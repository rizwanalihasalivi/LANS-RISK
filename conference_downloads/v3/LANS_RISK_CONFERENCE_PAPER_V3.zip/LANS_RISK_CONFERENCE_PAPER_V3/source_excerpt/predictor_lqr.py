"""Queue-predictor LQR + adaptive cruise; no hidden simulator state."""
import numpy as np
from baselines import AccelerationObserver,StandaloneLQR
from adaptive_mpc import propagate,errors,wrap

class PredictorLQR:
    def __init__(self,scenario,headway=1.2):
        self.scenario=['highway','merge','intersection','roundabout'].index(scenario)
        self.observer=AccelerationObserver();self.headway=headway
    def action(self,env,proposal=None):
        p=self.observer.packet(env);s=p['ego'];n=p['npcs'];ey,ep,curvature=errors(s[0],s[1],s[2],self.scenario)
        dy=env.e_y_dot_hat;dp=env.e_psi_dot_hat
        for u in p['pending']:
            s,n,_=propagate(s,n,float(u[0]),float(u[1]),self.scenario)
            next_ey,next_ep,curvature=errors(s[0],s[1],s[2],self.scenario)
            dy=.25*(next_ey-ey)/.1+.75*dy;dp=.25*wrap(next_ep-ep)/.1+.75*dp
            ey,ep=next_ey,next_ep
        steer=env.lqr.compute_action(dict(lateral_error=ey,lateral_error_rate=dy,yaw_error=ep,yaw_error_rate=dp,speed=s[3]),curvature)[0]
        target=p['desired_speed']
        for npc in n:
            if self.scenario==3:
                angle=(np.arctan2(npc[1],npc[0])-np.arctan2(s[1],s[0]))%(2*np.pi)
                gap=8*angle-16*np.arcsin(2.423/8)
            else:
                delta=npc[:2]-s[:2];direction=np.array([np.cos(s[2]),np.sin(s[2])])
                forward=float(delta@direction);lateral=abs(float(delta@np.array([-direction[1],direction[0]])))
                if forward<=0 or lateral>=4.846:continue
                gap=forward-np.sqrt(4.846**2-lateral**2)
            target=min(target,max(0.,npc[3]+.8*(gap-2.-self.headway*s[3])))
        self.log=dict(no_feasible=False)
        return np.array([steer,np.clip((target-s[3])/3.5,-1,1)],dtype=np.float32)
