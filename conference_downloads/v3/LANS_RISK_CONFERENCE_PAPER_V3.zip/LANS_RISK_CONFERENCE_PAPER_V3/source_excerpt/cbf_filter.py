"""Numerical discrete-time braking-distance CBF filter; not a safety certificate."""
import numpy as np
from numba import njit
from scipy.optimize import minimize
from adaptive_mpc import propagate,errors,nominal_steering
from baselines import AccelerationObserver

@njit(cache=True)
def barriers(state,npcs,scenario,buffer):
    out=np.empty(len(npcs)+1)
    for j in range(len(npcs)):
        dx=npcs[j,0]-state[0];dy=npcs[j,1]-state[1];dist=np.sqrt(dx*dx+dy*dy)
        vx=npcs[j,3]*np.cos(npcs[j,2])-state[3]*np.cos(state[2])
        vy=npcs[j,3]*np.sin(npcs[j,2])-state[3]*np.sin(state[2])
        closing=max(0.,-(dx*vx+dy*vy)/max(dist,1e-6))
        out[j]=dist-4.846-buffer-closing*closing/(2*3.5)
    ey,_,_=errors(state[0],state[1],state[2],scenario)
    out[-1]=1.75-abs(ey)
    return out

@njit(cache=True)
def constraints(action,state,npcs,scenario,buffer,gamma):
    before=barriers(state,npcs,scenario,buffer)
    s,n,_=propagate(state,npcs,action[0],action[1],scenario)
    return barriers(s,n,scenario,buffer)-(1.-gamma)*before

@njit(cache=True)
def grid_margins(actions,state,npcs,scenario,buffer,gamma):
    values=np.empty(len(actions))
    for j in range(len(actions)):values[j]=np.min(constraints(actions[j],state,npcs,scenario,buffer,gamma))
    return values

class DelayCBF:
    def __init__(self,scenario,gamma=.2,buffer=.25):
        self.scenario=['highway','merge','intersection','roundabout'].index(scenario)
        self.gamma=gamma;self.buffer=buffer;self.observer=AccelerationObserver()
    def action(self,env,proposal):
        p=self.observer.packet(env);s=p['ego'];n=p['npcs'];prefix=False
        for u in p['pending']:
            s,n,c=propagate(s,n,float(u[0]),float(u[1]),self.scenario)
            prefix|=bool(c<0 or abs(errors(s[0],s[1],s[2],self.scenario)[0])>1.75)
        proposal=np.clip(np.asarray(proposal,dtype=float),-1,1)
        fun=lambda u:constraints(np.asarray(u),s,n,self.scenario,self.buffer,self.gamma)
        objective=lambda u:float(2*(u[0]-proposal[0])**2+(u[1]-proposal[1])**2)
        if np.min(fun(proposal))>=0:
            action=proposal.astype(np.float32)
            margin=float(np.min(fun(action)))
            self.log=dict(no_feasible=margin < -1e-5,prefix_violation=prefix,barrier_margin=margin,solver_success=True)
            return action
        grid=np.array([[d,a] for d in np.linspace(-1,1,9) for a in np.linspace(-1,1,9)]+[proposal.tolist(),[nominal_steering(s,self.scenario),-1.]])
        margins=grid_margins(grid,s,n,self.scenario,self.buffer,self.gamma)
        feasible=np.flatnonzero(margins>=-1e-7)
        initial=grid[min(feasible,key=lambda j:objective(grid[j]))] if len(feasible) else grid[int(np.argmax(margins))]
        result=minimize(objective,initial,method='SLSQP',bounds=[(-1.,1.),(-1.,1.)],constraints=[dict(type='ineq',fun=fun)],options=dict(maxiter=35,ftol=1e-7))
        candidates=[grid[j] for j in feasible]
        if np.all(np.isfinite(result.x)) and np.all(np.abs(result.x)<=1.+1e-8) and np.min(fun(result.x))>=-1e-7:candidates.append(np.clip(result.x,-1,1))
        if candidates:action=min(candidates,key=objective)
        else:action=initial
        action=np.asarray(action,dtype=np.float32)
        self.log=dict(no_feasible=not bool(candidates) or np.min(fun(action)) < -1e-5,prefix_violation=prefix,barrier_margin=float(np.min(fun(action))),solver_success=bool(result.success))
        return np.asarray(action,dtype=np.float32)
