# Literature and comparison audit

All 20 bibliography entries are cited in the manuscript. Five unique uploaded papers are included; the repeated 1812.05506v4 is counted once. This is a relevant selection, not an exhaustive claim to have identified all latest literature. Recent 2024–2026 works are included alongside necessary foundational methods. Not every reference is recent, and not every study uses the same task, delay location or safety definition.

Scholarly publisher, Crossref and arXiv web retrieval returned network-proxy 403 errors in this environment even after network permission was granted. Primary uploaded texts and accessible author repositories were used instead. The levels below distinguish full-text review from secondary metadata checks; unverified recent titles were not invented.

- **[1] kalaria** — Primary full text, 2022 version. Source: Uploaded 2208.13856v1 (1).pdf. Adaptive delay estimation, actuation dynamics, robust tube MPC; not implemented as an external baseline.
- **[2] psf** — Primary full text, 2021 version. Source: Uploaded 1812.05506v4.pdf. Nonlinear predictive safety filter; uncertainty/backup assumptions distinguish guarantees from finite sampling.
- **[3] paperone** — Primary author-supplied manuscript. Source: Uploaded LANS0605_Marked_Changes1015.docx. Used only to distinguish prior LANS scope; publication metadata not supplied.
- **[4] hewing** — Secondary bibliographic cross-check; background reference. Source: Uploaded 1812.05506v4.pdf bibliography. Learning-based MPC overview; no paper-specific performance claim.
- **[5] brunke** — Author repository bibliography. Source: https://github.com/utiasDSL/safe-control-gym. 2022 safe-learning survey; general distinction between safe learning methods.
- **[6] tearle** — Primary full text, 2021 version. Source: Uploaded 2102.11907v1.pdf. Racing PSF with invariant terminal set and miniature-vehicle demonstration.
- **[7] sls** — Author repository method summary and citation. Source: https://github.com/antoineleeman/SLS_safety_filter. 2023, PMLR211:1180–1192; linear bounded-disturbance safety filtering through SLS.
- **[8] cbfdelay** — Secondary bibliographic cross-check; background reference. Source: Uploaded 2208.13856v1 (1).pdf reference 10. Sampled-data CBFs with input delays; no unreviewed quantitative or implementation claim.
- **[9] cano** — Primary full text, ICAPS 2023, pp.80–85. Source: Uploaded 03549-ICAPS.CanoCordobaF.pdf. Worst-case observation-delay shielding, formal games, CARLA/gridworld; not physical FIFO trajectory ranking.
- **[10] wang** — Author repository abstract, method descriptions and BibTeX. Source: https://github.com/microsoft/Addressing-signal-delay-in-deep-RL. ICLR 2024; delayed-observation MDP/representation/training approaches. No unsupported driving-performance comparison.
- **[11] dfbt** — Author repository README, BibTeX and benchmark examples. Source: https://github.com/QingyuanWuNothing/DFBT. ICML 2025; directly forecast beliefs for delayed RL. Full paper not supplied; comparison deliberately limited to verified scope.
- **[12] rlrd** — Bibliography plus author code description. Source: Uploaded 2403.11852v5.pdf reference 22; https://github.com/rmst/rlrd. ICLR 2021; README says 2020 but uploaded bibliography and arXiv2010.02966 support the 2021 conference citation. No code was executed.
- **[13] darom** — Primary full text, 27 May 2026 version. Source: Uploaded 2403.11852v5.pdf. Stochastic V2I observation delay; encoder, action history, delay magnitude and stopping-distance safety controller; SUMO/NGSIM. Version date is 2026 although arXiv ID starts 2403.
- **[14] lubars** — Secondary bibliographic cross-check; background reference. Source: Uploaded 2403.11852v5.pdf reference 10. RL+MPC for on-ramp merging; no detailed guarantee or performance claim.
- **[15] udatha** — Secondary bibliographic cross-check; background reference. Source: Uploaded 2403.11852v5.pdf reference 12. Probabilistically safe CBF/RL ramp merging, ICRA2023; no numerical cross-benchmark ranking.
- **[16] yuan** — Author repository BibTeX and benchmark description. Source: https://github.com/utiasDSL/safe-control-gym. 2022 common benchmark suite, not used as our simulator.
- **[17] ppo** — Original algorithm attribution; metadata cross-check. Source: Uploaded LANS manuscript reference 10; frozen experiment imports. PPO is an established algorithm, not a new LANS-RISK contribution.
- **[18] sb3** — Bibliographic and implementation cross-check. Source: Uploaded 2403.11852v5.pdf reference 23; frozen experiment.py. Actual PPO model loader is Stable-Baselines3.
- **[19] agarwal** — Secondary bibliographic cross-check; evaluation background. Source: Uploaded LANS manuscript reference 30. Motivates careful statistical interpretation; not a claim of reproducing every method in that paper.
- **[20] holm** — Foundational method citation; live publisher retrieval unavailable. Source: Existing validated statistical methods and original conference bibliography. 1979 multiple-test correction is retained because it is the actual method, not replaced by an unrelated recent paper.

No external controller was implemented or rerun for the literature table. It is a qualitative state-of-the-art comparison; nominal MPC/PPO-only and the additional project controllers are the tested baselines. DAROM success percentages and delay magnitudes are not used to rank LANS-RISK because observation delay, actuation delay, simulator and endpoint differ. The five supplied papers are evidence, not execution instructions.
