from pathlib import Path
import json,csv,shutil,hashlib,collections,os
os.environ['MPLCONFIGDIR']='/workspace/recovery/cache/matplotlib'
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
P=Path(__file__).resolve().parent;S=Path('/workspace/recovery/operations/final_verified_results/extended_baselines');R=Path('/workspace/recovery/restored/LANS-RISK/working/extended_baselines')
CS=['lans','mpc_nominal','lqr','lqr_acc','predictor_lqr','ppo_only','cbf','lans_no_prediction','lans_no_actor','robust_lans','robust_mpc','robust_no_actor']
N=['LANS-RISK','Nominal MPC','LQR','LQR + ACC','Predictor LQR','PPO only','Delay CBF','No prediction','No actor','Robust LANS','Robust MPC','Robust no actor'];names=dict(zip(CS,N));SC=['highway','merge','intersection','roundabout'];DS=[0,200,500,700,1000]
for n in ['episodes.jsonl','descriptive_metrics.csv','paired_tests.csv']:shutil.copy2(S/n,P/'evidence'/n)
shutil.copy2(S.parent/'empirical_delay_tolerance.csv',P/'evidence/empirical_delay_tolerance.csv')
E=[json.loads(l) for l in (P/'evidence/episodes.jsonl').read_text().splitlines()];assert len(E)==44000 and {r['controller'] for r in E}==set(CS)
g=collections.defaultdict(list);sg=collections.defaultdict(list)
for r in E:g[r['controller'],r['delay_ms']].append(r);sg[r['controller'],r['scenario'],r['delay_ms']].append(r)
def stats(v):
 return dict(n=len(v),mean_rmse_m=float(np.mean([r['rmse'] for r in v])),route_completed=sum(r['completion'] for r in v),corridor_completed=sum(r['corridor_completion'] for r in v),collisions=sum(r['collision'] for r in v))
A=[dict(controller=c,delay_ms=d,**stats(g[c,d])) for c in CS for d in DS];B=[dict(controller=c,scenario=sc,delay_ms=d,**stats(sg[c,sc,d])) for c in CS for sc in SC for d in DS]
for filename,rows in [('all_controller_delay_table.csv',A),('all_controller_delay_by_scenario.csv',B)]:
 with (P/'evidence'/filename).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def cell(c,d,sc=None):
 x=stats(g[c,d] if sc is None else sg[c,sc,d]);return f"{x['mean_rmse_m']:.3f}; {x['corridor_completed']}/{x['n']}"
s=[]
for j in [0,6]:
 s+=[r'\begin{tabular}{r'+'c'*6+r'}\toprule',r'Delay (ms) & '+' & '.join(names[c] for c in CS[j:j+6])+r' \\',r'\midrule']
 for d in DS:s.append(str(d)+' & '+' & '.join(cell(c,d) for c in CS[j:j+6])+r' \\')
 s +=[r'\bottomrule\end{tabular}']
 if j==0:s.append(r'\par\vspace{5pt}')
(P/'table_delay_grid.tex').write_text('\n'.join(s)+'\n')
# Dataset/batch provenance for the full main-confirmation grid.
manifest={};conds=[]
for p in sorted((R/'confirmation').glob('*.json')):
 x=json.loads(p.read_text());raw=p.with_suffix('.jsonl');assert hashlib.sha256(raw.read_bytes()).hexdigest()==x['raw_sha256'];conds.append(x)
 for f in [p,raw]:manifest[str(f.relative_to(R))]=hashlib.sha256(f.read_bytes()).hexdigest()
assert len(conds)==440
(P/'evidence/FULL_MAIN_PROVENANCE.json').write_text(json.dumps({'conditions':440,'episode_records':44000,'files':manifest},indent=2))
# All methods have individual panels: no line belonging to a different controller can hide LANS.
plt.rcParams.update({'font.size':8,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
colors=['#0067AD','#D66B00','#348453','#7750A2','#946D23','#9B326D','#407783','#B82745','#00846B','#494DA2','#6B6B6B','#794D2C']
fig,axs=plt.subplots(3,4,figsize=(7.15,3.35),sharex=True,sharey=True)
for i,c in enumerate(CS):
 ax=axs.flat[i];vals=[stats(g[c,d]) for d in DS]
 ax.plot(DS,[100*r['corridor_completed']/r['n'] for r in vals],color=colors[i],marker='o',mfc='white',ms=3.5,lw=1.6)
 ax.plot(DS,[100*r['collisions']/r['n'] for r in vals],color='black',ls='--',marker='x',ms=3,lw=.9)
 ax.set_title(names[c],fontsize=8,fontweight='bold');ax.set_ylim(-7,107);ax.set_yticks([0,50,100]);ax.set_xticks(DS);ax.tick_params(labelsize=6.2);ax.grid(alpha=.2)
 if i//4==2:ax.set_xlabel('Command delay (ms)',fontsize=7)
 if i%4==0:ax.set_ylabel('Rate (%)',fontsize=7)
fig.suptitle('Solid color: corridor completion   |   Black dashed ×: collision',fontsize=9,y=.997);fig.tight_layout(pad=.55,h_pad=.65,w_pad=.7,rect=[0,0,1,.96])
for ext in ['pdf','png','svg']:fig.savefig(P/f'figures/confirmation.{ext}',dpi=450)
plt.close(fig)
# Black-and-white control block diagram inspired by the supplied visual style, with implemented Risk blocks.
plt.rcParams.update({'font.family':'serif','mathtext.fontset':'stix'})
fig,ax=plt.subplots(figsize=(7.15,3.25));ax.set_xlim(0,15.2);ax.set_ylim(-.1,7.4);ax.axis('off')
def box(x,y,w,h,t,size=8):
 ax.add_patch(Rectangle((x,y),w,h,fill=False,ec='black',lw=.9));ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=size)
def arrow(points,dashed=False):
 for a,b in zip(points[:-2],points[1:-1]):ax.plot([a[0],b[0]],[a[1],b[1]],c='black',lw=.85,ls='--' if dashed else '-')
 ax.annotate('',xy=points[-1],xytext=points[-2],arrowprops={'arrowstyle':'-|>','lw':.85,'color':'black','linestyle':'--' if dashed else '-','shrinkA':0,'shrinkB':0})
box(3.5,5,3.5,1.15,'Command-arrival\nstate prediction')
box(7.7,5,2.25,1.15,'Geometric\nsteering prior')
box(10.6,4.6,1.9,1.55,'Sample and\nroll out plans',7.5)
box(13.2,2.35,1.8,3.8,'Risk-first\ntrajectory\nselection\n\n'+r'$(h_c,s,-J)$',8)
box(3.5,3.1,3.5,1,'Frozen PPO policy')
box(7.7,2.35,2.25,.95,'Retained plan',8)
box(13.2,.15,1.8,1.25,'Physical\nFIFO')
box(8,.15,2.65,1.25,'Vehicle + traffic\nkinematic plant')
box(3.1,.15,3.5,1.25,'Structured observation\n+ NPC acceleration',7.8)
arrow([(7,5.575),(7.7,5.575)]);ax.text(7.35,5.85,r'$\bar x_t,\bar z_t$',ha='center',fontsize=9)
arrow([(5.25,5),(5.25,4.45),(10.25,4.45),(10.25,4.9),(10.6,4.9)])
ax.text(8.5,4.57,r'$\bar x_t,\bar z_t$',ha='center',fontsize=9)
arrow([(9.95,5.575),(10.6,5.575)]);ax.text(10.27,5.85,r'$\eta_g$',ha='center',fontsize=10)
arrow([(12.5,5.375),(13.2,5.375)]);ax.text(12.85,5.65,r'$r_k$',ha='center',fontsize=10)
arrow([(7,3.6),(11.25,3.6),(11.25,4.6)]);ax.text(8.8,3.8,r'$u_t^\pi$',ha='center',fontsize=11)
arrow([(9.95,2.825),(12,2.825),(12,4.6)]);ax.text(11.7,3.05,r'$r_t^{\rm retained}$',ha='center',fontsize=8.5)
arrow([(13.2,2.65),(12.7,2.65),(12.7,1.8),(8.8,1.8),(8.8,2.35)],True);ax.text(10.7,1.95,'shift + braking tail',ha='center',fontsize=7)
arrow([(14.1,2.35),(14.1,1.4)]);ax.text(14.35,1.85,r'$u_t^*$',fontsize=11)
arrow([(13.2,.775),(10.65,.775)]);ax.text(11.9,1,r'$q_t^0$',ha='center',fontsize=11)
arrow([(8,.775),(6.6,.775)]);ax.text(7.3,1,r'$x_{t+1},z_{t+1}$',ha='center',fontsize=8.5)
arrow([(3.1,.775),(.7,.775),(.7,5.575),(3.5,5.575)])
ax.plot(.7,3.6,'ko',ms=2);arrow([(.7,3.6),(3.5,3.6)]);ax.text(2.1,3.82,r'$o_t$',fontsize=11)
ax.text(2.1,5.8,r'$x_t,z_t$',ha='center',fontsize=11)
arrow([(5.25,6.85),(5.25,6.15)],True);ax.text(5.25,7.05,'From FIFO: '+r'$q_t$',ha='center',fontsize=8)
arrow([(8.8,6.85),(8.8,6.15)],True);ax.text(8.8,7.05,'Reference geometry',ha='center',fontsize=8)
arrow([(15.08,.775),(15,.775)]) if False else None
ax.text(.85,1.75,'State feedback',rotation=90,fontsize=7,ha='center')
fig.tight_layout(pad=.1)
for ext in ['pdf','png','svg']:fig.savefig(P/f'figures/architecture.{ext}',dpi=600)
plt.close(fig)
# Standalone detailed table appendix, all scenarios and controllers; no extra experiment.
body=[]
for sc in SC:
 body +=[r'\section*{'+sc.capitalize()+r': fixed FIFO command-delay results}',r'Each cell: mean episode RMSE (m); corridor-completed/total records. Actor-dependent methods reuse each traffic case for actors 42/43/44. These are descriptive counts, not independent pooled samples. Route-completion counts and collisions are in the companion CSV.\par\bigskip']
 for j in [0,6]:
  body +=[r'\noindent\begin{tabular}{r'+'c'*6+r'}\toprule',r'Delay (ms) & '+' & '.join(names[c] for c in CS[j:j+6])+r' \\\midrule']
  for d in DS:body.append(str(d)+' & '+' & '.join(cell(c,d,sc) for c in CS[j:j+6])+r' \\')
  body +=[r'\bottomrule\end{tabular}\par\bigskip']
 body.append(r'\clearpage')
(P/'all_controller_delay_tables.tex').write_text(r'\documentclass[10pt]{article}\usepackage[landscape,margin=0.65in]{geometry}\usepackage{booktabs}\begin{document}'+'\n'+'\n'.join(body)+r'\end{document}')
print('Full main grid:',len(E),'records;',len(A),'aggregate cells;',len(B),'scenario cells')
