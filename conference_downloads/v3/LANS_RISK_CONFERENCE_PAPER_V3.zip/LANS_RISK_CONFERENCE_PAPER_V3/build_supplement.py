from pathlib import Path
import json,collections,os,shutil
os.environ['MPLCONFIGDIR']='/workspace/recovery/cache/matplotlib'
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
P=Path(__file__).resolve().parent
E=[json.loads(l) for l in (P/'evidence/episodes.jsonl').read_text().splitlines()];g=collections.defaultdict(list)
for r in E:g[r['controller'],r['scenario'],r['actor_seed'],r['delay_ms']].append(r)
CS=['lans','mpc_nominal','lqr','lqr_acc','predictor_lqr','ppo_only','cbf','lans_no_prediction','lans_no_actor','robust_lans','robust_mpc','robust_no_actor'];N=['LANS-RISK','Nominal MPC','LQR','LQR + ACC','Predictor LQR','PPO only','Delay CBF','No prediction','No actor','Robust LANS','Robust MPC','Robust no actor'];SC=['highway','merge','intersection','roundabout'];DS=[0,200,500,700,1000]
plt.rcParams.update({'font.size':9,'pdf.fonttype':42})
with PdfPages(P/'all_controller_scenario_figures.pdf') as pdf:
 for start in [0,4,8]:
  fig,axs=plt.subplots(4,4,figsize=(11,8),sharex=True,sharey=True)
  for i,c in enumerate(CS[start:start+4]):
   seeds=sorted({r['actor_seed'] for r in E if r['controller']==c})
   for j,sc in enumerate(SC):
    ax=axs[i,j]
    for metric,col,style,marker in [('corridor_completion','#0067AD','-','o'),('collision','#222222','--','x')]:
     vals=[np.array([100*np.mean([r[metric] for r in g[c,sc,k,d]]) for k in seeds]) for d in DS]
     ax.plot(DS,[v.mean() for v in vals],c=col,ls=style,marker=marker,ms=4,mfc='white',lw=1.4);ax.fill_between(DS,[v.min() for v in vals],[v.max() for v in vals],color=col,alpha=.13)
    ax.set_ylim(-7,107);ax.set_yticks([0,50,100]);ax.set_xticks(DS);ax.grid(alpha=.2)
    if i==0:ax.set_title(sc.capitalize())
    if j==0:ax.set_ylabel(N[start+i]+' (%)')
    if i==3:ax.set_xlabel('Command delay (ms)')
  fig.suptitle('Solid blue: corridor completion; black dashed: collision\nActor-seed means and min–max shading (not confidence intervals)',fontsize=12)
  fig.tight_layout(rect=[0,0,1,.94]);pdf.savefig(fig);fig.savefig(P/f'figures/all_controller_scenarios_{start//4+1}.png',dpi=300);plt.close(fig)
# Copies for interpretation of all listed controllers; original source is unchanged.
R=Path('/workspace/recovery/restored/LANS-RISK/working/extended_baselines')
for n in ['scenario_planner.py','cbf_filter.py','predictor_lqr.py']:
 if R.exists():shutil.copy2(R/n,P/'source_excerpt'/n)
