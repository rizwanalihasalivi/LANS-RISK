# LANS-RISK conference manuscript package

Start with `paper.pdf` (definitive five-page, two-column layout). `paper.docx` is an editable single-column Word version with editable equations and tables. `paper.tex` is the self-contained manuscript source; `paper_template.tex` plus generated table fragments are its authoring inputs. Original vector figures and high-resolution PNGs are in `figures/`.

## Evidence and provenance

`evidence/episodes.jsonl` contains the selected 22,000 main-confirmation records, not new experiments. CSVs contain selected per-condition metrics, intervals, paired tests and empirical delay thresholds. `CLAIM_VERIFICATION.json` identifies the 220 conditions, 440 original raw/metadata hashes and main numerical claims. `source_excerpt/` contains unchanged controller/protocol source for interpretation, not a standalone experiment installation. The complete code, models, logs and other studies remain in the separately delivered `LANS_RISK_FINAL_VERIFIED_RESULTS.zip`; this focused manuscript package does not replace that archive.

All selected methods retain all four scenarios and five delays. Holm-adjusted values preserve the parent main study's 3,440-test family; they cannot be reproduced by correcting only the filtered conference tests. Actor repetitions reuse traffic cases. Display averages across actors are descriptive, not independent pooled observations. Episode RMSE is saved episode-level evidence, not independently reconstructed full trajectories. No new experiment, timing superiority or formal safety guarantee is claimed.

## Build

Use Python with python-docx, NumPy and Matplotlib, Pandoc, and a LaTeX installation with pdflatex, amsmath, booktabs, graphicx and hyperref. IEEEtran.cls is included with its license header. Run `python build_document.py` in this folder to rebuild PDF and DOCX from existing generated figures/tables. `build_evidence.py` regenerates the evidence and graphics from the original project recovery tree; its S and R paths must be set to that full archive's verified results and frozen extended-baselines directory on another machine. It validates source hashes before using the selected batches.

`CONFERENCE_JOURNAL_SCOPE.md` explains the requested approximate 60% scope and journal extension boundaries. No exact percentage guarantees publication eligibility. `PACKAGE_VALIDATION.json` records final structural/numerical checks. `SHA256SUMS.json` identifies every packaged payload.
