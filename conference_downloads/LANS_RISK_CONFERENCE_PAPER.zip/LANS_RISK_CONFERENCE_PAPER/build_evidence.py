from pathlib import Path
import csv,json,hashlib,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg');matplotlib.rcParams.update({'font.size':8,'pdf.fonttype':42})
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent;S=Path('/workspace/recovery/operations/final_verified_results');R=Path('/workspace/recovery/restored/LANS-RISK/working/extended_baselines')
METHODS=['lans','mpc_nominal','ppo_only','lans_no_prediction','lans_no_actor'];SC=['highway','merge','intersection','roundabout'];labels={'lans':'LANS-RISK','mpc_nominal':'Nominal MPC','ppo_only':'PPO only','lans_no_prediction':'No queue prediction','lans_no_actor':'No actor'}
def read(p):
 with p.open() as f:return list(csv.DictReader(f))
def write(p,rows):
 with p.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
metrics=[x for x in read(S/'extended_baselines/descriptive_metrics.csv') if x['controller'] in METHODS]
pairs=[x for x in read(S/'extended_baselines/paired_tests.csv') if x['a']=='lans' and x['b'] in METHODS]
write(P/'evidence/descriptive_metrics.csv',metrics);write(P/'evidence/paired_tests.csv',pairs)
manifest={};conditions=[]
for p in sorted((R/'confirmation').glob('*.json')):
 x=json.loads(p.read_text())
 if x['controller'] not in METHODS:continue
 raw=p.with_suffix('.jsonl');assert hashlib.sha256(raw.read_bytes()).hexdigest()==x['raw_sha256'];conditions.append(x)
 manifest[str(p.relative_to(R))]=hashlib.sha256(p.read_bytes()).hexdigest();manifest[str(raw.relative_to(R))]=x['raw_sha256']
assert len(conditions)==220 and sum(x['count'] for x in conditions)==22000
with (P/'evidence/episodes.jsonl').open('w') as f:
 for line in (S/'extended_baselines/episodes.jsonl').read_text().splitlines():
  if json.loads(line)['controller'] in METHODS:f.write(line+'\n')
thresholds=[x for x in read(S/'empirical_delay_tolerance.csv') if x['controller'] in METHODS];write(P/'evidence/empirical_delay_tolerance.csv',thresholds)
def value(s,c,d,m):
 a=[float(x['mean']) for x in metrics if (x['scenario'],x['controller'],x['delay_ms'],x['metric'])==(s,c,str(d),m)];return np.array(a)*(1 if m=='rmse' else 100)
# Wide figure keeps all delays and scenarios rather than selecting favorable conditions.
fig,axes=plt.subplots(2,4,figsize=(7.1,3.35),sharey='row')
styles={'lans':('o','#1368a0'), 'mpc_nominal':('s','#d26b24'),'lans_no_prediction':('^','#9a3c74'),'lans_no_actor':('x','#3a864f')}
for j,s in enumerate(SC):
 for i,m in enumerate(['collision','corridor_completion']):
  ax=axes[i,j]
  for c,(marker,color) in styles.items():
   ds=[0,200,500,700,1000];a=[value(s,c,d,m) for d in ds]
   ax.plot(ds,[v.mean() for v in a],marker=marker,ms=3,lw=1,color=color,label=labels[c]);ax.fill_between(ds,[v.min() for v in a],[v.max() for v in a],color=color,alpha=.1)
  ax.set_ylim(-3,103);ax.set_xticks([0,500,1000]);ax.grid(alpha=.2)
  if i==0:ax.set_title(s.capitalize())
  if i==1:ax.set_xlabel('FIFO delay (ms)')
  if j==0:ax.set_ylabel('Collision (%)' if i==0 else 'Corridor success (%)')
h,l=axes[0,0].get_legend_handles_labels();fig.legend(h,l,loc='lower center',ncol=4,fontsize=7)
fig.tight_layout(rect=(0,.07,1,1));fig.savefig(P/'figures/confirmation.pdf');fig.savefig(P/'figures/confirmation.png',dpi=350);plt.close(fig)
# Original architecture schematic, not a reproduction of the reference illustration.
fig,ax=plt.subplots(figsize=(7.1,1.55));ax.set_xlim(0,10);ax.set_ylim(0,2);ax.axis('off')
boxes=[(.05,.9,1.65,'Observed state\n+ pending FIFO'),(2.05,.9,1.6,'Queue rollout\narrival prediction'),(4.05,.9,1.9,'Sample and rank\n30-step trajectories'),(6.45,.9,1.4,'Selected action\nphysical FIFO'),(8.3,.9,1.5,'Vehicle + traffic\nplant')]
from matplotlib.patches import FancyBboxPatch
for x,y,w,t in boxes:
 ax.add_patch(FancyBboxPatch((x,y),w,.65,boxstyle='round,pad=.02',fc='#eaf1f6',ec='#52677b',lw=.7));ax.text(x+w/2,y+.325,t,ha='center',va='center',fontsize=7)
for a,b in zip(boxes,boxes[1:]):ax.annotate('',xy=(b[0],1.225),xytext=(a[0]+a[2],1.225),arrowprops={'arrowstyle':'->','lw':.8})
ax.text(5,.48,'Frozen PPO proposal + retained previous plan',ha='center',fontsize=7)
ax.annotate('',xy=(5,.9),xytext=(5,.65),arrowprops={'arrowstyle':'->','lw':.8})
ax.plot([9,9,.9],[.9,.12,.12],color='#52677b',lw=.7)
ax.annotate('',xy=(.9,.9),xytext=(.9,.12),arrowprops={'arrowstyle':'->','lw':.7})
fig.tight_layout(pad=.2);fig.savefig(P/'figures/architecture.pdf');fig.savefig(P/'figures/architecture.png',dpi=350);plt.close(fig)
# Tables generated from verified numerical evidence.
rows=[]
for s in SC:
 a=[value(s,c,1000,m).mean() for c in ['lans','mpc_nominal'] for m in ['collision','corridor_completion','rmse']]
 rows.append(s.capitalize()+' & '+' & '.join(f'{v:.1f}' if i%3!=2 else f'{v:.3f}' for i,v in enumerate(a))+r' \\')
(P/'table_endpoints.tex').write_text('\n'.join(rows)+'\n')
rows=[]
for s in SC:
 for c in ['lans','lans_no_prediction','lans_no_actor','ppo_only']:
  vals=[value(s,c,1000,m).mean() for m in ['collision','corridor_completion','rmse']]
  rows.append(s.capitalize()+' & '+labels[c]+' & '+f'{vals[0]:.1f} & {vals[1]:.1f} & {vals[2]:.3f}'+r' \\')
(P/'table_ablations.tex').write_text('\n'.join(rows)+'\n')
claims={'subset_conditions':220,'subset_episode_records':22000,'full_confirmation_conditions':440,'full_confirmation_episode_records':44000,'holm_family_tests':3440,'source_methods':METHODS,'raw_file_hashes':manifest,'paired_corridor_tests':{}}
for c in METHODS[1:]:
 a=[r for r in pairs if r['b']==c and r['metric']=='corridor_completion'];claims['paired_corridor_tests'][c]={'tests':len(a),'positive_mean_differences':sum(float(x['mean_difference_a_minus_b'])>0 for x in a),'negative_mean_differences':sum(float(x['mean_difference_a_minus_b'])<0 for x in a),'holm_below_0_05':sum(float(x['p_holm'])<.05 for x in a)}
(P/'evidence/CLAIM_VERIFICATION.json').write_text(json.dumps(claims,indent=2))
print(json.dumps({k:v for k,v in claims.items() if k!='raw_file_hashes'}))
