# Conference and journal scope

The conference manuscript is a focused first article, approximately the requested 60% in narrative scope. This is not a measured percentage of scientific novelty, nor permission to republish the same article. It reports 22,000 of 44,000 main-confirmation records (50% of those records), retaining every scenario, delay and case for its five selected methods. Selection was made after evaluation and is disclosed.

| Conference article includes | Reserved for a substantive journal extension |
|---|---|
| Queue-aware trajectory-supervision method and assumptions | Expanded mechanism analysis and broader controller families |
| All four scenarios and all five fixed FIFO delays | Plant/traffic robustness confirmation, including separately documented dense-Merge amendment |
| Matched nominal MPC and PPO-only comparisons | Stochastic observation-delay evaluation |
| Queue-prediction and actor-removal ablations | Remaining required ablations and robustness variants |
| Main completion, collision and tracking results | Dedicated sequential runtime measurements and computational tradeoffs |
| Honest negative findings, uncertainty and limitations | Integrated analysis across the complete experimental program |

The actor-removal negative result and tied MPC delay thresholds are included now; they are not withheld to make the conference paper look stronger. Future journal work should cite and disclose the conference version, distinguish reused evidence, and follow the actual journal/conference extension policies. There is no universal 60/40 rule.

## Before submission

This is an English manuscript draft in a five-page IEEE conference layout. The supplied reference is a 12-page Transactions-style article; its visual conventions informed the layout, but its wording and figures were not copied. A specific conference has not been selected, so its page limit, anonymization, reference and disclosure requirements still need application. Author names and affiliation follow the supplied LANS manuscript and should be checked by the authors. That manuscript's publication metadata was not supplied and is not invented here. The paper makes an empirical integration contribution, not a first-ever/PPO novelty or certified safety claim. The references are focused rather than an exhaustive novelty search.
