"""Observable acceleration CEM variant; damped acceleration and FIFO rollout."""
import math
import numpy as np
from numba import njit
from lans_env_scenario import LANSSafeEnv

@njit(cache=True)
def wrap(x):
    return math.atan2(math.sin(x), math.cos(x))

@njit(cache=True)
def errors(x, y, heading, scenario):
    if scenario == 3:
        return 8.-math.hypot(x,y), wrap(heading-math.atan2(y,x)-math.pi/2), 1./8.
    yr=0.; pr=0.; curvature=0.
    if scenario == 1:
        z=min(1., max(0.,x/25.))
        yr=-3.5+3.5*(10*z**3-15*z**4+6*z**5)
        yp=3.5*(30*z*z-60*z**3+30*z**4)/25.
        ypp=3.5*(60*z-180*z*z+120*z**3)/625.
        pr=math.atan(yp); curvature=ypp/(1+yp*yp)**1.5
    return y-yr, wrap(heading-pr), curvature

@njit(cache=True)
def nominal_steering(state, scenario):
    ey, ep, curvature=errors(state[0],state[1],state[2],scenario)
    delta=math.atan(2.6*curvature)-.4*ey-1.2*(ep+state[3]*curvature*.05)
    return min(1.,max(-1.,delta/.5))

@njit(cache=True)
def propagate(state,npcs,steer,accel,scenario):
    s=state.copy(); n=npcs.copy()
    s[3]=min(25.,max(0.,s[3]+3.5*accel*.1))
    s[2]=wrap(s[2]+s[3]*math.tan(.5*steer)/2.6*.1)
    s[0]+=s[3]*.1*math.cos(s[2]); s[1]+=s[3]*.1*math.sin(s[2])
    clearance=1e6
    for j in range(len(n)):
        n[j,3]=min(20.,max(0.,n[j,3]+.1*n[j,4]))
        n[j,4]*=.85
        if scenario==3:
            theta=math.atan2(n[j,1],n[j,0])+n[j,3]*.1/8.
            n[j,0]=8.*math.cos(theta); n[j,1]=8.*math.sin(theta)
            n[j,2]=theta+math.pi/2
        else:
            # Observed-acceleration predictor: no hidden desired speed.
            n[j,0]+=n[j,3]*.1*math.cos(n[j,2]); n[j,1]+=n[j,3]*.1*math.sin(n[j,2])
        clearance=min(clearance,math.hypot(n[j,0]-s[0],n[j,1]-s[1])-4.846)
    return s,n,clearance

@njit(cache=True)
def costs(plans,state,npcs,scenario,desired_speed,buffer):
    values=np.zeros(len(plans)); minimum=np.full(len(plans),1e6)
    for k in range(len(plans)):
        s=state.copy(); n=npcs.copy()
        for t in range(30):
            steer=min(1.,max(-1.,nominal_steering(s,scenario)+plans[k,t//5,0]))
            accel=plans[k,t//5,1]
            s,n,clearance=propagate(s,n,steer,accel,scenario)
            ey,ep,_=errors(s[0],s[1],s[2],scenario)
            values[k]+=8*ey*ey+2*ep*ep+.15*(s[3]-desired_speed)**2+.05*(steer*steer+accel*accel)+5*max(0.,2.-clearance)**2
            minimum[k]=min(minimum[k],clearance)
            if clearance<buffer: values[k]+=1e6+1e4*(buffer-clearance)**2
    return values,minimum

class MPCEnv(LANSSafeEnv):
    """Direct MPC command through the existing plant; optional shared supervisor."""
    def __init__(self,scenario,shield):
        super().__init__(scenario=scenario,safety_enabled=shield,lqr_enabled=False)
    def step(self,action):
        # Parent fuses beta*action with LQR. Direct MPC must bypass that blend.
        # Synthetic latency draw consumption is preserved by the parent.
        self.beta=1.
        return super().step(action)

class CEMMPC:
    def __init__(self,scenario,seed,compensate=True,buffer=.25):
        self.buffer=buffer
        self.compensate=compensate
        self.scenario=('highway','merge','intersection','roundabout').index(scenario)
        self.rng=np.random.default_rng(700000+seed)
        self.previous=None
        self.fallback=False
    def action(self,packet):
        state=packet['ego'].copy(); npcs=packet['npcs'].copy()
        self.prefix_clearance=1e6
        if self.compensate:
            for command in packet['pending']:
                state,npcs,clearance=propagate(state,npcs,float(command[0]),float(command[1]),self.scenario)
                self.prefix_clearance=min(self.prefix_clearance,clearance)
        cruise=np.zeros((6,2)); cruise[:,1]=np.clip((packet['desired_speed']-state[3])/3.5,-1,1)
        brake=cruise.copy(); brake[:,1]=-1.
        mean=cruise.copy() if self.previous is None else self.previous.copy()
        std=np.tile([.18,.65],(6,1))
        best=mean.copy(); best_cost=float('inf'); best_clearance=-float('inf')
        for _ in range(3):
            candidates=np.clip(self.rng.normal(mean,std,(192,6,2)),-1,1)
            candidates[0]=mean; candidates[1]=cruise; candidates[2]=brake; candidates[3]=best
            score,clear=costs(candidates,state,npcs,self.scenario,packet['desired_speed'],self.buffer)
            order=np.argsort(score)
            if score[order[0]]<best_cost:
                best_cost=float(score[order[0]]); best=candidates[order[0]].copy(); best_clearance=float(clear[order[0]])
            elite=candidates[order[:24]]
            mean=elite.mean(axis=0); std=np.maximum(elite.std(axis=0),[.025,.08])
        # Approximate one-step shift of block parameterization.
        expanded=np.repeat(best,5,axis=0)
        shifted=np.concatenate([expanded[1:],expanded[-1:]])
        self.previous=shifted.reshape(6,5,2).mean(axis=1)
        self.fallback=best_clearance<self.buffer
        steer=np.clip(nominal_steering(state,self.scenario)+best[0,0],-1,1)
        if self.fallback: steer=nominal_steering(state,self.scenario)
        return np.array([steer,-1. if self.fallback else best[0,1]],dtype=np.float32)
