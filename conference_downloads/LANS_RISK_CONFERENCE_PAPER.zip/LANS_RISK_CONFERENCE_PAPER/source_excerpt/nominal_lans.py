"""Experimental trajectory-retaining LANS-Risk supervisor, not certified MPC."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'submission_study'))
import numpy as np
from numba import njit
from adaptive_mpc import propagate,nominal_steering,errors
from baselines import AccelerationObserver
from queue_authority import packet

@njit(cache=True)
def score_plans(plans,state,npcs,scenario,target,proposal,buffer,actor_weight=.5):
    scores=np.zeros(len(plans));collision_steps=np.full(len(plans),30);tracking_steps=np.full(len(plans),30);first_clearance=np.zeros(len(plans))
    for k in range(len(plans)):
        s=state.copy();n=npcs.copy()
        for t in range(30):
            d=min(1.,max(-1.,nominal_steering(s,scenario)+plans[k,t,0]));a=plans[k,t,1]
            s,n,c=propagate(s,n,d,a,scenario);ey,ep,_=errors(s[0],s[1],s[2],scenario)
            m=min(c-buffer,1.75-abs(ey))
            if t==0:first_clearance[k]=c
            if c<buffer:collision_steps[k]=min(collision_steps[k],t)
            if abs(ey)>1.75:tracking_steps[k]=min(tracking_steps[k],t)
            scores[k]+=8*ey*ey+2*ep*ep+.2*(s[3]-target)**2+.03*(d*d+a*a)+10*max(0.,1.-c)**2
            if m<0:
                scores[k]+=1e6+1e5*m*m
            if t==0:scores[k]+=actor_weight*((d-proposal[0])**2+(a-proposal[1])**2)
    return scores,collision_steps,tracking_steps,first_clearance

class LANSHandover:
    def __init__(self,scenario,seed,buffer=.25,samples=192,compensate=True,use_actor=True):
        self.use_actor=use_actor
        self.compensate=compensate
        self.samples=samples
        self.observer=AccelerationObserver()
        self.scenario=['highway','merge','intersection','roundabout'].index(scenario)
        self.rng=np.random.default_rng(900000+seed);self.previous=None;self.buffer=buffer
    def action(self,env,ppo):
        p=self.observer.packet(env);s=p['ego'];n=p['npcs'];prefix=1e6
        for u in (p['pending'] if self.compensate else []):
            s,n,c=propagate(s,n,float(u[0]),float(u[1]),self.scenario)
            ey,_,_=errors(s[0],s[1],s[2],self.scenario)
            prefix=min(prefix,c-self.buffer,1.75-abs(ey))
        analytic=nominal_steering(s,self.scenario);proposal=np.asarray(ppo,dtype=float) if self.use_actor else np.array([analytic,np.clip((p['desired_speed']-s[3])/3.5,-1,1)])
        target=p['desired_speed']  # Same reference-speed ceiling as MPC; PPO remains a proposal/prior.
        cruise=np.zeros((30,2));cruise[:,1]=np.clip((target-s[3])/3.5,-1,1)
        brake=np.zeros((30,2));brake[:,1]=-1
        prior=cruise.copy();prior[0]=[np.clip(proposal[0]-analytic,-1.,1.),proposal[1]]
        retained=brake.copy() if self.previous is None else self.previous.copy()
        mean=cruise.copy() if self.previous is None else self.previous.copy()
        std=np.tile([.18,.65],(30,1));best=brake.copy();best_key=(-1,-float('inf'),-float('inf'));best_collision=-1;best_tracking=-1
        for _ in range(3):
            noise=np.repeat(self.rng.normal(size=(self.samples,6,2)),5,axis=1)
            plans=np.clip(mean[None,:,:]+noise*std[None,:,:],-1,1)
            plans[:,:,0]=np.clip(plans[:,:,0],-1.,1.)
            plans[:6]=[mean,cruise,brake,prior,retained,best]
            values,collision_steps,tracking_steps,first_clearance=score_plans(plans,s,n,self.scenario,target,proposal,self.buffer,.5 if self.use_actor else 0.)
            # Collision prevention precedes tracking recovery. If tracking is
            # already infeasible, do not force braking into a moving obstacle.
            secondary=np.where(collision_steps==0,first_clearance,tracking_steps.astype(float))
            order=np.lexsort((values,-secondary,-collision_steps));idx=order[0]
            key=(int(collision_steps[idx]),float(secondary[idx]),-float(values[idx]))
            if key>best_key:
                best=plans[idx].copy();best_key=key
                best_collision=int(collision_steps[idx]);best_tracking=int(tracking_steps[idx])
            elite=plans[order[:16 if self.samples==96 else 24]];mean=elite.mean(axis=0);std=np.maximum(elite.std(axis=0),[.015,.08])
        self.previous=np.concatenate([best[1:],np.array([[0.,-1.]])])
        action=np.array([np.clip(analytic+best[0,0],-1,1),best[0,1]])
        self.log=dict(no_feasible=best_collision<30 or best_tracking<30,prefix_violation=prefix<0,forecast_collision_free_steps=best_collision,forecast_tracking_steps=best_tracking)
        return action.astype(np.float32)
