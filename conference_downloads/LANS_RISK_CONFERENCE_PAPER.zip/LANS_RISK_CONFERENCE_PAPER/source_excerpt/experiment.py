"""Independent development and frozen holdout experiments; preserves old evidence."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'): os.environ[key]='1'
import sys,json,time,hashlib,argparse
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/'submission_study'
sys.path.insert(0,str(BASE))
import numpy as np
import torch
from stable_baselines3 import PPO
from extended_suite import ProtocolEnv
from queue_authority import DirectEnv,packet
from corridor_filter import CorridorFilter
from observable_mpc import CEMMPC,propagate as cv_propagate
sys.path.insert(0,str(ROOT.parent/'latency_improvement'))
from lans_predictive import LANSPredictive,LANSRiskSearch
sys.path.insert(0,str(ROOT.parent/'handover_study'))
from handover import LANSHandover
sys.path.insert(0,str(ROOT.parent/'traffic_v2'))
from benchmark import TrafficEnv
sys.path.insert(0,str(ROOT))
from nominal_lans import LANSHandover as AdaptiveLANS
from predictor_lqr import PredictorLQR
from cbf_filter import DelayCBF
from scenario_planner import ScenarioPlanner
from adaptive_mpc import CEMMPC as AdaptiveMPC,propagate as accel_propagate
from baselines import AccelerationObserver,StandaloneLQR
SCENARIOS=['highway','merge','intersection','roundabout']

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def sources():
    paths=[ROOT.parent/'traffic_v2'/'benchmark.py',ROOT.parent/'latency_improvement'/'lans_predictive.py',ROOT.parent/'handover_study'/'handover.py']+list(ROOT.glob('*.py'))+list((ROOT/'tests').glob('*.py'))+list((ROOT/'diagnostics').glob('*.py'))+[ROOT/'PROTOCOL.md']+list(BASE.glob('*.py'))+list((BASE/'original_models').glob('*.zip'))
    return {str(p.relative_to(ROOT.parent)):digest(p) for p in sorted(paths)}

def evaluate(job):
    stage,s,c,k,d,count,first=job
    torch.set_num_threads(1)
    destination=ROOT/stage;destination.mkdir(exist_ok=True)
    path=destination/f'{s}_{c}_seed{k}_delay{d*100}.json'
    raw=path.with_suffix('.jsonl')
    if path.exists():
        result=json.loads(path.read_text())
        assert result['count']==count and result['first']==first and result['raw_sha256']==digest(raw)
        assert result['source_hash']==hashlib.sha256(json.dumps(sources(),sort_keys=True).encode()).hexdigest()
        return result
    model=None if c in ACTOR_FREE else PPO.load(BASE/'original_models'/f'{s}_seed{k}.zip',device='cpu')
    rows=[];start=time.monotonic()
    for case in range(first,first+count):
        env=TrafficEnv(s,delay=d,direct=c!='full')
        obs,_=env.reset(seed=case)
        controller=make_controller(c,s,case)
        observer=AccelerationObserver()
        errors=[];success=False;timings=[];no_feasible=0
        diagnostic=AccelerationObserver();cv_errors=[];accel_errors=[]
        for _ in range(env.max_steps):
            started=time.perf_counter_ns()
            if c in ACTOR_FREE:
                action=controller.action(observer.packet(env)) if c=='mpc_nominal' else (controller.action(env) if c in ('lqr','lqr_acc') else controller.action(env,None))
            else:
                action,_=model.predict(obs,deterministic=True)
                if controller:action=controller.action(env,action)
            timings.append((time.perf_counter_ns()-started)/1e6)
            if controller: no_feasible+=int(getattr(controller,'log',{}).get('no_feasible',False))
            forecast=diagnostic.packet(env);u=forecast['pending'][0] if len(forecast['pending']) else action
            _,cv_n,_=cv_propagate(forecast['ego'],forecast['npcs'][:,:4],float(u[0]),float(u[1]),SCENARIOS.index(s))
            _,accel_n,_=accel_propagate(forecast['ego'],forecast['npcs'],float(u[0]),float(u[1]),SCENARIOS.index(s))
            obs,_,done,trunc,info=env.step(action)
            actual=packet(env)['npcs']
            cv_errors.append(float(np.linalg.norm(actual[:,:2]-cv_n[:,:2],axis=1).mean()))
            accel_errors.append(float(np.linalg.norm(actual[:,:2]-accel_n[:,:2],axis=1).mean()))
            errors.append(info['lateral_error']); success|=info['success']
            if done or trunc: break
        collision=bool(info['collision']);complete=bool(success and not collision)
        rows.append(dict(episode_seed=case,collision=collision,completion=complete,
            corridor_completion=bool(complete and max(abs(x) for x in errors)<=1.75),
            corridor_exceedance=bool(max(abs(x) for x in errors)>1.75),
            progress=float(info['route_progress']),rmse=float(np.sqrt(np.mean(np.square(errors)))),
            steps=len(errors),no_feasible_steps=no_feasible,
            npc_position_error_cv=float(np.mean(cv_errors)),npc_position_error_accel=float(np.mean(accel_errors)),
            # Exclude initial JIT/startup step from steady-state diagnostic only.
            decision_ms_median=float(np.median(timings[1:] or timings)),
            decision_ms_max=float(max(timings)),timeout=bool(trunc and not complete and not collision)))
        env.close()
    raw.write_text(''.join(json.dumps(r,allow_nan=False)+'\n' for r in rows))
    result=dict(scenario=s,controller=c,policy_seed=k,delay_ms=100*d,count=count,first=first,
                raw_sha256=digest(raw),source_hash=hashlib.sha256(json.dumps(sources(),sort_keys=True).encode()).hexdigest(),
                seconds=time.monotonic()-start)
    for metric in ('collision','completion','corridor_completion','corridor_exceedance','timeout'):
        result[metric]=float(100*np.mean([r[metric] for r in rows]))
    for metric in ('progress','rmse','decision_ms_median','no_feasible_steps','npc_position_error_cv','npc_position_error_accel'):
        result[metric]=float(np.mean([r[metric] for r in rows]))
    path.write_text(json.dumps(result,indent=2)); return result

METHODS=['predictor_lqr','cbf','robust_mpc','ppo_only','lans_no_prediction','lans','mpc_nominal','lqr','lqr_acc','robust_lans','robust_no_actor','lans_no_actor']
ACTOR_FREE={'predictor_lqr','robust_mpc','mpc_nominal','lqr','lqr_acc','robust_no_actor','lans_no_actor'}

def make_controller(name,scenario,seed):
    if name=='predictor_lqr':return PredictorLQR(scenario)
    if name=='cbf':return DelayCBF(scenario)
    if name=='robust_mpc':return ScenarioPlanner(scenario,seed,use_actor=False,exact_handover=False)
    if name=='robust_no_actor':return ScenarioPlanner(scenario,seed,use_actor=False,exact_handover=True)
    if name=='robust_lans':return ScenarioPlanner(scenario,seed)
    if name=='lans_no_actor':return AdaptiveLANS(scenario,seed,use_actor=False)
    if name=='ppo_only':return None
    if name in ('lans','lans_no_prediction'):return AdaptiveLANS(scenario,seed,compensate=name=='lans')
    if name=='mpc_nominal':return AdaptiveMPC(scenario,seed,buffer=.25)
    if name in ('lqr','lqr_acc'):return StandaloneLQR(adaptive_cruise=name=='lqr_acc')
    raise ValueError(name)

def main():
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=['smoke','development','confirmation'],required=True)
    p.add_argument('--workers',type=int,default=1);a=p.parse_args()
    freeze_path=ROOT/'EXTENDED_FREEZE.json'
    current=sources()
    if freeze_path.exists():assert json.loads(freeze_path.read_text())['sha256']==current,'Frozen sources changed'
    else:freeze_path.write_text(json.dumps(dict(sha256=current),indent=2))
    first,count=(120900,1) if a.stage=='smoke' else ((121000,20) if a.stage=='development' else (141000,100))
    delays=[0,5] if a.stage=='smoke' else [0,2,5,7,10]
    jobs=[(a.stage,s,c,k,d,count,first) for c in METHODS for s in SCENARIOS for k in ([0] if c in ACTOR_FREE else ([42,43,44] if a.stage=='confirmation' else [42])) for d in delays]
    results=[]
    with ProcessPoolExecutor(a.workers) as pool:
        for f in as_completed([pool.submit(evaluate,j) for j in jobs]):
            result=f.result();results.append(result);print(json.dumps(result),flush=True)
    (ROOT/f'{a.stage}_SUMMARY.json').write_text(json.dumps(results,indent=2))
    print('COMPLETE',a.stage,len(results),sum(r['count'] for r in results),flush=True)
if __name__=='__main__':main()
