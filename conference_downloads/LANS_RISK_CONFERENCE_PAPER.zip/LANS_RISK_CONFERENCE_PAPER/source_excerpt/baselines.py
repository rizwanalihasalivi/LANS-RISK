"""Observable finite-difference acceleration and explicit standalone LQR baselines."""
import numpy as np
from queue_authority import packet

class AccelerationObserver:
    def __init__(self):self.previous=None
    def packet(self,env):
        p=packet(env);n=p['npcs'];a=np.zeros(len(n))
        if self.previous is not None:
            a=np.clip((n[:,3]-self.previous)/env.dt,-6.,1.5)
        self.previous=n[:,3].copy()
        p['npcs']=np.column_stack([n,a])
        return p

class StandaloneLQR:
    def __init__(self,adaptive_cruise=False):self.adaptive_cruise=adaptive_cruise
    def action(self,env):
        ey,ep=env._compute_raw_errors()
        steer=env.lqr.compute_action(dict(lateral_error=ey,lateral_error_rate=env.e_y_dot_hat,
            yaw_error=ep,yaw_error_rate=env.e_psi_dot_hat,speed=env.ego.velocity),env._reference_curvature())[0]
        target=env.config['desired_speed'];ego=env.ego
        if self.adaptive_cruise:
            for n in env.npcs:
                if env.scenario=='roundabout':
                    angle=(np.arctan2(n.position[1],n.position[0])-np.arctan2(ego.position[1],ego.position[0]))%(2*np.pi)
                    gap=8*angle-16*np.arcsin(2.423/8)
                else:
                    delta=n.position-ego.position
                    direction=np.array([np.cos(ego.heading),np.sin(ego.heading)])
                    forward=float(delta@direction);lateral=abs(float(delta@np.array([-direction[1],direction[0]])))
                    if forward<=0 or lateral>=4.846:continue
                    gap=forward-np.sqrt(4.846**2-lateral**2)
                target=min(target,max(0.,n.velocity+.8*(gap-2.-1.2*ego.velocity)))
        return np.array([steer,np.clip((target-ego.velocity)/3.5,-1,1)],dtype=np.float32)
