# Extended controller comparison — fixed initial configuration

Priority: predictor LQR + ACC, numerical delay-aware CBF, finite-scenario robust MPC; then matched ablations and references. This suite is an adaptation to the existing synthetic benchmark, not reproduction of any uploaded paper.

All methods use traffic_v2, 0.1 s steps, identical case seeds and physical FIFO, 160-step horizon, action limits and observation access. No hidden NPC acceleration or desired-speed access is added. No actor retraining in this stage. Old frozen studies remain intact.

Development: 121000–121019, four scenarios, delays 0/200/500/700/1000 ms, actor42. Confirmation: 141000–141099, actors42/43/44; deterministic untrained controllers run once. Smoke:120900,0/500 ms, one case; not evidence of superiority. Freeze all source/model hashes before executing. No tuning on confirmation. Initial fixed parameters are not asserted to be optimal.

Predictor LQR uses observed acceleration and queued inputs to predict arrival state, then original LQR + ACC (1.2 s headway). CBF uses a discrete-time braking-distance barrier, gamma0.2, margin0.25m, grid plus SLSQP, explicit infeasibility logging. This numerical filter has no global certificate or terminal invariant set.

Finite-scenario robust MPC uses acceleration offsets 0/-1/+1 m/s², clipped to plant bounds, with worst-case cost and constraint-prefix ranking. This is NOT certified tube MPC: three correlated scenarios do not cover all uncertainties. Three CEM rounds, 96 candidates each, 30-step horizon and five-step blocks. Robust LANS and actor-free robust LANS use the same scenario/sample budgets with per-step trajectory retention.

Nominal LANS and LANS without delay prediction differ only in internal FIFO rollout; actual FIFO remains active. LANS without actor removes learned proposal/prior but preserves prediction, objective, samples and retention. PPO-only removes the entire supervisor: its contrast with LANS measures the supervisor bundle, NOT an isolated safety-mechanism causal effect. CBF vs PPO measures that specific filter addition. Predictor LQR vs LQR+ACC isolates queue-state prediction. Robust LANS vs robust actor-free version assesses actor contribution within that variant. Interactions remain possible.

Primary outcomes: collision, corridor-completion (goal reached, no collision throughout episode, all recorded lateral errors<=1.75m). Also route completion, RMSE, timeout, infeasible-step counts, decision times. Tolerance: highest tested delay with collision<=1% and corridor-completion>=90% at every lower tested delay. No extrapolation beyond tested range. Cold FIFO startup may violate the corridor before a controller can influence the plant. Timings with JIT/shared CPU contention are diagnostics, not real-time guarantees.

Do not pool actor seeds as independent traffic cases. Compare paired traffic seeds, report seed-specific outcomes and uncertainty. Ties are not exclusive wins. Do not rank from smoke data or unfinished confirmation.
