from pathlib import Path
import csv,json,os
os.environ['MPLCONFIGDIR']='/workspace/recovery/cache/matplotlib'
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
P=Path(__file__).resolve().parent;M=list(csv.DictReader((P/'evidence/descriptive_metrics.csv').open()));T=list(csv.DictReader((P/'evidence/empirical_delay_tolerance.csv').open()))
SC=['highway','merge','intersection','roundabout'];CS=['lans','mpc_nominal','ppo_only','lans_no_prediction','lans_no_actor'];names=['LANS-RISK','Nominal MPC','PPO only','No prediction','No actor'];colors=['#0067AD','#D66B00','#7750A2','#B82745','#00846B'];markers=['o','s','^','D','x'];ds=[0,200,500,700,1000]
plt.rcParams.update({'font.size':8,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
for metric,filename,ytitle in [('corridor_completion','confirmation','Corridor completion (%)'),('collision','collision_all','Collision (%)')]:
 fig,axs=plt.subplots(5,4,figsize=(7.15,5.3),sharex=True,sharey=True)
 for i,c in enumerate(CS):
  for j,sc in enumerate(SC):
   ax=axs[i,j];vals=[]
   for d in ds:vals.append(np.array([100*float(r['mean']) for r in M if (r['controller'],r['scenario'],r['delay_ms'],r['metric'])==(c,sc,str(d),metric)]))
   ax.plot(ds,[v.mean() for v in vals],color=colors[i],marker=markers[i],lw=1.65,ms=4,markerfacecolor='white',markeredgewidth=1.2,zorder=3)
   ax.fill_between(ds,[v.min() for v in vals],[v.max() for v in vals],color=colors[i],alpha=.22)
   if metric=='corridor_completion':
    cv=[np.array([100*float(r['mean']) for r in M if (r['controller'],r['scenario'],r['delay_ms'],r['metric'])==(c,sc,str(d),'collision')]) for d in ds]
    ax.plot(ds,[v.mean() for v in cv],color='#222222',ls='--',marker='x',lw=1,ms=3,zorder=4)
    ax.fill_between(ds,[v.min() for v in cv],[v.max() for v in cv],color='#222222',alpha=.1)
   ax.set_ylim(-7,107);ax.set_yticks([0,50,100]);ax.set_xticks(ds);ax.tick_params(labelsize=6.4);ax.grid(alpha=.2);ax.axhline(90 if metric=='corridor_completion' else 1,color='.55',ls=':',lw=.65)
   if i==0:ax.set_title(sc.capitalize(),fontsize=9,fontweight='bold')
   if j==0:ax.set_ylabel(names[i],fontsize=8,color=colors[i],fontweight='bold')
   if i==4:ax.set_xlabel('FIFO delay (ms)',fontsize=7)
 fig.suptitle('Solid color: corridor completion (%)   |   Black dashed ×: collision (%)' if metric=='corridor_completion' else 'Collision (%) — separate panels for every controller',fontsize=9,y=.997)
 fig.tight_layout(pad=.65,h_pad=.65,w_pad=.7,rect=[0,0,1,.975]);fig.savefig(P/f'figures/{filename}.pdf');fig.savefig(P/f'figures/{filename}.png',dpi=450);plt.close(fig)
# Empirical threshold visualization: per-actor points on separate method rows, no jitter of measured delay.
fig,axs=plt.subplots(1,4,figsize=(7.15,2.5),sharey=True)
threshold_rows=[]
for j,sc in enumerate(SC):
 ax=axs[j]
 for i,c in enumerate(CS):
  rows=sorted([r for r in T if r['scenario']==sc and r['controller']==c],key=lambda r:int(r['actor_seed']))
  vals=[r['empirical_contiguous_passing_delay_ms'] for r in rows]
  for z,r in enumerate(rows):
   y=i+(z-1)*.17 if len(rows)==3 else i
   if r['empirical_contiguous_passing_delay_ms']=='':ax.text(-95,y,'×',color=colors[i],ha='center',va='center',fontsize=10)
   else:
    v=float(r['empirical_contiguous_passing_delay_ms']);ax.plot(v,y,marker='>' if r['upper_grid_censored']=='True' else 'o',color=colors[i],ms=4)
  threshold_rows.append({'scenario':sc,'controller':c,'actor_order':'42/43/44' if len(rows)==3 else 'actor-free','thresholds_ms':'/'.join(v or 'NP' for v in vals),'censored':all(r['upper_grid_censored']=='True' for r in rows)})
 ax.set_title(sc.capitalize(),fontsize=9);ax.set_xlim(-160,1110);ax.set_xticks([0,500,1000]);ax.grid(axis='x',alpha=.25);ax.set_xlabel('Passing delay (ms)',fontsize=8);ax.set_ylim(4.65,-.65)
axs[0].set_yticks(range(5),names,fontsize=8);fig.tight_layout(pad=.8);fig.savefig(P/'figures/latency_thresholds.pdf');fig.savefig(P/'figures/latency_thresholds.png',dpi=450);plt.close(fig)
with (P/'evidence/latency_table.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(threshold_rows[0]));w.writeheader();w.writerows(threshold_rows)
rows=[]
for c,n in zip(CS,names):
 cells=[]
 for sc in SC:
  r=next(r for r in threshold_rows if r['scenario']==sc and r['controller']==c);v=r['thresholds_ms'].split('/');cell=v[0] if len(set(v))==1 else '/'.join(v)
  if r['censored']:cell+=r'$^{\dagger}$'
  cells.append(cell)
 rows.append(n+' & '+' & '.join(cells)+r' \\')
(P/'table_latency.tex').write_text('\n'.join(rows)+'\n')
# Expanded original framework, with distinct observation, planning and physical actuation paths.
fig,ax=plt.subplots(figsize=(7.15,2.8));ax.set_xlim(0,12);ax.set_ylim(0,4.7);ax.axis('off')
def box(x,y,w,h,txt,fc='#EDF3F8'):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.05',fc=fc,ec='#45617B',lw=.9));ax.text(x+w/2,y+h/2,txt,ha='center',va='center',fontsize=8)
def arrow(x1,y1,x2,y2):ax.annotate('',xy=(x2,y2),xytext=(x1,y1),arrowprops={'arrowstyle':'->','lw':1,'color':'#34495E'})
box(.1,2.55,2.05,1.1,'State: ego + NPCs\nPending FIFO\nObserved data only')
box(2.7,2.55,2.0,1.1,'Queue rollout\nPredict arrival state\nLog prefix violations')
box(5.25,2.55,2.3,1.1,'Sample future plans\nH = 30, K = 192\n3 rounds, 24 elites')
box(8.15,2.55,3.6,1.1,'Lexicographic selection\nCollision prefix → corridor → cost\nReturn selected first action')
for a,b in [(2.15,2.7),(4.7,5.25),(7.55,8.15)]:arrow(a,3.1,b,3.1)
box(5.25,.95,2.3,.85,'Frozen PPO action prior\n+ shifted retained plan',fc='#FFF3D9');arrow(6.4,1.8,6.4,2.55)
box(8.15,.15,1.65,1.2,'Physical FIFO\nzero-filled start\nd × 100 ms',fc='#E5F3EB')
box(10.2,.15,1.55,1.2,'Vehicle + traffic\nplant\nΔt = 0.1 s',fc='#E5F3EB')
arrow(9,2.55,9,1.35);arrow(9.8,.75,10.2,.75)
ax.plot([11.8,11.95,11.95,1.1,1.1],[.75,.75,4.25,4.25,3.65],color='#34495E',lw=.8);arrow(1.1,3.95,1.1,3.65);ax.text(6.4,4.4,'Next observation and updated FIFO',ha='center',fontsize=8)
ax.text(2.5,.6,'Pending commands cannot be replaced\nby the newly computed command.',ha='center',fontsize=8,color='#405568')
fig.tight_layout(pad=.2);fig.savefig(P/'figures/architecture.pdf');fig.savefig(P/'figures/architecture.png',dpi=450);plt.close(fig)
print('Generated framework, all-controller completion/collision panels, and threshold figure/table.')
