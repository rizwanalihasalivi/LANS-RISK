# LANS-RISK conference manuscript package

Start with `paper.pdf` (definitive eight-page, two-column layout). `paper.docx` is an editable single-column Word version with editable equations and tables. `paper.tex` is the self-contained manuscript source; `paper_template.tex` plus generated table fragments are its authoring inputs. Original vector figures and high-resolution PNGs are in `figures/`.

## Evidence and provenance

`evidence/episodes.jsonl` contains the selected 22,000 main-confirmation records, not new experiments. CSVs contain selected per-condition metrics, intervals, paired tests and empirical delay thresholds. `CLAIM_VERIFICATION.json` identifies the 220 conditions, 440 original raw/metadata hashes and main numerical claims. `source_excerpt/` contains unchanged controller/protocol source for interpretation, not a standalone experiment installation. The complete code, models, logs and other studies remain in the separately delivered `LANS_RISK_FINAL_VERIFIED_RESULTS.zip`; this focused manuscript package does not replace that archive.

All selected methods retain all four scenarios and five delays. Holm-adjusted values preserve the parent main study's 3,440-test family; they cannot be reproduced by correcting only the filtered conference tests. Actor repetitions reuse traffic cases. Display averages across actors are descriptive, not independent pooled observations. Episode RMSE is saved episode-level evidence, not independently reconstructed full trajectories. No new experiment, timing superiority or formal safety guarantee is claimed.

## Build

Use Python with python-docx, NumPy and Matplotlib, Pandoc, and a LaTeX installation with pdflatex, amsmath, booktabs, graphicx and hyperref. IEEEtran.cls is included with its license header. Run `python build_document.py` in this folder to rebuild PDF and DOCX from existing generated figures/tables. Run `python build_revision_figures.py` to regenerate the revised framework, per-controller plots and latency summary from the packaged CSVs. `build_evidence.py` regenerates the evidence and graphics from the original project recovery tree; its S and R paths must be set to that full archive's verified results and frozen extended-baselines directory on another machine. It validates source hashes before using the selected batches.

`CONFERENCE_JOURNAL_SCOPE.md` explains the requested approximate 60% scope and journal extension boundaries. No exact percentage guarantees publication eligibility. `PACKAGE_VALIDATION.json` records final structural/numerical checks. `SHA256SUMS.json` identifies every packaged payload.

## Revision 2

Adds 20 cited references including all five unique supplied papers; a qualitative SOTA table; explicit delay, dynamics, prediction, sampling and score equations in Sections III–IV; an expanded framework; a compact algorithm; an empirical actuation-delay table/figure; and separate controller panels that preserve coincident results. `figures/collision_all.pdf` is the supplemental all-controller collision plot. Actuation-delay thresholds are not CPU execution-time measurements. Dedicated runtime/observation-delay/robustness studies remain outside this focused article. Read `LITERATURE_REVIEW_NOTES.md` for source-verification levels and network limitations.
