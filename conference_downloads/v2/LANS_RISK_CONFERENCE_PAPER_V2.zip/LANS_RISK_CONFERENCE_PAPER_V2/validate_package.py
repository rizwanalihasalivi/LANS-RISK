from pathlib import Path
import json,hashlib,collections,csv,re,subprocess,math
from docx import Document
P=Path(__file__).resolve().parent
rows=[json.loads(l) for l in (P/'evidence/episodes.jsonl').read_text().splitlines()]
k=lambda r:(r['controller'],r['scenario'],int(r['actor_seed']),int(r['delay_ms']))
g=collections.defaultdict(list)
for r in rows:g[k(r)].append(r)
assert len(rows)==22000 and len(g)==220
assert all(len(v)==100 and {r['episode_seed'] for r in v}==set(range(141000,141100)) for v in g.values())
metrics=list(csv.DictReader((P/'evidence/descriptive_metrics.csv').open()));checks=0
for m in metrics:
 if m['metric'] not in ['collision','corridor_completion','rmse']:continue
 group=g[k(m)];mean=sum(float(r[m['metric']]) for r in group)/100
 assert math.isclose(mean,float(m['mean']),abs_tol=1e-10);checks+=1
assert checks==660
# Reconstruct all 44 controller/actor/scenario endpoints from episode outcomes.
thresholds=list(csv.DictReader((P/'evidence/empirical_delay_tolerance.csv').open()))
for t in thresholds:
 last=None
 for delay in [0,200,500,700,1000]:
  v=g[(t['controller'],t['scenario'],int(t['actor_seed']),delay)]
  if sum(r['collision'] for r in v)<=1 and sum(r['corridor_completion'] for r in v)>=90:last=delay
  else:break
 assert t['empirical_contiguous_passing_delay_ms']==('' if last is None else str(last))
 assert (t['upper_grid_censored']=='True')==(last==1000)
assert len(thresholds)==44
claims=json.loads((P/'evidence/CLAIM_VERIFICATION.json').read_text());pairs=list(csv.DictReader((P/'evidence/paired_tests.csv').open()))
for c,claim in claims['paired_corridor_tests'].items():
 pp=[r for r in pairs if r['a']=='lans' and r['b']==c and r['metric']=='corridor_completion']
 assert len(pp)==claim['tests']==60
 assert sum(float(r['p_holm'])<.05 for r in pp)==claim['holm_below_0_05']
s=(P/'paper.tex').read_text();keys=re.findall(r'\\bibitem\{([^}]+)\}',s);cited=set(k for group in re.findall(r'\\cite\{([^}]+)\}',s) for k in group.split(','))
assert len(keys)==len(set(keys))==20 and set(keys)==cited
assert {'tearle','psf','kalaria','darom','cano'}<=cited
assert len(json.loads((P/'evidence/UPLOADED_SOURCE_HASHES.json').read_text()))==5
D=Document(P/'paper.docx');assert len(D.tables)==5 and len(D.inline_shapes)==3
assert sum(p.style.name=='Table Caption' for p in D.paragraphs)==5
assert sum(p.style.name=='Image Caption' for p in D.paragraphs)==3
assert D._element.xml.count('<m:oMath>')>=60
assert sum(bool(re.match(r'^\[\d+\]',p.text)) for p in D.paragraphs)==20
log=(P/'paper.log').read_text();assert 'Overfull' not in log and 'undefined' not in log
info=subprocess.check_output(['pdfinfo',str(P/'paper.pdf')],text=True);assert re.search(r'Pages:\s+8',info)
report={'status':'pass','episode_records':22000,'conditions':220,'case_seeds_per_condition':100,'independently_recomputed_metric_means':checks,'independently_recomputed_delay_endpoints':len(thresholds),'paired_corridor_comparisons_checked':240,'cited_unique_references':20,'unique_uploaded_literature_sources':5,'pdf_pages':8,'editable_tables_including_algorithm':5,'embedded_main_figures':3,'supplemental_collision_figure':True,'word_math_objects':D._element.xml.count('<m:oMath>'),'word_reference_labels':20,'latex_overfull_or_undefined_warnings':False,'limitations':['Literature table is qualitative; cited external algorithms were not rerun.','Recent 2024–2026 sources and foundational references coexist; no exhaustive latest-literature claim.','Source access/verification levels are detailed in LITERATURE_REVIEW_NOTES.md.','Actuation-delay endpoints are not execution-time measurements.','Existing episode-level data reused; no new experiment or peer-review claim.']}
(P/'PACKAGE_VALIDATION.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
