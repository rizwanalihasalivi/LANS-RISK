from pathlib import Path
import json,csv,shutil,hashlib,collections,os
os.environ['MPLCONFIGDIR']='/workspace/recovery/cache/matplotlib'
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
P=Path(__file__).resolve().parent;S=Path('/workspace/recovery/operations/final_verified_results/extended_baselines');R=Path('/workspace/recovery/restored/LANS-RISK/working/extended_baselines')
CS=['lans','mpc_nominal','lqr','lqr_acc','predictor_lqr','ppo_only','cbf','lans_no_prediction','lans_no_actor','robust_lans','robust_mpc','robust_no_actor']
N=['LANS-RISK','Nominal MPC','LQR','LQR + ACC','Predictor LQR','PPO only','Delay CBF','No prediction','No actor','Robust LANS','Robust MPC','Robust no actor'];names=dict(zip(CS,N));SC=['highway','merge','intersection','roundabout'];DS=[0,200,500,700,1000]
for n in ['episodes.jsonl','descriptive_metrics.csv','paired_tests.csv']:shutil.copy2(S/n,P/'evidence'/n)
shutil.copy2(S.parent/'empirical_delay_tolerance.csv',P/'evidence/empirical_delay_tolerance.csv')
E=[json.loads(l) for l in (P/'evidence/episodes.jsonl').read_text().splitlines()];assert len(E)==44000 and {r['controller'] for r in E}==set(CS)
g=collections.defaultdict(list);sg=collections.defaultdict(list)
for r in E:g[r['controller'],r['delay_ms']].append(r);sg[r['controller'],r['scenario'],r['delay_ms']].append(r)
def stats(v):
 return dict(n=len(v),mean_rmse_m=float(np.mean([r['rmse'] for r in v])),route_completed=sum(r['completion'] for r in v),corridor_completed=sum(r['corridor_completion'] for r in v),collisions=sum(r['collision'] for r in v))
A=[dict(controller=c,delay_ms=d,**stats(g[c,d])) for c in CS for d in DS];B=[dict(controller=c,scenario=sc,delay_ms=d,**stats(sg[c,sc,d])) for c in CS for sc in SC for d in DS]
for filename,rows in [('all_controller_delay_table.csv',A),('all_controller_delay_by_scenario.csv',B)]:
 with (P/'evidence'/filename).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def cell(c,d,sc=None):
 x=stats(g[c,d] if sc is None else sg[c,sc,d]);return f"{x['mean_rmse_m']:.3f}; {x['corridor_completed']}/{x['n']}"
s=[]
for j in [0,6]:
 s+=[r'\begin{tabular}{r'+'c'*6+r'}\toprule',r'Delay (ms) & '+' & '.join(names[c] for c in CS[j:j+6])+r' \\',r'\midrule']
 for d in DS:s.append(str(d)+' & '+' & '.join(cell(c,d) for c in CS[j:j+6])+r' \\')
 s +=[r'\bottomrule\end{tabular}']
 if j==0:s.append(r'\par\vspace{5pt}')
(P/'table_delay_grid.tex').write_text('\n'.join(s)+'\n')
# Dataset/batch provenance for the full main-confirmation grid.
manifest={};conds=[]
for p in sorted((R/'confirmation').glob('*.json')):
 x=json.loads(p.read_text());raw=p.with_suffix('.jsonl');assert hashlib.sha256(raw.read_bytes()).hexdigest()==x['raw_sha256'];conds.append(x)
 for f in [p,raw]:manifest[str(f.relative_to(R))]=hashlib.sha256(f.read_bytes()).hexdigest()
assert len(conds)==440
(P/'evidence/FULL_MAIN_PROVENANCE.json').write_text(json.dumps({'conditions':440,'episode_records':44000,'files':manifest},indent=2))
# All methods have individual panels: no line belonging to a different controller can hide LANS.
plt.rcParams.update({'font.size':8,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
colors=['#0067AD','#D66B00','#348453','#7750A2','#946D23','#9B326D','#407783','#B82745','#00846B','#494DA2','#6B6B6B','#794D2C']
fig,axs=plt.subplots(3,4,figsize=(7.15,3.35),sharex=True,sharey=True)
for i,c in enumerate(CS):
 ax=axs.flat[i];vals=[stats(g[c,d]) for d in DS]
 ax.plot(DS,[100*r['corridor_completed']/r['n'] for r in vals],color=colors[i],marker='o',mfc='white',ms=3.5,lw=1.6)
 ax.plot(DS,[100*r['collisions']/r['n'] for r in vals],color='black',ls='--',marker='x',ms=3,lw=.9)
 ax.set_title(names[c],fontsize=8,fontweight='bold');ax.set_ylim(-7,107);ax.set_yticks([0,50,100]);ax.set_xticks(DS);ax.tick_params(labelsize=6.2);ax.grid(alpha=.2)
 if i//4==2:ax.set_xlabel('Command delay (ms)',fontsize=7)
 if i%4==0:ax.set_ylabel('Rate (%)',fontsize=7)
fig.suptitle('Solid color: corridor completion   |   Black dashed ×: collision',fontsize=9,y=.997);fig.tight_layout(pad=.55,h_pad=.65,w_pad=.7,rect=[0,0,1,.96])
for ext in ['pdf','png','svg']:fig.savefig(P/f'figures/confirmation.{ext}',dpi=450)
plt.close(fig)
# Rebuild the V4 reference-style framework after regenerating data plots.
import runpy
runpy.run_path(str(P/"build_framework.py"))
# Standalone detailed table appendix, all scenarios and controllers; no extra experiment.
body=[]
for sc in SC:
 body +=[r'\section*{'+sc.capitalize()+r': fixed FIFO command-delay results}',r'Each cell: mean episode RMSE (m); corridor-completed/total records. Actor-dependent methods reuse each traffic case for actors 42/43/44. These are descriptive counts, not independent pooled samples. Route-completion counts and collisions are in the companion CSV.\par\bigskip']
 for j in [0,6]:
  body +=[r'\noindent\begin{tabular}{r'+'c'*6+r'}\toprule',r'Delay (ms) & '+' & '.join(names[c] for c in CS[j:j+6])+r' \\\midrule']
  for d in DS:body.append(str(d)+' & '+' & '.join(cell(c,d,sc) for c in CS[j:j+6])+r' \\')
  body +=[r'\bottomrule\end{tabular}\par\bigskip']
 body.append(r'\clearpage')
(P/'all_controller_delay_tables.tex').write_text(r'\documentclass[10pt]{article}\usepackage[landscape,margin=0.65in]{geometry}\usepackage{booktabs}\begin{document}'+'\n'+'\n'.join(body)+r'\end{document}')
print('Full main grid:',len(E),'records;',len(A),'aggregate cells;',len(B),'scenario cells')
