"""Publication vector diagram; reference-style placement, implemented LANS-RISK signals."""
from pathlib import Path
import os
os.environ['MPLCONFIGDIR']='/workspace/recovery/cache/matplotlib'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
P=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'serif','font.serif':['STIXGeneral'],'mathtext.fontset':'stix','pdf.fonttype':42,'svg.fonttype':'none'})
fig,ax=plt.subplots(figsize=(18,10));ax.set_xlim(0,18);ax.set_ylim(0,10);ax.axis('off')
def box(x,y,w,h,t,fs=24):
 ax.add_patch(Rectangle((x,y),w,h,fill=False,lw=1.5,color='black'))
 ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=fs,linespacing=1.1)
def arrow(ps,dash=False):
 for a,b in zip(ps[:-2],ps[1:-1]):ax.plot([a[0],b[0]],[a[1],b[1]],color='black',lw=1.3,ls=(0,(5,4)) if dash else '-')
 ax.annotate('',xy=ps[-1],xytext=ps[-2],arrowprops={'arrowstyle':'-|>','mutation_scale':15,'lw':1.3,'color':'black','linestyle':(0,(5,4)) if dash else '-','shrinkA':0,'shrinkB':0})
def label(x,y,t,fs=23):ax.text(x,y,t,ha='center',va='bottom',fontsize=fs)
def dot(x,y):ax.plot(x,y,'ko',ms=4)
# Same major visual hierarchy as the supplied LANS reference: upper prediction,
# central learned action, lower auxiliary branch, tall right-hand supervisor.
box(4.5,7.25,3.75,1.3,'Command-arrival\nstate prediction')
box(9.5,7.25,2.65,1.3,'Geometric\nsteering prior')
box(4.5,5.0,3.0,1.15,'Frozen PPO')
box(15.1,2.9,2.65,5.75,'Sampled\ntrajectory\nsearch\n\nRisk-first\nselection',25)
box(3.35,2.9,2.75,1.2,'Previous\nselected plan',23)
box(7.15,2.9,2.75,1.2,'Shift +\nbraking tail',23)
box(11.0,2.9,2.75,1.2,'Retained\ncandidate',23)
box(15.1,.35,2.65,1.45,'Physical FIFO',24)
box(9.1,.35,3.7,1.45,'Vehicle + traffic\nkinematic plant',24)
box(3.25,.35,3.9,1.45,'Observation\nconstruction',24)
# Structured state and the actor's distinct legacy feature vector.
arrow([(3.25,1.075),(.65,1.075),(.65,7.9),(4.5,7.9)])
label(2.45,8.03,r'$x_t,\ z_t$')
arrow([(1.8,1.075),(1.8,5.575),(4.5,5.575)])
label(3.2,5.7,r'$o_t$');dot(1.8,1.075)
# Independent dashed supplies follow the reference figure's top input convention.
arrow([(5.55,9.25),(5.55,8.55)],True);label(5.55,9.3,'from FIFO\n'+r'$q_t$',20)
arrow([(10.8,9.25),(10.8,8.55)],True);label(10.8,9.3,'reference geometry',20)
arrow([(8.25,7.9),(9.5,7.9)]);label(8.87,8.03,r'$\bar x_t$')
arrow([(8.85,7.9),(8.85,6.7),(15.1,6.7)]);dot(8.85,7.9)
label(12.9,6.82,r'$\bar x_t,\ \bar z_t$',22)
arrow([(12.15,7.9),(15.1,7.9)]);label(13.65,8.04,r'$\eta_g(\cdot)$')
arrow([(7.5,5.575),(15.1,5.575)]);label(11.7,5.75,r'$u_t^{\pi}$',27)
# Plan memory branch (replaces the old paper's clock/latency/gain branch).
arrow([(6.1,3.5),(7.15,3.5)]);label(6.62,3.66,r'$r_{t-1}^{*}$',23)
arrow([(9.9,3.5),(11.,3.5)]);label(10.45,3.66,r'$r_t^{\rm ret}$',22)
arrow([(13.75,3.5),(15.1,3.5)]);label(14.42,3.67,r'$r_t^{\rm ret}$',22)
arrow([(15.1,4.6),(4.72,4.6),(4.72,4.1)],True);label(10.1,4.7,r'$r_t^*$'+'   store for next decision',19)
# Closed-loop command and plant flow.
arrow([(16.42,2.9),(16.42,1.8)]);label(16.95,2.2,r'$u_t^*$',27)
arrow([(15.1,1.075),(12.8,1.075)]);label(13.95,1.2,r'$q_t^0$',25)
arrow([(9.1,1.075),(7.15,1.075)]);label(8.12,1.2,r'$x_{t+1},\ z_{t+1}$',21)
# Physical delay enters queue as in the supplied reference.
arrow([(15.55,2.5),(15.55,1.8)]);label(15.25,2.25,r'$d$',23)
fig.subplots_adjust(left=.006,right=.995,bottom=.015,top=.97)
for ext in ['pdf','png','svg']:fig.savefig(P/f'figures/architecture.{ext}',dpi=400)
plt.close(fig)
