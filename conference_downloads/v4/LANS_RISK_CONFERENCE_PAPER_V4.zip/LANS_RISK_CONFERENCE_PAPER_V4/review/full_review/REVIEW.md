# ARIS full-paper review: LANS-RISK V3

**Verdict: revise before submission.** The numerical core and the main algorithm description withstand this review. The paper is a credible, carefully bounded synthetic integration study, but V3 needs clearer information-access and inherited-policy disclosure, a reproducible benchmark specification, and a more explicit account of what its logs establish. These are mostly manuscript/supplement corrections using existing artifacts; no new experiment is required or authorized for this revision. The evidence does not justify stronger learning, safety, or MPC-superiority claims. Its incremental contribution remains a material venue-fit limitation, especially for a top general ML venue.

This is a fresh native Codex review, **review_independence: same-family; acceptance_status: provisional**. It is not external cross-family peer review or acceptance certification. The requested default reviewer route is gpt-6-astra/ultra; actual returned model/effort identity was not independently exposed to this reviewer and remains unknown. Review session: `/root/aris_full_review`; working directory: `/workspace`. This review covers V3, not a subsequent revision.

## What was independently verified

I read the manuscript source, rendered and visually inspected all seven PDF pages, and opened both original PNG figures. I traced the actual nominal planner, nominal MPC, all additional implemented baseline classes, runner, queue adapter, traffic plant, base environment, and scenario configuration. This was an artifact-grounded review, not acceptance of a prior validation summary.

I independently parsed all 440 original confirmation metadata files and their 440 raw JSONL files, checked their 100-case seed sequences, matched all 44,000 original episode rows against the packaged enriched data, recomputed all 60 aggregate and 240 scenario table cells, and recalculated all 3,440 paired tests and Holm-adjusted p-values. All checked values match. The audit is saved in `RAW_AUDIT.json`, including the explicit list of all 880 original batch files inspected. Its scope is recomputation from saved episode metrics, not reconstruction from trajectories.

The headline results are supported:

| Contrast against LANS-RISK | Corridor contrasts | LANS higher | LANS lower | Holm significant |
|---|---:|---:|---:|---:|
| Nominal MPC | 60 | 9 | 0 | 0 |
| No prediction | 60 | 45 | 0 | 45 |
| No actor | 60 | 0 | 0 | 0 |
| PPO only | 60 | 49 | 0 | 45 |

All three LANS actors and nominal MPC have the stated contiguous passing thresholds: Highway 1,000 ms, Merge 700 ms, Intersection 1,000 ms, Roundabout 500 ms. The 1,000 ms scenario values, tracking-direction claims, and LQR zero-delay 60/400 corridor count also match the raw data. Zero delay makes the queue-prediction removal operationally identical to the full nominal design, as expected.

The nominal LANS equations match the code: split update of speed/heading/position; observed finite-difference NPC acceleration with clipping and damping; roll-out of the pending FIFO; 30-step per-step offset/acceleration representation; three rounds of 192 candidates with five-step shared Gaussian noise; six explicit candidates; 24 elites; the stated dispersion floors; collision-prefix/secondary/cost lexicographic rank; the stated stage and actor costs; and one-step retained-plan shift with geometric-steering/full-brake tail. The special first-step clearance secondary rank is described correctly. The no-actor and no-prediction removals are matched within the scope claimed. The physical FIFO applies to corrective actions as stated.

## Prioritized findings and exact fixes

### F1 — P1: the general observation-matching statement is too broad

**Location:** `paper.tex:41`, and actor specification at `paper.tex:60`, `paper.tex:169`, `paper.tex:240`.

**Evidence:** `experiment.py:48–63` loads an inherited scenario-specific actor and calls `model.predict(obs, deterministic=True)`. The actor receives the base environment's 18-dimensional observation, not `queue_authority.packet(env)`. `lans_env_scenario.py:329–373` supplies clipped tracking errors/rates, speed, applied steering/acceleration, a single critical-NPC summary, NPC count, scenario code, synthetic timing context, beta, and LQR advice. It supplies neither the full surrounding-vehicle state set nor the pending command sequence. In contrast, the model-based supervisor and nominal MPC receive current ego/NPC state and the FIFO via the structured packet. `TrafficEnv.step:85–87` forces direct actuation (`beta=1`, safety disabled), while the next actor observation still contains the inherited synthetic timing/beta features sampled by the parent environment.

This is not hidden future-NPC leakage: the packet does not expose desired NPC speeds. It is an information/representation difference between PPO-only and the planner, and the paper should make it explicit. The nominal LANS–MPC information-matching claim itself is correct. The existing statement that PPO-only tests a bundle is good but insufficiently specific.

**Replace the broad sentence at line 41 with:**

> All evaluated methods share the synthetic plant, initial traffic cases, action bounds and physical FIFO. LANS-RISK and nominal MPC additionally share the full structured state/FIFO packet; the frozen actor uses its inherited compact observation, described below. Remaining planning differences are disclosed in Section V.

**Add a short actor-input/deployment paragraph:**

> Each scenario uses three frozen PPO checkpoints, evaluated deterministically. The actor receives an 18-dimensional legacy observation containing normalized tracking errors and rates, ego speed, previous applied steering and acceleration, one critical-vehicle summary, NPC count, scenario indicators, synthetic timing context, an authority-weight feature and LQR steering advice. It does not receive the full NPC state set or pending FIFO. The synthetic timing feature is not the imposed command delay. During these experiments, the emitted two-component action is interpreted as a direct steering/acceleration proposal; the inherited steering blend and original safety supervisor are bypassed. PPO-only therefore tests deployment of this frozen proposal without the current trajectory supervisor, rather than an independently optimized delay-aware RL baseline with matched information.

The actor feature paragraph may be shortened in the article with the exact ordering/scaling supplied in an explicitly named supplement. Do not add an LQR–PPO actuation-fusion layer to the architecture diagram: there is none in this confirmation path. LQR advice is still an actor input feature.

### F2 — P1: the benchmark and frozen actor are not sufficiently specified in the article

**Location:** Sections III and V, especially `paper.tex:99`, `paper.tex:169`, `paper.tex:175`.

The paper gives the ego predictor and reference curves in considerable detail but omits the target speeds, actual NPC counts, goal predicates, important initialization ranges, and enough traffic dynamics to interpret completion. This matters because the reported delay thresholds are strongly protocol-dependent. The names Highway/Merge/Intersection/Roundabout do not identify a standard benchmark. The roundabout is circular following, not entry/exit negotiation; Intersection actually contains one crossing NPC.

**Source-grounded compact table to add:**

| Scenario | NPCs actually spawned | Common desired speed (m/s) | Ego initial speed (m/s) | Goal predicate |
|---|---:|---:|---|---|
| Highway | 5 | 15 | Uniform [11,15] | At least 80 m forward from initial X |
| Merge | 6 | 12 | Uniform [11,15] | At least 60 m forward and abs(Y) < 1 m |
| Intersection | 1 | 8 | Uniform [6,7.5] | At least 50 m forward from initial X |
| Roundabout | 4 | 9 | Uniform [5.5,7.5] | One unwrapped 2-pi lap about the 8 m circle |

`scenario_config.py` lists nominal_npcs=3 for Intersection, but `_spawn_vehicles` explicitly overrides it to one; report the executed value. Goal attainment does not terminate an episode. The runner accumulates any goal attainment and then requires no collision through collision termination or the 160-step time limit. This should be said explicitly.

**Concise additional text:**

> Surrounding vehicles follow bounded IDM-style longitudinal interactions with maximum acceleration 1.5 m/s², braking clipped at -6 m/s², speed clipped to [0,20] m/s, desired standstill gap 1 m and headway 0.6 s; straight-road headings remain fixed, while circular traffic follows the 8 m route. The predictor extrapolates observed acceleration and does not reproduce the full interaction law. Initial states are rejection sampled to exclude all center separations at or below 6 m and specified close-following configurations; full distributions and predicates are provided in the supplement. Goal attainment is nonterminal, so collision/corridor outcomes cover the remaining episode as well.

For the supplement, specify the actual traffic generation: Highway one nearby ego-lane vehicle and a lane-mixture for others; Merge 80/20 target-lane/ramp mixture; Intersection a north/south crossing with near/far starting-distance mixture; Roundabout approximately even angular spacing with ±0.08 rad perturbations. Include the rejection predicate from `traffic_v2/benchmark.py`, rather than the older base-environment roundabout placement that the subclass overwrites. The corridor is an ego-reference-point diagnostic, not vehicle-footprint road-boundary compliance.

For actor reproducibility, I inspected the plain JSON `data` member of all 12 original checkpoint ZIPs without executing or deserializing their policies. They report 311,296 realized training timesteps each, seeds 42/43/44, network [128,128,64] with ReLU, PPO n_steps=2048, batch_size=64, n_epochs=10, gamma=.995, gae_lambda=.95, clipping .2, entropy coefficient .01, value coefficient .5 and max-gradient norm .5. Learning rate is .00025 for Intersection and .0003 otherwise. The 300,000 nominal budget rounds to full PPO rollouts. State these as checkpoint-recorded properties, and identify inherited training environment/reward provenance separately; do not invent a reconstructed training history from the hyperparameters. Available historical training code uses supervised/blended control, making the deployment caveat in F1 especially relevant, but source code alone does not independently establish every checkpoint's training trajectory.

Provide a concrete supplement/artifact reference. The current paper repeatedly says “companion tables/CSVs” without a discoverable location in the PDF. Existing artifacts can be packaged or linked; do not require a new training run.

### F3 — P2: extend the log-reconstruction limitation beyond RMSE

**Location:** `paper.tex:251`; algorithm lines about logging at `paper.tex:151`, `paper.tex:156`.

The limitation correctly states that per-step trajectories were not saved for independent RMSE reconstruction. The same limitation applies to independent reconstruction of collision detection, goal/corridor flags, actor intervention, actual FIFO history, and specific failure causes. The raw files hold episode labels/scalars; they do not hold every state/action/error. `nominal_lans.py` computes `prefix_violation` and forecast-prefix lengths in its transient `self.log`, but `experiment.py` persists only its accumulated `no_feasible` field, not those prefix diagnostics or a trajectory. Thus one cannot use the saved logs alone to count cold-prefix violations or prove that a particular retained plan prevented a collision. The paper does not currently make such quantitative claims; preserve that restraint.

**Suggested replacement:**

> The saved evidence contains episode-level metrics and binary outcomes, not full state/action trajectories. We can independently recompute aggregate statistics and paired tests from these records and inspect the frozen metric implementation, but cannot reconstruct every episode's RMSE, collision/corridor event, or queue-prefix history from the logs alone. Transient forecast diagnostics are not all persisted.

Also specify that collision detection is disc overlap at sampled 0.1 s states. Do not imply continuous-time collision certification or claim that an actual missed collision was found; this review found no such case.

### F4 — P2: make the scientific contribution and attribution limits explicit

**Location:** introduction contribution paragraph, method framing, Discussion/Conclusion.

The empirical claims are narrower and more credible than a generic learning or safe-control superiority claim. However, the main positive finding—compensating a known input queue is beneficial—is expected from prior predictor control. The actor contributes no observed completion improvement, nominal MPC matches all empirical thresholds, and the differences in representation, objective and fallback prevent assigning any LANS–MPC difference specifically to retention or lexicographic ranking. There is no retention-only removal here. This is a contribution-strength limitation, not proof that the experiments are invalid, and the manuscript already disclaims much of it.

**Add:**

> These results isolate queue rollout and the actor proposal within this implementation. They do not isolate the effects of trajectory retention, lexicographic ranking or the other differences from nominal MPC.

Frame the paper as an empirical characterization and negative-result study of a specified supervisory design, with reproducible matched evidence, rather than a new general safety method. The present title is acceptable if the abstract's negative findings remain prominent. Additional mechanism ablations, matched-information delay-trained RL, or external algorithm reproduction would support broader future claims, but are not tasks for the frozen conference revision and were not run. Wording alone cannot convert the current result into a major general ML algorithm contribution.

### F5 — P2/minor: refine prior-paper metric wording and improve visibility of uncertainty

`paper.tex:41` says the earlier LANS benchmark and “RMSE definition differ.” The uploaded prior manuscript explicitly reports both conventional RMSE and failure-penalized RMSE (e.g. its comparison discussion around extracted lines 476–478). Avoid implying that prior LANS reported only the latter. Prefer: “The benchmarks and failure metrics differ; this article reports unpenalized episode RMSE.” The statement at line 179 distinguishing the present metric from the prior failure-penalized one is otherwise appropriate.

The main paper explains interval methods but reports few actual intervals/effect sizes. At least one compact actor/scenario-specific paired example or an explicitly identified uncertainty table would make the inference assessable without searching thousands of CSV rows. Do not pool shared actor repetitions for a binomial CI, infer equivalence from a degenerate paired bootstrap interval, or add new multiplicity selection. This is a presentation improvement, not a defect in the checked Holm arithmetic.

## Section-by-section assessment

- **Title/abstract:** Accurate scope and unusually candid null findings. The 44,000 count is correctly called records. Consider identifying the synthetic nature earlier in the title/abstract if needed for venue framing. No numerical correction required.
- **Introduction:** The problem and physical inability to cancel queued commands are valid. Novelty is carefully limited. Correct the global observation-matching impression and foreground the empirical contribution.
- **Related work:** The five supplied primary works support the main comparisons: nonlinear PSF with uncertainty/backup assumptions; racing PSF with terminal-set construction and 1:28 hardware demonstration; Kalaria's delay estimator, tube MPC and black-box guarding designs; Cano Córdoba's delayed-observation safety-game shielding; DAROM's encoder/history/delay representation and stopping-distance intervention in SUMO/NGSIM-derived traffic. The distinction between observation delay and physical FIFO is scientifically necessary and is correctly made. Kalaria has separate standalone tube-MPC and learning-controller QP/CBF guarding constructions; a more precise table entry can mention this distinction, but the paper's broad summary is not materially false. No external method is falsely represented as rerun. Independent latest-version metadata checks remain incomplete; see limitations below.
- **Problem formulation:** Ego/prediction equations, queue ordering and geometry match the executed code. Add the actual benchmark endpoints/distributions and actor input distinction. The zero-filled queue is properly disclosed. No theorem is asserted.
- **Method:** The principal equations and candidate selection match source. The retained candidate is correctly distinguished from a safe terminal backup. Proposal influence is limited to one inserted first action and the first-action distance cost, so the lack of broad actor benefit is plausible. No distribution over collision risk is estimated. Define v_ref with scenario values and avoid suggesting that retention's individual benefit was isolated.
- **Experimental protocol:** Frozen actors, paired case seeds, method counts, resource comparison, and post-evaluation analysis selection are clearly stated. The nominal MPC has the same predictor, horizon and candidate count but different block representation, cost, warm start and fallback; the manuscript correctly calls it a multicomponent comparison. The three-scenario robust variants have 96 candidates per round; “robust” is appropriately qualified. Equal candidate counts are not equal runtime. Add F1/F2 details.
- **Statistics:** Wilson intervals per 100-case condition and exact paired-discordance tests are appropriate for the stated conditional binary comparisons. Holm control does not require contrasts to be independent, so shared actors/cases do not invalidate that correction. Wilcoxon location interpretation requires symmetric differences; this is disclosed, and the core significant claims concern binary outcomes. Marginal bootstrap intervals are not simultaneous; three fixed actor seeds do not support training-population inference. I recomputed all tests, but did not regenerate every bootstrap interval. There is no justified equivalence, population collision probability <=1%, or continuous-delay stability conclusion. The manuscript correctly avoids them.
- **Results:** All stated counts and thresholds checked. Tracking direction is scenario-dependent, and early collision termination is appropriately identified as an RMSE caveat. Zero LQR delay is a useful warning that a small RMSE can accompany poor completion. The scenario-specific poor Roundabout/Merge outcomes are not hidden by the narrative. No additional experiment is necessary to report these existing findings honestly.
- **Discussion:** Strong on cold-start authority, finite sampling, absent guarantees, synthetic traffic, actor-seed limits and timing. Extend the saved-log caveat as in F3 and explicitly call the circular case following rather than realistic intersection/roundabout negotiation. The corridor is not a road-footprint safety constraint.
- **Conclusion:** Supported if it remains an empirical design/evidence claim. “Reproducible comparison” should be accompanied by a concrete artifact/supplement pointer and the distinction between recomputable episode statistics and unavailable per-step reconstruction.
- **References/writing:** All 20 bibliography entries are cited in source. The inspected primary texts do not show a substantive mismatch in the five core comparisons. Some references are based on secondary/repository metadata and were not independently verified in full. Avoid “state of the art” implying an exhaustive current search. The writing repeats limitations in multiple places; moving some repetition into a concise limitations paragraph would free space for missing benchmark/actor specifications.

## Figure and PDF review

All seven rendered PDF pages were opened with `tools.view_image`, as were `figures/architecture.png` and `figures/confirmation.png`. The PDF is legible and shows no obvious clipping or missing objects. The table/figure content matches the checked data. Main Figure 2 shows all 12 controllers, each with its own panel, with measured grid-point markers and no shifted outcomes. Connecting lines should be read as visual guides, not unmeasured-delay observations; the table caption correctly says no intermediate delay was measured. At final page size the 12 panels and small tick labels are dense. Tiny collision rates are hard to see on 0–100% axes, so the numerical companion remains essential.

The current architecture is broadly faithful and appropriately avoids inventing an EKF or a runtime LQR–PPO blend. For a revised diagram the essential signals are:

1. Current structured ego/NPC state and observed acceleration estimate to queue prediction, with pending q_t from FIFO.
2. Predicted arrival state/world to sampled rollouts; reference geometry to geometric steering evaluated along each rollout; v_ref to performance cost/cruise construction.
3. Actor observation o_t clearly distinguished from the full state/FIFO packet; frozen actor action to candidate insertion and the first-action distance cost.
4. Retained offset/acceleration plan to candidate generation; the selected full plan back through shift plus braking tail to retention.
5. Selected first command to physical FIFO, applied head command to plant, and current state feedback from plant. For d=0 the newly selected command applies immediately.

A combined sampled-search/ranking supervisor box is legitimate. A diagram arrow labeled only r_k between rollout and ranking can be clarified to include forecast collision/corridor/cost scores. Distinguish feedback of the selected full plan from feedback of only its first action. These are clarity improvements; the current equations resolve the ambiguity.

## Claims boundary and revision plan

| Claim | Status after this review |
|---|---|
| Queue rollout improves corridor outcomes in this matched implementation | Supported by the stated paired contrasts |
| Actor has no observed corridor-rate benefit on this grid | Supported as a finite-sample statement; not universal uselessness |
| LANS and nominal MPC have equal observed grid thresholds | Supported; not statistical equivalence |
| LANS universally improves tracking over MPC | Unsupported and appropriately not claimed |
| Retention/risk-first ranking individually cause the observed gains | Not isolated |
| Collision-free safety, robustness guarantee, or real-time deadline guarantee | Not supported |
| All compared methods consume matched observations | False as a broad statement; valid for the specified model-based pair |
| Every episode metric can be rebuilt from saved trajectories | Not supported; aggregate recomputation from saved labels/scalars is supported |

**Minimum in-scope revision:** correct F1; add the F2 benchmark table and actor/deployment specification; supply an artifact/supplement pointer; expand F3's limitation; state the F4 attribution boundary; and make the minor metric wording correction. All have zero new experimental compute cost. Read-only extraction/recalculation and PDF rebuilding are sufficient. Do not tune controllers, retrain policies, replace cases or add runs to improve the story.

After those changes, the manuscript can be a technically defensible submission candidate for a venue receptive to carefully scoped empirical control studies. Its fit for a high-novelty conference remains uncertain. An acceptance forecast or cross-family PASS would be unwarranted.

## Inspection inventory and limitations

`REVIEW.json` contains the explicit path inventory, with all 880 raw batch paths inherited from `RAW_AUDIT.json`. Principal inspected inputs were:

- Manuscript source/PDF; both primary PNG figures; V3 build source, README, scope note and literature-audit note; packaged episodes, paired tests, aggregate and scenario CSVs.
- All seven requested extended-baseline source files, their protocol, imported traffic-v2 plant, queue packet/FIFO adapter, base environment, scenario configuration and inherited protocol; the statistical-analysis implementation; historical actor-training source and checkpoint metadata.
- The five supplied primary literature text extractions, checked at titles/abstracts and the relevant methods, assumptions, experiments and bibliographic passages. The corresponding original PDFs were opened for their title/page information; they were not exhaustively visually reviewed page by page. The full target manuscript, not all cited literature, received page-by-page visual review.
- The prior author-supplied LANS manuscript text, with particular attention to architecture, FIFO and metric distinctions.

No experiment, policy forward pass, model API, paid service or frozen-file modification was performed. Only review artifacts were written under this review directory. All policies' ZIP `data` metadata were read as JSON, not executed.

Independent live metadata requests to Crossref, the PMLR Leeman page and OpenReview all failed with proxy `403 Forbidden`. No callable general web-search tool was available. Consequently I do not certify exhaustive/latest literature coverage, every secondary citation's metadata, or publication status of the author-supplied prior LANS manuscript. I also did not regenerate every bootstrap interval, inspect every historical training log, verify the historical temporal claim of no confirmation tuning from source files alone, or reconstruct metrics from unavailable per-step trajectories. Those limits do not invalidate the raw-aggregate/test checks reported above.
