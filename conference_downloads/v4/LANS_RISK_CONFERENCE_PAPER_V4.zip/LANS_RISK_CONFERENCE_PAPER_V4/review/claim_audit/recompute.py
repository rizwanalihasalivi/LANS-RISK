from pathlib import Path
import json, re, hashlib, datetime, warnings
from collections import Counter, defaultdict
import numpy as np
import pandas as pd
from scipy.stats import binomtest, wilcoxon, norm

OUT=Path('/workspace/recovery/aris_paper_review/claim_audit')
PAPER=Path('/workspace/recovery/conference_paper_v3')
RAW=Path('/workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation')
FREEZE=RAW.parent/'EXTENDED_FREEZE.json'
INPUTS=[PAPER/'paper.tex',PAPER/'table_delay_grid.tex']+[PAPER/'evidence'/f for f in ['episodes.jsonl','descriptive_metrics.csv','paired_tests.csv','empirical_delay_tolerance.csv','all_controller_delay_table.csv','all_controller_delay_by_scenario.csv']]+sorted(RAW.glob('*.json'))+sorted(RAW.glob('*.jsonl'))+[FREEZE]
hashes={(str(p.relative_to(PAPER)) if p.is_relative_to(PAPER) else str(p)):'sha256:'+hashlib.sha256(p.read_bytes()).hexdigest() for p in INPUTS}
freeze=json.loads(FREEZE.read_text())
paper=(PAPER/'paper.tex').read_text()
table=(PAPER/'table_delay_grid.tex').read_text()
def readcsv(n): return pd.read_csv(PAPER/'evidence'/n,float_precision='round_trip')
episodes=[json.loads(s) for s in (PAPER/'evidence/episodes.jsonl').read_text().splitlines()]
e=pd.DataFrame(episodes)
key=['scenario','controller','actor_seed','delay_ms']
groups={k:g.set_index('episode_seed').sort_index() for k,g in e.groupby(key)}
issues=defaultdict(list)
raw_sources={}
raw_records=[]
for p in sorted(RAW.glob('*.json')):
    s=json.loads(p.read_text()); q=p.with_suffix('.jsonl')
    rows=[json.loads(line) for line in q.read_text().splitlines()]
    k=(s['scenario'],s['controller'],s['policy_seed'],s['delay_ms'])
    raw_sources[k]=str(q)
    g=groups.get(k)
    if g is None: issues['raw_condition_missing'].append(k); continue
    if len(rows)!=s['count'] or len(rows)!=len(g): issues['raw_count'].append(k)
    if [x['episode_seed'] for x in rows]!=list(range(141000,141100)): issues['raw_seeds'].append(k)
    if hashlib.sha256(q.read_bytes()).hexdigest()!=s['raw_sha256']: issues['raw_hash'].append(k)
    for row in rows:
        actual=g.loc[row['episode_seed']]
        for f,v in row.items():
            if f=='episode_seed': continue
            a=actual[f]
            if (v is None and pd.isna(a)) or v==a: continue
            issues['raw_episode_mismatch'].append([*k,row['episode_seed'],f,v,str(a)])
        raw_records.append(dict(row,scenario=k[0],controller=k[1],actor_seed=k[2],delay_ms=k[3]))
    for f,v in s.items():
        if f not in rows[0] or f in ['episode_seed','steps']: continue
        vals=[r[f] for r in rows if r.get(f) is not None]
        actual=np.mean(vals) if vals else np.nan
        if vals and isinstance(vals[0],bool): actual*=100
        if not (np.isnan(actual) and v is None) and not np.isclose(actual,v,atol=1e-12,rtol=1e-12): issues['raw_summary_mismatch'].append([*k,f,v,float(actual)])
r=pd.DataFrame(raw_records)
rg={k:g.set_index('episode_seed').sort_index() for k,g in r.groupby(key)}
if len(episodes)!=len(raw_records): issues['total_raw_records'].append([len(episodes),len(raw_records)])
if e.duplicated(key+['episode_seed']).any(): issues['duplicate_records'].append(int(e.duplicated(key+['episode_seed']).sum()))

des=readcsv('descriptive_metrics.csv')
numeric_fields={'mean':lambda a:np.mean(a),'sample_sd':lambda a:np.std(a,ddof=1),'minimum':lambda a:np.min(a),'maximum':lambda a:np.max(a),'p05':lambda a:np.quantile(a,.05),'median':lambda a:np.quantile(a,.5),'p95':lambda a:np.quantile(a,.95)}
for idx,row in des.iterrows():
    k=tuple(row[c] for c in key); g=rg[k]; a=g[row.metric].dropna().astype(float).to_numpy()
    if not row.available:
        # The exported artifact explicitly excludes a runner default/fixed zero
        # from a scientific measurement; do not turn that exclusion into data.
        if row.metric!='no_feasible_steps' or row.n!=0 or row.ci_method!='Not estimated: unavailable diagnostic' or any(pd.notna(row[f]) for f in numeric_fields): issues['unavailable_diagnostic'].append(int(idx))
        if groups[k].no_feasible_steps_available.any(): issues['availability_flag'].append(int(idx))
        continue
    if row.n!=len(a): issues['descriptive_n'].append([int(idx),int(row.n),len(a)])
    if row.raw_episode_records!=len(g): issues['descriptive_raw_n'].append(int(idx))
    if len(a):
        for f,fn in numeric_fields.items():
            v=float(fn(a))
            if not np.isclose(row[f],v,atol=1e-12,rtol=1e-12): issues['descriptive_'+f].append([int(idx),float(row[f]),v])
        worst=float(a.min() if row.metric in ['completion','corridor_completion','progress'] else a.max())
        if not np.isclose(row.worst_observed,worst,atol=1e-12,rtol=1e-12): issues['descriptive_worst'].append([int(idx),float(row.worst_observed),worst])
        if row.ci_method=='Wilson':
            z=norm.ppf(.975); p=a.mean(); n=len(a); center=(p+z*z/(2*n))/(1+z*z/n); delta=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n)
            for f,v in [('ci95_low',center-delta),('ci95_high',center+delta)]:
                if not np.isclose(row[f],v,atol=1e-12,rtol=1e-12): issues['descriptive_wilson'].append([int(idx),f,float(row[f]),float(v)])
        if pd.notna(row.ci95_low) and (row.ci95_low>row.ci95_high or row.ci95_low<a.min()-1e-12 or row.ci95_high>a.max()+1e-12) and row.ci_method!='Wilson': issues['bootstrap_support'].append(int(idx))

aggregate_results=[]
for name,cols in [('all_controller_delay_table.csv',['controller','delay_ms']),('all_controller_delay_by_scenario.csv',['controller','scenario','delay_ms'])]:
    df=readcsv(name); gg={k:g for k,g in r.groupby(cols)}
    for idx,row in df.iterrows():
        k=tuple(row[c] for c in cols); g=gg[k]
        actual={'n':len(g),'mean_rmse_m':g.rmse.mean(),'route_completed':int(g.completion.sum()),'corridor_completed':int(g.corridor_completion.sum()),'collisions':int(g.collision.sum())}
        for f,v in actual.items():
            if not np.isclose(row[f],v,atol=1e-12,rtol=1e-12): issues['aggregate_mismatch'].append([name,int(idx),f,float(row[f]),float(v)])
        aggregate_results.append(dict(source=name,row=int(idx),key=list(k),actual=actual))

tests=readcsv('paired_tests.csv')
recomputed=[]
for idx,row in tests.iterrows():
    def group(controller):
        k=(row.scenario,controller,row.actor_seed,row.delay_ms)
        return rg[k if k in rg else (row.scenario,controller,0,row.delay_ms)]
    a,b=group(row.a),group(row.b)
    if not a.index.equals(b.index) or len(a)!=row.n: issues['paired_matching'].append(int(idx))
    av=a[row.metric].to_numpy(dtype=float); bv=b[row.metric].to_numpy(dtype=float); diff=av-bv
    if not np.isclose(diff.mean(),row.mean_difference_a_minus_b,atol=1e-12,rtol=1e-12): issues['paired_difference'].append([int(idx),float(row.mean_difference_a_minus_b),float(diff.mean())])
    if row.metric!='rmse':
        at=int(((av==1)&(bv==0)).sum()); bt=int(((av==0)&(bv==1)).sum())
        if row.discordant_a_true!=at or row.discordant_b_true!=bt: issues['paired_discordance'].append([int(idx),at,bt])
        p=binomtest(at,at+bt,.5,alternative='two-sided').pvalue if at+bt else 1.
    else:
        with warnings.catch_warnings():
            warnings.simplefilter('ignore'); p=wilcoxon(av,bv,alternative='two-sided',method='auto').pvalue if np.any(diff) else 1.
    if not np.isclose(p,row.p_raw,atol=1e-30,rtol=1e-10): issues['paired_p_raw'].append([int(idx),float(row.p_raw),float(p)])
    if row.paired_bootstrap95_low>row.paired_bootstrap95_high or row.paired_bootstrap95_low<diff.min()-1e-12 or row.paired_bootstrap95_high>diff.max()+1e-12: issues['paired_bootstrap_support'].append(int(idx))
    recomputed.append(dict(row=int(idx),mean_difference=float(diff.mean()),p=float(p),a_source=raw_sources[(row.scenario,row.a,row.actor_seed if (row.scenario,row.a,row.actor_seed,row.delay_ms) in rg else 0,row.delay_ms)],b_source=raw_sources[(row.scenario,row.b,row.actor_seed if (row.scenario,row.b,row.actor_seed,row.delay_ms) in rg else 0,row.delay_ms)]))
ps=np.array([x['p'] for x in recomputed]); order=np.argsort(ps,kind='stable'); corrected=np.empty(len(ps)); corrected[order]=np.minimum(1,np.maximum.accumulate(ps[order]*(len(ps)-np.arange(len(ps)))))
for idx,p in enumerate(corrected):
    recomputed[idx]['p_holm']=float(p)
    if not np.isclose(p,tests.iloc[idx].p_holm,atol=1e-28,rtol=1e-10): issues['paired_holm'].append([idx,float(tests.iloc[idx].p_holm),float(p)])

threshold=readcsv('empirical_delay_tolerance.csv'); thresholds=[]
for idx,row in threshold.iterrows():
    best=-1; points=[]; still=True
    for delay in [0,200,500,700,1000]:
        k=(row.scenario,row.controller,row.actor_seed,delay); g=rg[k]
        ok=g.collision.mean()<=.01 and g.corridor_completion.mean()>=.90
        points.append(dict(delay_ms=delay,collision=float(g.collision.mean()),corridor_completion=float(g.corridor_completion.mean()),passes=bool(ok)))
        if still and ok: best=delay
        else: still=False
    if not ((best==-1 and pd.isna(row.empirical_contiguous_passing_delay_ms)) or best==row.empirical_contiguous_passing_delay_ms) or (best==1000)!=row.upper_grid_censored: issues['threshold'].append([int(idx),str(row.empirical_contiguous_passing_delay_ms),best])
    thresholds.append(dict(scenario=row.scenario,controller=row.controller,actor_seed=int(row.actor_seed),threshold_ms=None if best==-1 else best,points=points))

names=['lans','mpc_nominal','lqr','lqr_acc','predictor_lqr','ppo_only','cbf','lans_no_prediction','lans_no_actor','robust_lans','robust_mpc','robust_no_actor']
table_cells=[]
for source,tex in [('paper.tex',paper),('table_delay_grid.tex',table)]:
    row_number=0
    for line_no,line in enumerate(tex.splitlines(),1):
        if not re.match(r'^(0|200|500|700|1000) &',line): continue
        parts=line.split('&'); delay=int(parts[0]); block=row_number//5; row_number+=1
        for j,cell in enumerate(parts[1:]):
            match=re.search(r'(\d+\.\d+); (\d+)/(\d+)',cell); mean,numerator,denominator=match.groups(); controller=names[block*6+j]
            g=r[(r.controller==controller)&(r.delay_ms==delay)]
            actual={'rmse':float(g.rmse.mean()),'corridor_completed':int(g.corridor_completion.sum()),'n':len(g)}
            correct=f'{actual["rmse"]:.3f}'==mean and actual['corridor_completed']==int(numerator) and actual['n']==int(denominator)
            if not correct: issues['paper_table'].append([source,line_no,controller,delay,cell,actual])
            table_cells.append(dict(source=source,line=line_no,controller=controller,delay_ms=delay,paper_value=f'{mean}; {numerator}/{denominator}',evidence_value=actual,match=correct,source_files=[v for k,v in raw_sources.items() if k[1]==controller and k[3]==delay]))

contrasts={}
for comparator in ['mpc_nominal','lans_no_prediction','lans_no_actor','ppo_only']:
    ix=tests.index[(tests.a=='lans')&(tests.b==comparator)&(tests.metric=='corridor_completion')].tolist()
    vals=[recomputed[i] for i in ix]
    contrasts[comparator]={'n':len(vals),'positive':sum(v['mean_difference']>0 for v in vals),'negative':sum(v['mean_difference']<0 for v in vals),'zero':sum(v['mean_difference']==0 for v in vals),'positive_significant':sum(v['mean_difference']>0 and v['p_holm']<.05 for v in vals),'negative_significant':sum(v['mean_difference']<0 and v['p_holm']<.05 for v in vals),'max_positive_p_holm':max((v['p_holm'] for v in vals if v['mean_difference']>0),default=None)}

diagnostics={'counts':{'episodes':len(e),'raw_episode_records':len(r),'raw_json_files':len(list(RAW.glob('*.json'))),'raw_jsonl_files':len(list(RAW.glob('*.jsonl'))),'conditions':len(rg),'paired_tests':len(tests),'descriptive_rows':len(des),'table_cells':len(table_cells),'csv_aggregate_rows':len(aggregate_results)},'issues':dict(issues),'contrasts':contrasts,'thresholds':thresholds,'table_cells':table_cells,'aggregate_results':aggregate_results,'recomputed_paired_tests':recomputed,'input_hashes':hashes,'exact_input_paths':[str(p) for p in INPUTS],'freeze_contents_characterization':{'top_level_keys':list(freeze),'source_hash_entry_count':len(freeze['sha256'])},'metadata_uniques':{c:sorted(e[c].unique().tolist()) for c in ['study','stage','stage_status','source_version','profile','scenario','controller','actor_seed','delay_ms']},'raw_field_names':sorted(set().union(*(x.keys() for x in raw_records))), 'versions':{'numpy':np.__version__,'pandas':pd.__version__}}
(OUT/'recomputed_evidence.json').write_text(json.dumps(diagnostics,indent=2))
(OUT/'EXACT_INPUT_SET.json').write_text(json.dumps({'paper_dir':str(PAPER),'exact_input_paths':diagnostics['exact_input_paths'],'audited_input_hashes':hashes},indent=2))
print(json.dumps({'counts':diagnostics['counts'],'issue_counts':{k:len(v) for k,v in issues.items()},'first_issues':{k:v[:3] for k,v in issues.items()},'contrasts':contrasts,'freeze':diagnostics['freeze_contents_characterization']},indent=2))
