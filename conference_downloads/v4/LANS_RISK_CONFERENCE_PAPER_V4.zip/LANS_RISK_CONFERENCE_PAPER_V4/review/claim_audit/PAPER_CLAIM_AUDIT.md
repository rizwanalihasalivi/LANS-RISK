# Paper Claim Audit

**Overall verdict: WARN.** All empirical counts, displayed table values, paired-test results, global Holm adjustments and finite-grid thresholds reconcile with the original 44,000 episode records. WARN is for implementation, training-history, bootstrap provenance, figure and literature claims outside the authorized raw/config scope; no material numeric mismatch was found.

**Review status:** fresh same-family Codex review; provisional. No submission-ready acceptance is implied. HTML rendering disabled.

**Input set:** 889 files; exact paths and SHA256 bindings in `EXACT_INPUT_SET.json` and the audit JSON. Only the declared evidence was read; no prior audits, executor narratives, implementation code, experiments or manuscript changes.

## Scientific findings

| Comparison | Raw paired corridor contrasts | Positive / equal / negative LANS differences | Holm-significant positive |
|---|---:|---:|---:|
| LANS versus mpc_nominal | 60 | 9 / 51 / 0 | 0 |
| LANS versus lans_no_prediction | 60 | 45 / 15 / 0 | 45 |
| LANS versus lans_no_actor | 60 | 0 / 60 / 0 | 0 |
| LANS versus ppo_only | 60 | 49 / 11 / 0 | 45 |

All three LANS actors and nominal MPC pass contiguously through 1,000 ms on Highway and Intersection, 700 ms on Merge, and 500 ms on Roundabout. These are observed grid endpoints, not equivalence findings or population-risk bounds. Zero collisions in 100 cases has a Wilson 95% upper bound of 3.69935%, confirming the paper's 3.7% caution.

At 1,000 ms LANS/MPC corridor rates are Highway 100%/100%, Merge 35%/34%, Intersection 99%/99%, and Roundabout 0%/0%. The paper's RMSE direction reversals against MPC and no-actor are correct. No best-seed substitution, denominator mismatch, cherry-picked correction family, table inflation or case-pairing error was found.

## Verification coverage

- All 44,000 raw episodes match the exported record fields, with 100 traffic seeds 141000–141099 in each of 440 conditions. Five actor-dependent controllers use 42/43/44; seven actor-free controllers use placeholder seed 0.
- All 60 distinct numerical delay-table cells, including all 120 occurrences across both TeX files, use ordinary three-decimal RMSE rounding and exact completion fractions.
- All 300 aggregate CSV rows reconcile in n, RMSE, route completion, corridor completion and collisions.
- All 3,440 paired mean differences, 2,580 exact binary tests, 860 Wilcoxon tests and 3,440 full-family Holm adjustments agree. The tests use exactly matched episode seeds.
- All 88 threshold rows reproduce the contiguous rule, including eight no-passing-point rows.
- All available means, sample SDs, minima/maxima, quantiles and Wilson endpoints in 5,720 descriptive rows reconcile. The 140 explicitly unavailable feasibility diagnostics are correctly left unestimated; their fixed zeros are not counted as measurements.
- Every raw summary file's JSONL hash matches. The freeze manifest contains 51 source/model hash entries, including 12 model archive hashes. This verifies hash retention; excluded source bytes, model bytes and freeze chronology were not certified.

## Scope warnings and concrete follow-up

These are limits of the authorized audit inputs, not detected numerical errors:

1. **Implementation and component matching:** method equations/constants, the physical FIFO and cold start, NPC observation access, nominal resource matching, robust forecast settings and “only this component changed” assertions require executable source/configuration. `EXTENDED_FREEZE.json` contains hashes, not those constants. They are marked `unsupported_by_this_audit_scope`.
2. **Metric provenance:** boolean endpoint relationships agree, but no per-step trajectories exist in the allowed raw files. The 1.75 m event detector and each saved episode RMSE cannot be reconstructed independently.
3. **Bootstrap provenance:** the 5,000-draw label and plausible saved intervals do not expose RNG seeds/draw indices or prove the resampling procedure. Original bootstrap endpoints and draw count remain unverified. Exact paired tests, Holm correction and Wilson intervals do verify.
4. **History and literature:** frozen-training/no-tuning/development-seed claims, post-hoc selection history, external-method non-reproduction and bibliographic claims require evidence outside this scope.
5. **Figures:** the captions' aggregate mappings agree with the data, but figure artwork was not an authorized input; panel styling, shifted curves and architecture arrows were not inspected.

The narrow empirical conclusions are supported: within the labelled experiment, queue-prediction removal is strongly associated with lower completion; actor removal provides no observed completion advantage; nominal MPC matches the delay thresholds. These outcome logs alone do not validate causal isolation, implementation correctness, universal superiority or a safety guarantee.

## Per-claim audit

267 entries: exact_match=37, scope_supported=9, unsupported_by_this_audit_scope=99, rounding_ok=122.

Each numeric table cell has its own entry. Repeated abstract/result/conclusion claims and repeated TeX table cells are counted as separate occurrences. Method equations are grouped by coherent formula or parameter block. Qualitative table cells and algorithm action cells are explicitly covered. Exact source quotes and full provenance are retained in the JSON.

### Claim 1: PASS — paper.tex:10

**Status:** `exact_match`

**Paper:** Commands selected from a current vehicle state can become inappropriate while waiting for delayed execution. This paper investigates a queue-aware, trajectory-retaining supervisor for frozen learned driving policies. LANS-RISK predicts the state reached after pending commands, incorporates a proximal policy optimization proposal into sampled future plans, and ranks plans by predicted collision-free duration, corridor retention, and tracking cost. We report the complete 44,000-record main-confirmation grid across 12 controllers, four synthetic traffic scenarios and five command delays, with focused comparisons against matched nominal MPC, PPO-only and two component removals. LANS-RISK and nominal MPC attain identical observed contiguous passing delay thresholds: 1,000~ms on Highway and Intersection, 700~ms on Merge, and 500~ms on Roundabout. Removing queue prediction reduces corridor completion in 45 of 60 paired actor/scenario/delay contrasts, all significant after the retained study-wide Holm correction. Removing the actor does not change corridor-completion rates on the evaluated grid. Tracking differences against MPC remain scenario-dependent. These findings support queue compensation within this implementation, but do not establish a general advantage of learned proposals, universal superiority over MPC, or a formal safety guarantee.

**Evidence:** {"episodes": 44000, "raw_episode_records": 44000, "raw_json_files": 440, "raw_jsonl_files": 440, "conditions": 440, "paired_tests": 3440, "descriptive_rows": 5720, "table_cells": 120, "csv_aggregate_rows": 300, "controller_names": ["cbf", "lans", "lans_no_actor", "lans_no_prediction", "lqr", "lqr_acc", "mpc_nominal", "ppo_only", "predictor_lqr", "robust_lans", "robust_mpc", "robust_no_actor"], "scenario_names": ["highway", "intersection", "merge", "roundabout"], "delay_ms": [0, 200, 500, 700, 1000]}

**Assessment:** 440 raw JSONL files contain 100 records each, with no duplicate condition/episode keys; all original raw values match the exported episode table.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 2: PASS — paper.tex:10

**Status:** `exact_match`

**Paper:** Commands selected from a current vehicle state can become inappropriate while waiting for delayed execution. This paper investigates a queue-aware, trajectory-retaining supervisor for frozen learned driving policies. LANS-RISK predicts the state reached after pending commands, incorporates a proximal policy optimization proposal into sampled future plans, and ranks plans by predicted collision-free duration, corridor retention, and tracking cost. We report the complete 44,000-record main-confirmation grid across 12 controllers, four synthetic traffic scenarios and five command delays, with focused comparisons against matched nominal MPC, PPO-only and two component removals. LANS-RISK and nominal MPC attain identical observed contiguous passing delay thresholds: 1,000~ms on Highway and Intersection, 700~ms on Merge, and 500~ms on Roundabout. Removing queue prediction reduces corridor completion in 45 of 60 paired actor/scenario/delay contrasts, all significant after the retained study-wide Holm correction. Removing the actor does not change corridor-completion rates on the evaluated grid. Tracking differences against MPC remain scenario-dependent. These findings support queue compensation within this implementation, but do not establish a general advantage of learned proposals, universal superiority over MPC, or a formal safety guarantee.

**Evidence:** [{"scenario": "highway", "controller": "lans", "actor_seed": 42, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 1.0, "passes": true}]}, {"scenario": "highway", "controller": "lans", "actor_seed": 43, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 1.0, "passes": true}]}, {"scenario": "highway", "controller": "lans", "actor_seed": 44, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 1.0, "passes": true}]}, {"scenario": "highway", "controller": "mpc_nominal", "actor_seed": 0, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 1.0, "passes": true}]}, {"scenario": "intersection", "controller": "lans", "actor_seed": 42, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.01, "corridor_completion": 0.99, "passes": true}]}, {"scenario": "intersection", "controller": "lans", "actor_seed": 43, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.01, "corridor_completion": 0.99, "passes": true}]}, {"scenario": "intersection", "controller": "lans", "actor_seed": 44, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.01, "corridor_completion": 0.99, "passes": true}]}, {"scenario": "intersection", "controller": "mpc_nominal", "actor_seed": 0, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.99, "passes": true}]}, {"scenario": "merge", "controller": "lans", "actor_seed": 42, "threshold_ms": 700, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.35, "passes": false}]}, {"scenario": "merge", "controller": "lans", "actor_seed": 43, "threshold_ms": 700, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.35, "passes": false}]}, {"scenario": "merge", "controller": "lans", "actor_seed": 44, "threshold_ms": 700, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.35, "passes": false}]}, {"scenario": "merge", "controller": "mpc_nominal", "actor_seed": 0, "threshold_ms": 700, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.97, "passes": true}, {"delay_ms": 1000, "collision": 0.01, "corridor_completion": 0.34, "passes": false}]}, {"scenario": "roundabout", "controller": "lans", "actor_seed": 42, "threshold_ms": 500, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.24, "passes": false}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.0, "passes": false}]}, {"scenario": "roundabout", "controller": "lans", "actor_seed": 43, "threshold_ms": 500, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.24, "passes": false}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.0, "passes": false}]}, {"scenario": "roundabout", "controller": "lans", "actor_seed": 44, "threshold_ms": 500, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.24, "passes": false}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.0, "passes": false}]}, {"scenario": "roundabout", "controller": "mpc_nominal", "actor_seed": 0, "threshold_ms": 500, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.23, "passes": false}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.0, "passes": false}]}]

**Assessment:** Computed separately for all three LANS actor seeds and nominal MPC, enforcing every lower grid point.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 3: PASS — paper.tex:10

**Status:** `exact_match`

**Paper:** Commands selected from a current vehicle state can become inappropriate while waiting for delayed execution. This paper investigates a queue-aware, trajectory-retaining supervisor for frozen learned driving policies. LANS-RISK predicts the state reached after pending commands, incorporates a proximal policy optimization proposal into sampled future plans, and ranks plans by predicted collision-free duration, corridor retention, and tracking cost. We report the complete 44,000-record main-confirmation grid across 12 controllers, four synthetic traffic scenarios and five command delays, with focused comparisons against matched nominal MPC, PPO-only and two component removals. LANS-RISK and nominal MPC attain identical observed contiguous passing delay thresholds: 1,000~ms on Highway and Intersection, 700~ms on Merge, and 500~ms on Roundabout. Removing queue prediction reduces corridor completion in 45 of 60 paired actor/scenario/delay contrasts, all significant after the retained study-wide Holm correction. Removing the actor does not change corridor-completion rates on the evaluated grid. Tracking differences against MPC remain scenario-dependent. These findings support queue compensation within this implementation, but do not establish a general advantage of learned proposals, universal superiority over MPC, or a formal safety guarantee.

**Evidence:** {"n": 60, "positive": 45, "negative": 0, "zero": 15, "positive_significant": 45, "negative_significant": 0, "max_positive_p_holm": 0.0002608299255371094}

**Assessment:** 

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 4: PASS — paper.tex:10

**Status:** `exact_match`

**Paper:** Commands selected from a current vehicle state can become inappropriate while waiting for delayed execution. This paper investigates a queue-aware, trajectory-retaining supervisor for frozen learned driving policies. LANS-RISK predicts the state reached after pending commands, incorporates a proximal policy optimization proposal into sampled future plans, and ranks plans by predicted collision-free duration, corridor retention, and tracking cost. We report the complete 44,000-record main-confirmation grid across 12 controllers, four synthetic traffic scenarios and five command delays, with focused comparisons against matched nominal MPC, PPO-only and two component removals. LANS-RISK and nominal MPC attain identical observed contiguous passing delay thresholds: 1,000~ms on Highway and Intersection, 700~ms on Merge, and 500~ms on Roundabout. Removing queue prediction reduces corridor completion in 45 of 60 paired actor/scenario/delay contrasts, all significant after the retained study-wide Holm correction. Removing the actor does not change corridor-completion rates on the evaluated grid. Tracking differences against MPC remain scenario-dependent. These findings support queue compensation within this implementation, but do not establish a general advantage of learned proposals, universal superiority over MPC, or a formal safety guarantee.

**Evidence:** {"n": 60, "positive": 0, "negative": 0, "zero": 60, "positive_significant": 0, "negative_significant": 0, "max_positive_p_holm": null}

**Assessment:** 

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 5: PASS — paper.tex:10

**Status:** `exact_match`

**Paper:** Commands selected from a current vehicle state can become inappropriate while waiting for delayed execution. This paper investigates a queue-aware, trajectory-retaining supervisor for frozen learned driving policies. LANS-RISK predicts the state reached after pending commands, incorporates a proximal policy optimization proposal into sampled future plans, and ranks plans by predicted collision-free duration, corridor retention, and tracking cost. We report the complete 44,000-record main-confirmation grid across 12 controllers, four synthetic traffic scenarios and five command delays, with focused comparisons against matched nominal MPC, PPO-only and two component removals. LANS-RISK and nominal MPC attain identical observed contiguous passing delay thresholds: 1,000~ms on Highway and Intersection, 700~ms on Merge, and 500~ms on Roundabout. Removing queue prediction reduces corridor completion in 45 of 60 paired actor/scenario/delay contrasts, all significant after the retained study-wide Holm correction. Removing the actor does not change corridor-completion rates on the evaluated grid. Tracking differences against MPC remain scenario-dependent. These findings support queue compensation within this implementation, but do not establish a general advantage of learned proposals, universal superiority over MPC, or a formal safety guarantee.

**Evidence:** {"lans": {"highway": {"n": 300, "rmse": 0.07981345629686774, "collision": 0.0, "corridor_completion": 1.0}, "intersection": {"n": 300, "rmse": 0.04268431355082067, "collision": 0.01, "corridor_completion": 0.99}, "merge": {"n": 300, "rmse": 0.3780779859167268, "collision": 0.0, "corridor_completion": 0.35}, "roundabout": {"n": 300, "rmse": 0.9273620814106418, "collision": 0.0, "corridor_completion": 0.0}}, "mpc_nominal": {"highway": {"n": 100, "rmse": 0.02542576593307875, "collision": 0.0, "corridor_completion": 1.0}, "intersection": {"n": 100, "rmse": 0.03093134880496795, "collision": 0.0, "corridor_completion": 0.99}, "merge": {"n": 100, "rmse": 0.41620760163203213, "collision": 0.01, "corridor_completion": 0.34}, "roundabout": {"n": 100, "rmse": 0.939072099350991, "collision": 0.0, "corridor_completion": 0.0}}}

**Assessment:** At 1,000 ms the mean-RMSE direction reverses across scenarios; the text makes no universal ranking.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 6: PASS — paper.tex:10

**Status:** `scope_supported`

**Paper:** Commands selected from a current vehicle state can become inappropriate while waiting for delayed execution. This paper investigates a queue-aware, trajectory-retaining supervisor for frozen learned driving policies. LANS-RISK predicts the state reached after pending commands, incorporates a proximal policy optimization proposal into sampled future plans, and ranks plans by predicted collision-free duration, corridor retention, and tracking cost. We report the complete 44,000-record main-confirmation grid across 12 controllers, four synthetic traffic scenarios and five command delays, with focused comparisons against matched nominal MPC, PPO-only and two component removals. LANS-RISK and nominal MPC attain identical observed contiguous passing delay thresholds: 1,000~ms on Highway and Intersection, 700~ms on Merge, and 500~ms on Roundabout. Removing queue prediction reduces corridor completion in 45 of 60 paired actor/scenario/delay contrasts, all significant after the retained study-wide Holm correction. Removing the actor does not change corridor-completion rates on the evaluated grid. Tracking differences against MPC remain scenario-dependent. These findings support queue compensation within this implementation, but do not establish a general advantage of learned proposals, universal superiority over MPC, or a formal safety guarantee.

**Evidence:** "Equal observed completion rates versus actor removal, equal finite-grid thresholds versus MPC, scenario-dependent RMSE, and finite empirical records"

**Assessment:** This is an appropriately limited empirical conclusion. Audit does not certify implementation correctness or safety.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 7: WARN — paper.tex:10

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Commands selected from a current vehicle state can become inappropriate while waiting for delayed execution. This paper investigates a queue-aware, trajectory-retaining supervisor for frozen learned driving policies. LANS-RISK predicts the state reached after pending commands, incorporates a proximal policy optimization proposal into sampled future plans, and ranks plans by predicted collision-free duration, corridor retention, and tracking cost. We report the complete 44,000-record main-confirmation grid across 12 controllers, four synthetic traffic scenarios and five command delays, with focused comparisons against matched nominal MPC, PPO-only and two component removals. LANS-RISK and nominal MPC attain identical observed contiguous passing delay thresholds: 1,000~ms on Highway and Intersection, 700~ms on Merge, and 500~ms on Roundabout. Removing queue prediction reduces corridor completion in 45 of 60 paired actor/scenario/delay contrasts, all significant after the retained study-wide Holm correction. Removing the actor does not change corridor-completion rates on the evaluated grid. Tracking differences against MPC remain scenario-dependent. These findings support queue compensation within this implementation, but do not establish a general advantage of learned proposals, universal superiority over MPC, or a formal safety guarantee.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 8: WARN — paper.tex:17

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Autonomous-driving control decisions are often evaluated as if the selected action were applied immediately. With a physical command queue, the vehicle instead continues to execute previously issued commands. A corrective action based only on the measured state can therefore address a state that no longer exists when the command reaches the plant. Nearby traffic also evolves during this interval. Delay compensation must consequently be evaluated together with collision outcomes, task completion, and tracking, rather than inferred from a controller's decision time alone.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 9: WARN — paper.tex:19

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Delay-aware control and supervision of learning-enabled controllers are established research directions. Kalaria \emph{et al.} combine delay handling with robust tube MPC and discuss a protective role for a learning-enabled primary controller~\cite{kalaria}. Predictive safety filtering also provides a principled framework for modifying a learned action under specified model and feasibility assumptions~\cite{psf}. These precedents rule out a broad claim that predicting through delay or guarding a learned policy is itself new.

**Evidence:** null

**Assessment:** No external publications, earlier manuscript, implementation files, or experiment-history logs were included. This includes the 1:28 vehicle claim, May 2026 version, 2 s claim, non-reproduction assertions, and all relative mechanism comparisons where applicable.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 10: WARN — paper.tex:21

**Status:** `unsupported_by_this_audit_scope`

**Paper:** The author-supplied LANS path-tracking manuscript~\cite{paperone} studies analytical feedback with optional PPO steering residuals, packet-age handling, and implementation-specific supervision. The present study addresses a different question: how does a trajectory-level supervisor perform in interacting synthetic traffic when all commands, including corrective commands, pass through the same actuation FIFO? The current implementation combines existing model-based and learning-based elements. Its contribution is a specific design and a controlled examination of its benefits and limitations, not a new PPO optimization algorithm or a certified safety-filter theory.

**Evidence:** null

**Assessment:** No external publications, earlier manuscript, implementation files, or experiment-history logs were included. This includes the 1:28 vehicle claim, May 2026 version, 2 s claim, non-reproduction assertions, and all relative mechanism comparisons where applicable.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 11: WARN — paper.tex:29

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Learning-based MPC combines prediction and optimization with learned components~\cite{hewing}; safe-learning surveys distinguish empirical constraint handling from guarantees that depend on a model, uncertainty description, and safe backup~\cite{brunke}. Wabersich and Zeilinger~\cite{psf} formulate a predictive safety filter for constrained nonlinear systems with state/input-dependent model uncertainty. Tearle \emph{et al.}~\cite{tearle} specialize predictive filtering to racing: an invariant terminal set and backup trajectories support track-boundary safety, demonstrated on a 1:28-scale vehicle. Leeman \emph{et al.}~\cite{sls} use system-level synthesis to enlarge certified safe sets for linear systems with bounded disturbances.

**Evidence:** null

**Assessment:** No external publications, earlier manuscript, implementation files, or experiment-history logs were included. This includes the 1:28 vehicle claim, May 2026 version, 2 s claim, non-reproduction assertions, and all relative mechanism comparisons where applicable.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 12: WARN — paper.tex:31

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Input latency is also addressed through sampled-data control barrier functions~\cite{cbfdelay}. Cano C\'ordoba \emph{et al.}~\cite{cano} synthesize delay-resilient shields from safety games under worst-case observation-delay assumptions, with CARLA and gridworld demonstrations. These guarantees concern their formal abstractions and assumptions. LANS-RISK instead ranks finitely sampled forecasts and retains a candidate trajectory; it has neither a winning-strategy certificate nor a certified terminal safe set.

**Evidence:** null

**Assessment:** No external publications, earlier manuscript, implementation files, or experiment-history logs were included. This includes the 1:28 vehicle claim, May 2026 version, 2 s claim, non-reproduction assertions, and all relative mechanism comparisons where applicable.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 13: WARN — paper.tex:34

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Kalaria \emph{et al.}~\cite{kalaria} address computation/processing delay and steering dynamics with adaptive delay estimation and robust tube MPC, including a guard for a learning-enabled controller. Our fixed, known FIFO isolates delayed command execution and does not reproduce their adaptive estimator or robust tube construction.

**Evidence:** null

**Assessment:** No external publications, earlier manuscript, implementation files, or experiment-history logs were included. This includes the 1:28 vehicle claim, May 2026 version, 2 s claim, non-reproduction assertions, and all relative mechanism comparisons where applicable.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 14: WARN — paper.tex:36

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Recent RL work emphasizes reconstructing useful information from delayed signals. Wang \emph{et al.}~\cite{wang} study delayed-observation MDPs and delay-aware training/representation strategies in continuous robotic control. Wu \emph{et al.}~\cite{dfbt} directly forecast beliefs for delayed RL. Random-delay RL~\cite{rlrd} provides another formulation for delayed interactions. These methods change the learned representation or training process; the current LANS-RISK confirmation uses already frozen actors.

**Evidence:** null

**Assessment:** No external publications, earlier manuscript, implementation files, or experiment-history logs were included. This includes the 1:28 vehicle claim, May 2026 version, 2 s claim, non-reproduction assertions, and all relative mechanism comparisons where applicable.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 15: WARN — paper.tex:38

**Status:** `unsupported_by_this_audit_scope`

**Paper:** The supplied May 2026 version of DAROM~\cite{darom} is particularly relevant to highway merging. It combines delayed observations, masked action histories, and observed delay magnitude in an encoder, and adds a stopping-distance safety controller. It evaluates stochastic V2I observation delays in SUMO using NGSIM-derived traffic parameters. Its reported success under delays up to 2~s is not directly comparable with our corridor-completion endpoint under a physical action FIFO. Earlier on-ramp studies combine RL with MPC~\cite{lubars} or probabilistic barrier functions~\cite{udatha}. Their existence also precludes claiming that combining learning and model-based supervision is itself new.

**Evidence:** null

**Assessment:** No external publications, earlier manuscript, implementation files, or experiment-history logs were included. This includes the 1:28 vehicle claim, May 2026 version, 2 s claim, non-reproduction assertions, and all relative mechanism comparisons where applicable.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 16: WARN — paper.tex:41

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Table~\ref{tab:literature} compares mechanisms and evidence, not numerical rankings across incompatible benchmarks. The cited approaches were not rerun in our simulator. The experimentally evaluated controllers are listed in Section V; none is a reproduction of the external literature methods. Following the motivation for unified safe-control benchmarking~\cite{yuan}, we match plant, observations, action limits and important planning resources, and disclose remaining differences. Relative to the earlier LANS path-tracking manuscript~\cite{paperone}, the present work studies steering/acceleration trajectories and surrounding-vehicle clearance under a shared physical FIFO. Its benchmark and RMSE definition differ.

**Evidence:** null

**Assessment:** No external publications, earlier manuscript, implementation files, or experiment-history logs were included. This includes the 1:28 vehicle claim, May 2026 version, 2 s claim, non-reproduction assertions, and all relative mechanism comparisons where applicable.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 17: WARN — paper.tex:23

**Status:** `unsupported_by_this_audit_scope`

**Paper:** We study \lans{}, a supervisor that rolls out the pending queue, retains a shifted previous trajectory, and includes a frozen PPO proposal as a prior in sampled trajectory search. Candidate selection first favors a longer predicted collision-free prefix, then corridor retention, and finally a weighted performance objective. This ordering is intended to distinguish collision-related recovery from a simple tracking-error penalty, while remaining an approximate forecast.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 18: PASS — paper.tex:25

**Status:** `scope_supported`

**Paper:** The conference contribution is deliberately focused: (i) an executable queue-aware trajectory-selection design with explicit information and actuation assumptions; (ii) a paired comparison with nominal MPC and PPO-only control; and (iii) matched removals of queue prediction and the actor proposal. A complete 12-controller delay table retains every main-confirmation case. Plant/traffic perturbations, stochastic observation delays and dedicated runtime evaluations remain outside this article.

**Evidence:** {"study": ["extended_baselines"], "stage": ["confirmation"], "stage_status": ["complete"], "source_version": ["original_frozen"], "profile": ["fixed_fifo"], "scenario": ["highway", "intersection", "merge", "roundabout"], "controller": ["cbf", "lans", "lans_no_actor", "lans_no_prediction", "lqr", "lqr_acc", "mpc_nominal", "ppo_only", "predictor_lqr", "robust_lans", "robust_mpc", "robust_no_actor"], "actor_seed": [0, 42, 43, 44], "delay_ms": [0, 200, 500, 700, 1000]}

**Assessment:** All allowed episode records are labelled extended_baselines / confirmation / original_frozen / fixed_fifo; complete raw grid is retained. This confirms the reported input scope, not absence of other studies.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 19: WARN — paper.tex:44

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \caption{Related state-of-the-art approaches and LANS-RISK: qualitative mechanism comparison. Literature results are author-reported in different settings; no external method was rerun or ranked against LANS-RISK. ``Guarantee'' refers to the cited model assumptions, not unconditional real-world safety.}

**Evidence:** null

**Assessment:** Cited publications and external implementation histories are outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 20: WARN — paper.tex:48, literature table cell 1

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Nonlinear PSF~\cite{psf} (2021)

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 21: WARN — paper.tex:48, literature table cell 2

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Model uncertainty; not our fixed FIFO protocol

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 22: WARN — paper.tex:48, literature table cell 3

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Predictive constraints and safe backup under stated uncertainty assumptions

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 23: WARN — paper.tex:48, literature table cell 4

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Nonlinear constrained systems; certificate differs from sampled ranking\\

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 24: WARN — paper.tex:49, literature table cell 1

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Racing PSF~\cite{tearle} (2021)

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 25: WARN — paper.tex:49, literature table cell 2

**Status:** `unsupported_by_this_audit_scope`

**Paper:** State-feedback racing control

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 26: WARN — paper.tex:49, literature table cell 3

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Invariant terminal set; backup trajectories; track constraints

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 27: WARN — paper.tex:49, literature table cell 4

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Physical miniature vehicle; no matched traffic/FIFO experiment\\

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 28: WARN — paper.tex:50, literature table cell 1

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Delay-aware tube MPC~\cite{kalaria} (2022 preprint)

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 29: WARN — paper.tex:50, literature table cell 2

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Estimated computation/processing delay; steering dynamics

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 30: WARN — paper.tex:50, literature table cell 3

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Adaptive delay estimator and robust tube MPC

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 31: WARN — paper.tex:50, literature table cell 4

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Driving/racing; richer delay model than a known queue\\

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 32: WARN — paper.tex:51, literature table cell 1

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Delayed shielding~\cite{cano} (2023)

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 33: WARN — paper.tex:51, literature table cell 2

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Worst-case bounded observation delay

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 34: WARN — paper.tex:51, literature table cell 3

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Safety-game synthesis and delay-resilient winning strategies

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 35: WARN — paper.tex:51, literature table cell 4

**Status:** `unsupported_by_this_audit_scope`

**Paper:** CARLA and gridworld; discrete formal abstraction\\

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 36: WARN — paper.tex:52, literature table cell 1

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Signal-delay RL~\cite{wang} (2024); DFBT~\cite{dfbt} (2025)

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 37: WARN — paper.tex:52, literature table cell 2

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Delayed observations / delayed RL information

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 38: WARN — paper.tex:52, literature table cell 3

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Delay-aware representation/training or belief forecasting

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 39: WARN — paper.tex:52, literature table cell 4

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Continuous robotic control; not a matched driving safety comparison\\

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 40: WARN — paper.tex:53, literature table cell 1

**Status:** `unsupported_by_this_audit_scope`

**Paper:** DAROM~\cite{darom} (2026 version)

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 41: WARN — paper.tex:53, literature table cell 2

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Stochastic V2I observation delay

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 42: WARN — paper.tex:53, literature table cell 3

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Learned encoder plus stopping-distance intervention

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 43: WARN — paper.tex:53, literature table cell 4

**Status:** `unsupported_by_this_audit_scope`

**Paper:** SUMO/NGSIM-based merging; task success differs from corridor completion\\

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 44: PASS — paper.tex:54, literature table cell 1

**Status:** `exact_match`

**Paper:** LANS-RISK (this work)

**Evidence:** "lans controller in every scenario/delay/actor condition"

**Assessment:** Controller label maps to the main result files.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 45: WARN — paper.tex:54, literature table cell 2

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Known physical FIFO, 0--1,000~ms

**Evidence:** {"recorded_profile": "fixed_fifo", "delay_ms": [0, 200, 500, 700, 1000]}

**Assessment:** Recorded profile and delay values agree; physical queue semantics require excluded source code.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 46: WARN — paper.tex:54, literature table cell 3

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Queue rollout, frozen PPO prior, retained plans, lexicographic forecast ranking; no certificate

**Evidence:** null

**Assessment:** External source or executable method evidence is outside the allowed input set.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 47: WARN — paper.tex:54, literature table cell 4

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Four synthetic scenarios; paired main confirmation and component removals\\\bottomrule

**Evidence:** {"scenarios": ["highway", "intersection", "merge", "roundabout"], "comparisons": {"mpc_nominal": {"n": 60, "positive": 9, "negative": 0, "zero": 51, "positive_significant": 0, "negative_significant": 0, "max_positive_p_holm": 1.0}, "lans_no_prediction": {"n": 60, "positive": 45, "negative": 0, "zero": 15, "positive_significant": 45, "negative_significant": 0, "max_positive_p_holm": 0.0002608299255371094}, "lans_no_actor": {"n": 60, "positive": 0, "negative": 0, "zero": 60, "positive_significant": 0, "negative_significant": 0, "max_positive_p_holm": null}, "ppo_only": {"n": 60, "positive": 49, "negative": 0, "zero": 11, "positive_significant": 45, "negative_significant": 0, "max_positive_p_holm": 1.0}}}

**Assessment:** Four scenario names and paired component-labelled conditions agree; synthetic plant implementation and one-component-only removals require excluded source.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 48: WARN — paper.tex:60

**Status:** `unsupported_by_this_audit_scope`

**Paper:** At control time $t$, the ego state is $x_t=(X_t,Y_t,\psi_t,v_t)$, containing planar position, heading, and speed. Surrounding-vehicle observations are $z_t=\{(X_t^i,Y_t^i,\psi_t^i,v_t^i)\}_{i=1}^{n_t}$. The controller receives structured state and the pending command queue, but not hidden NPC desired speeds. A frozen PPO policy~\cite{ppo} proposes $u_t^\pi=\pi_\theta(o_t)$ from its policy observation $o_t$. No actor parameters change during confirmation.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 49: WARN — paper.tex:62

**Status:** `unsupported_by_this_audit_scope`

**Paper:** The normalized command $u_t=(\eta_t,\alpha_t)\in[-1,1]^2$ scales to steering angle $\delta_t=0.5\eta_t$ rad and acceleration $a_t=3.5\alpha_t$ m/s$^2$. The prediction model uses wheelbase $L=2.6$~m and step $\Delta t=0.1$~s. For an applied command $(\eta,\alpha)$, its explicit update is \begin{align}  v^+&=\operatorname{clip}(v+3.5\alpha\Delta t,0,25),\\  \psi^+&=\operatorname{wrap}(\psi+v^+\tan(0.5\eta)\Delta t/L),\\  X^+&=X+v^+\cos(\psi^+)\Delta t,\quad  Y^+=Y+v^+\sin(\psi^+)\Delta t. \end{align}

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 50: WARN — paper.tex:69

**Status:** `unsupported_by_this_audit_scope`

**Paper:** These equations describe the implemented ego rollout. The synthetic plant also evolves interacting NPCs, whose true future actions need not match the predictor.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 51: WARN — paper.tex:71

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Highway and Intersection use a straight reference. Merge uses a quintic lateral transition, $Y_r=-3.5+3.5(10\xi^3-15\xi^4+6\xi^5)$ with $\xi=\operatorname{clip}(X/25,0,1)$. Roundabout uses a circle of radius 8~m. Let $e_y$, $e_\psi$ and $\kappa$ denote the implemented lateral error, wrapped reference-heading error and reference curvature. The geometric steering prior is

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 52: WARN — paper.tex:73

**Status:** `unsupported_by_this_audit_scope`

**Paper:**  \delta_g(x)&=\arctan(L\kappa)-0.4e_y-1.2(e_\psi+0.05v\kappa),\\  \eta_g(x)&=\operatorname{clip}(\delta_g(x)/0.5,-1,1). \end{align} The lateral error is $Y-Y_r(X)$ on the noncircular references and $8-\sqrt{X^2+Y^2}$ on the circle. Thus the method's corridor test is tied to explicit reference geometry.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 53: WARN — paper.tex:79

**Status:** `unsupported_by_this_audit_scope`

**Paper:** For $d>0$, write the commands awaiting execution as $q_t=(q_t^0,\ldots,q_t^{d-1})$, oldest first. The plant applies $q_t^0$ and appends the newly selected $u_t$: \begin{align}  x_{t+1}&=F(x_t,z_t,q_t^0),\\  q_{t+1}&=(q_t^1,\ldots,q_t^{d-1},u_t). \end{align} For $d=0$, $u_t$ acts immediately. All methods use the same zero-filled initial FIFO, so the first $d$ applied commands are initialization commands. The tested $d\in\{0,2,5,7,10\}$ corresponds to 0, 200, 500, 700, and 1,000~ms. A supervisory correction also enters the FIFO; it cannot replace already queued commands. This physical restriction differs from a delay-free safety override.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 54: WARN — paper.tex:87

**Status:** `unsupported_by_this_audit_scope`

**Paper:** The observer estimates NPC acceleration from consecutive observed speeds: \begin{equation}  \hat a_t^i=\operatorname{clip}((v_t^i-v_{t-1}^i)/\Delta t,-6,1.5), \end{equation} using zero on the first observation. During rollout, predicted NPC speed is clipped to $[0,20]$~m/s, and its acceleration estimate is multiplied by 0.85 after each step. NPC heading remains fixed outside the roundabout; on the roundabout, predicted motion follows the 8~m circle. This is an observable forecast, not access to the traffic simulator's hidden intentions.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 55: WARN — paper.tex:93

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Starting from $(\hat x^0,\hat z^0)=(x_t,z_t)$, the supervisor propagates every pending command: \begin{equation}  (\hat x^{j+1},\hat z^{j+1})=\hat F(\hat x^j,\hat z^j,q_t^j),\quad 0\leq j<d. \end{equation} The resulting $(\bar x_t,\bar z_t)=(\hat x^d,\hat z^d)$ initializes the future-action search. At each predicted step, minimum disc clearance is $c=\min_i\|(X,Y)-(X^i,Y^i)\|_2-4.846$~m. The queue prefix is flagged if $c<0.25$~m or $|e_y|>1.75$~m. A prefix violation is a diagnostic of already committed commands, not a proof that the next action can recover safety.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 56: WARN — paper.tex:99

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Episodes last at most 160 steps (16~s). Initial scenes satisfy rejection-sampling predicates excluding specified overlaps and close-following configurations; those predicates do not certify that every task is solvable. The benchmark is synthetic and does not establish road-vehicle validity.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 57: WARN — paper.tex:103

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \caption{LANS-RISK framework. Observation and pending-command processing feed a predicted arrival state to trajectory search. The frozen PPO prior and retained plan are candidates, while the lexicographic score determines selection. The selected command enters the same physical FIFO as every baseline ($d=0$ applies it immediately). Solid arrows carry state/actions; dashed arrows supply queue/reference information or update the retained plan. The feedback path returns structured observations. The architecture uses an observed-acceleration predictor; it does not contain an EKF or an LQR--PPO fusion layer.}

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 58: WARN — paper.tex:109

**Status:** `unsupported_by_this_audit_scope`

**Paper:** A candidate $k$ is a sequence $r_k=\{(b_{k,h},\alpha_{k,h})\}_{h=0}^{H-1}$ with $H=30$. At each predicted state, it generates \begin{equation}  u_{k,h}=\left(\operatorname{clip}(\eta_g(\hat x_{k,h})+b_{k,h},-1,1),\alpha_{k,h}\right). \end{equation} The offset $b_{k,h}$ permits geometric steering to adapt along a trajectory. The actor provides a first-action prior; it does not increase the common desired-speed reference $v_{\mathrm{ref}}$.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 59: WARN — paper.tex:115

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Each of three rounds samples $K=192$ plans around a per-step mean. Gaussian perturbations are shared within five-step blocks, but the mean has one value per step. All plan entries are clipped to $[-1,1]$. Six explicit candidates replace the first sampled plans: the current mean, cruise, full brake, actor prior, retained previous plan, and best-so-far plan. Cruise uses $b_h=0$ and $\alpha_h=\operatorname{clip}((v_{\mathrm{ref}}-\bar v_t)/3.5,-1,1)$; brake uses $(b_h,\alpha_h)=(0,-1)$. The actor-prior plan replaces the cruise plan's first pair with $(\operatorname{clip}(u^\pi_{t,1}-\eta_g(\bar x_t),-1,1),u^\pi_{t,2})$.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 60: WARN — paper.tex:117

**Status:** `unsupported_by_this_audit_scope`

**Paper:** The first decision starts its mean at cruise and its retained candidate at brake. Later decisions use the shifted previous plan. Initial sampling standard deviations are $(0.18,0.65)$ per step; the best 24 plans update the mean and standard deviation, with floors $(0.015,0.08)$. Thus the search evaluates 576 candidate rollouts per decision, although explicit candidates may repeat. This is sampled optimization, not an exhaustive feasibility solver.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 61: WARN — paper.tex:120

**Status:** `unsupported_by_this_audit_scope`

**Paper:** For steps $h=0,\ldots,H-1$, $c_{k,h}$ and $e_{k,h}$ are evaluated after propagation. Define the first forecast violations \begin{align}  h_c(k)&=\min\big(\{h:c_{k,h}<0.25\}\cup\{H\}\big),\\  h_e(k)&=\min\big(\{h:|e_{k,h}|>1.75\}\cup\{H\}\big),\\  s_k&=\begin{cases}c_{k,0},&h_c(k)=0,\\h_e(k),&h_c(k)>0.\end{cases} \end{align} Selection lexicographically maximizes $(h_c(k),s_k,-J_k)$. A longer predicted collision-free prefix therefore takes precedence over corridor retention and tracking cost. When every sampled plan predicts a first-step collision-margin violation, first-step clearance replaces corridor duration as the secondary rank.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 62: WARN — paper.tex:128

**Status:** `unsupported_by_this_audit_scope`

**Paper:** The implemented stage cost is explicitly \begin{align}  \ell_{k,h}={}&8e_y^2+2e_\psi^2+0.2(v-v_{\mathrm{ref}})^2\nonumber\\  &+0.03(\eta^2+\alpha^2)+10\max(0,1-c)^2\nonumber\\  &+\mathbf{1}_{m<0}(10^6+10^5m^2),\\  m={}&\min(c-0.25,1.75-|e_y|),\\  J_k={}&\sum_{h=0}^{H-1}\ell_{k,h}        +0.5\|u_{k,0}-u_t^\pi\|_2^2.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 63: WARN — paper.tex:137

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Variables in $\ell_{k,h}$ refer to the propagated candidate state and normalized command. These weights are frozen implementation constants, not values selected on confirmation cases. The large penalty and lexicographic rank express operational priorities; neither turns the sampled forecast into a collision-probability estimate or a safety certificate.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 64: WARN — paper.tex:140

**Status:** `unsupported_by_this_audit_scope`

**Paper:** The best plan across the three rounds supplies only its first command. For the next decision, the stored candidate is \begin{equation}  r_{t+1}^{\mathrm{retained}}=(r_{t,1}^*,\ldots,r_{t,H-1}^*,(0,-1)). \end{equation} The tail means geometric steering with full braking, not zero physical steering. All returned commands pass through the physical FIFO. Re-evaluation at the next observation can select a different plan. Retention therefore preserves a candidate, not a recursively feasible backup; prediction error and the uncertified braking tail prevent importing the terminal-set guarantees of~\cite{psf,tearle}. Algorithm 1 (Table~\ref{tab:algorithm}) summarizes the actual decision sequence.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 65: WARN — paper.tex:161

**Status:** `unsupported_by_this_audit_scope`

**Paper:** The no-prediction variant skips only the internal queue rollout; the real FIFO, actor and search remain active. The no-actor variant uses the analytical cruise proposal and sets the actor-distance weight to zero, retaining prediction, ranking and plan retention. PPO-only removes the complete supervisor. Accordingly, the first two are component removals, whereas the PPO-only contrast tests a bundle. No removal establishes a claim about all prediction methods or all learned policies.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 66: WARN — paper.tex:167

**Status:** `unsupported_by_this_audit_scope`

**Paper:** LQR variants use analytical feedback; predictor LQR adds queue prediction. Delay CBF filters the PPO proposal using numerical braking-distance constraints. The three ``robust'' variants sample three NPC-acceleration forecasts (nominal and $\pm1$~m/s$^2$ offsets before clipping), with 96 candidates per round. Robust MPC removes the actor and exact retained-trajectory handover; robust no actor preserves that handover. The label ``robust'' denotes this implemented scenario construction, not a formal robust-control guarantee. These variants do not share the nominal pair's full sampling budget.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 67: WARN — paper.tex:172

**Status:** `unsupported_by_this_audit_scope`

**Paper:** The nominal MPC shares the plant, structured state information, physical FIFO, action bounds, reference-speed ceiling, observed-acceleration predictor, 30-step horizon, and three rounds of 192 candidates. It uses a block-parameterized plan and its own cost ranking, warm start, and fallback. LANS-RISK differs in actor use, trajectory retention/representation, and ranking/objective details. Thus, the comparison matches important resources and information but is not a one-variable algorithmic ablation. Equal candidate counts also do not establish equal runtime; no computational superiority claim is made here.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 68: WARN — paper.tex:175

**Status:** `unsupported_by_this_audit_scope`

**Paper:** A collision is an event anywhere in the recorded episode. Route completion requires reaching the goal and remaining collision-free for the episode. Corridor completion additionally requires $|e_t|\leq1.75$~m at every recorded step. Episode tracking error is \begin{equation}  {\rm RMSE}=\sqrt{\frac{1}{T}\sum_{t=1}^{T}e_t^2}. \end{equation} This is conventional episode RMSE, not the failure-penalized metric in the supplied LANS path-tracking manuscript. Since collisions can shorten an episode, RMSE is interpreted together with collision and completion outcomes.

**Evidence:** null

**Assessment:** Episode outcome logs and the hash-only freeze manifest do not encode this implementation detail; executable source/configuration is excluded from this audit.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 69: PASS — paper.tex:84

**Status:** `exact_match`

**Paper:** For $d=0$, $u_t$ acts immediately. All methods use the same zero-filled initial FIFO, so the first $d$ applied commands are initialization commands. The tested $d\in\{0,2,5,7,10\}$ corresponds to 0, 200, 500, 700, and 1,000~ms. A supervisory correction also enters the FIFO; it cannot replace already queued commands. This physical restriction differs from a delay-free safety override.

**Evidence:** [0, 200, 500, 700, 1000]

**Assessment:** The recorded millisecond grid agrees. Multiplying stated d by stated 0.1 s is arithmetically correct; dt and actual queue length are not stored in the outcome logs.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 70: PASS — paper.tex:99

**Status:** `exact_match`

**Paper:** Episodes last at most 160 steps (16~s). Initial scenes satisfy rejection-sampling predicates excluding specified overlaps and close-following configurations; those predicates do not certify that every task is solvable. The benchmark is synthetic and does not establish road-vehicle validity.

**Evidence:** {"min_steps": 14, "max_steps": 160, "records": 44000}

**Assessment:** Every saved episode has at most 160 steps; no per-step trajectory reconstruction is possible.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 71: WARN — paper.tex:99

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Episodes last at most 160 steps (16~s). Initial scenes satisfy rejection-sampling predicates excluding specified overlaps and close-following configurations; those predicates do not certify that every task is solvable. The benchmark is synthetic and does not establish road-vehicle validity.

**Evidence:** null

**Assessment:** 160 × stated 0.1 s = 16 s is internally correct, but the physical time step is not encoded in the allowed raw/config files.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 72: PASS — paper.tex:117

**Status:** `exact_match`

**Paper:** The first decision starts its mean at cruise and its retained candidate at brake. Later decisions use the shifted previous plan. Initial sampling standard deviations are $(0.18,0.65)$ per step; the best 24 plans update the mean and standard deviation, with floors $(0.015,0.08)$. Thus the search evaluates 576 candidate rollouts per decision, although explicit candidates may repeat. This is sampled optimization, not an exhaustive feasibility solver.

**Evidence:** {"arithmetic": 576}

**Assessment:** Arithmetic only; actual candidate evaluation counts are not recorded. The implementation claim is separately marked unsupported.

**Provenance:** paper.tex

### Claim 73: WARN — paper.tex:150

**Status:** `unsupported_by_this_audit_scope`

**Paper:** &\textbf{Inputs:} observed state, FIFO $q_t$, PPO action $u_t^\pi$, retained plan.\\\midrule

**Evidence:** null

**Assessment:** Algorithm operations, 3 rounds, 192 candidates, 6 explicit candidates, 30 steps, 24 elites and retained tail cannot be independently recovered from episode summary records.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 74: WARN — paper.tex:151

**Status:** `unsupported_by_this_audit_scope`

**Paper:** 1&Estimate NPC acceleration; roll out $q_t$ to $(\bar x_t,\bar z_t)$; log prefix violations.\\

**Evidence:** null

**Assessment:** Algorithm operations, 3 rounds, 192 candidates, 6 explicit candidates, 30 steps, 24 elites and retained tail cannot be independently recovered from episode summary records.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 75: WARN — paper.tex:152

**Status:** `unsupported_by_this_audit_scope`

**Paper:** 2&Construct cruise, brake, actor-prior and retained candidates; initialize mean and dispersion.\\

**Evidence:** null

**Assessment:** Algorithm operations, 3 rounds, 192 candidates, 6 explicit candidates, 30 steps, 24 elites and retained tail cannot be independently recovered from episode summary records.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 76: WARN — paper.tex:153

**Status:** `unsupported_by_this_audit_scope`

**Paper:** 3&For three rounds: draw 192 plans, insert six explicit candidates, and propagate 30 steps.\\

**Evidence:** null

**Assessment:** Algorithm operations, 3 rounds, 192 candidates, 6 explicit candidates, 30 steps, 24 elites and retained tail cannot be independently recovered from episode summary records.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 77: WARN — paper.tex:154

**Status:** `unsupported_by_this_audit_scope`

**Paper:** 4&Compute $(h_c,s,-J)$; retain the best plan across rounds. Refit the sampling distribution to 24 elites.\\

**Evidence:** null

**Assessment:** Algorithm operations, 3 rounds, 192 candidates, 6 explicit candidates, 30 steps, 24 elites and retained tail cannot be independently recovered from episode summary records.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 78: WARN — paper.tex:155

**Status:** `unsupported_by_this_audit_scope`

**Paper:** 5&Return the selected first action to the physical FIFO. Shift the selected plan and append $(0,-1)$.\\

**Evidence:** null

**Assessment:** Algorithm operations, 3 rounds, 192 candidates, 6 explicit candidates, 30 steps, 24 elites and retained tail cannot be independently recovered from episode summary records.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 79: WARN — paper.tex:156

**Status:** `unsupported_by_this_audit_scope`

**Paper:** 6&Log forecast collision/corridor violations; repeat at the next observation.\\\bottomrule

**Evidence:** null

**Assessment:** Algorithm operations, 3 rounds, 192 candidates, 6 explicit candidates, 30 steps, 24 elites and retained tail cannot be independently recovered from episode summary records.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 80: PASS — paper.tex:165

**Status:** `exact_match`

**Paper:** The main confirmation contains 12 controllers on four scenarios and delays of 0, 200, 500, 700 and 1,000~ms. The core comparison uses LANS-RISK, nominal MPC, PPO-only, no prediction and no actor. The full delay table also includes standalone LQR, LQR with adaptive cruise control (ACC), predictor LQR, a numerical delay-CBF filter, robust LANS, robust MPC and robust no actor. These are the project's implemented baselines, not reproductions of the cited external algorithms.

**Evidence:** {"study": ["extended_baselines"], "stage": ["confirmation"], "stage_status": ["complete"], "source_version": ["original_frozen"], "profile": ["fixed_fifo"], "scenario": ["highway", "intersection", "merge", "roundabout"], "controller": ["cbf", "lans", "lans_no_actor", "lans_no_prediction", "lqr", "lqr_acc", "mpc_nominal", "ppo_only", "predictor_lqr", "robust_lans", "robust_mpc", "robust_no_actor"], "actor_seed": [0, 42, 43, 44], "delay_ms": [0, 200, 500, 700, 1000]}

**Assessment:** All 12 names occur on all four scenarios and all five delays.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 81: PASS — paper.tex:169

**Status:** `exact_match`

**Paper:** Policies are loaded with Stable-Baselines3~\cite{sb3}. Five actor-dependent variants use frozen seeds 42/43/44, and seven actor-free variants run once per condition. Each uses the same 100 traffic seeds, 141000--141099, yielding $4\times5\times(5\times3+7)\times100=44{,}000$ records in 440 conditions. Repeated actors reuse cases; the records are not independent pooled replicates. Development seeds are disjoint. No confirmation retraining or tuning occurred. This article uses only the original main protocol, not the separate dense-Merge robustness amendment. The full-table presentation and focused contrasts were selected after evaluation and are not a separately preregistered analysis.

**Evidence:** {"actors_by_controller": {"cbf": [42, 43, 44], "lans": [42, 43, 44], "lans_no_actor": [0], "lans_no_prediction": [42, 43, 44], "lqr": [0], "lqr_acc": [0], "mpc_nominal": [0], "ppo_only": [42, 43, 44], "predictor_lqr": [0], "robust_lans": [42, 43, 44], "robust_mpc": [0], "robust_no_actor": [0]}, "all_440_conditions_exact_seed_set": true, "arithmetic": 44000}

**Assessment:** Matched case sets verified in every raw file; actor-free seed 0 is a metadata placeholder and not a trained actor.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 82: PASS — paper.tex:169

**Status:** `scope_supported`

**Paper:** Policies are loaded with Stable-Baselines3~\cite{sb3}. Five actor-dependent variants use frozen seeds 42/43/44, and seven actor-free variants run once per condition. Each uses the same 100 traffic seeds, 141000--141099, yielding $4\times5\times(5\times3+7)\times100=44{,}000$ records in 440 conditions. Repeated actors reuse cases; the records are not independent pooled replicates. Development seeds are disjoint. No confirmation retraining or tuning occurred. This article uses only the original main protocol, not the separate dense-Merge robustness amendment. The full-table presentation and focused contrasts were selected after evaluation and are not a separately preregistered analysis.

**Evidence:** {"unique_episode_seed_labels": 100, "records": 44000, "each_condition_same_seed_set": true}

**Assessment:** Only 100 traffic-seed labels per scenario; actor repeats reuse them. Statistical tests use within-condition pairing.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 83: WARN — paper.tex:169

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Policies are loaded with Stable-Baselines3~\cite{sb3}. Five actor-dependent variants use frozen seeds 42/43/44, and seven actor-free variants run once per condition. Each uses the same 100 traffic seeds, 141000--141099, yielding $4\times5\times(5\times3+7)\times100=44{,}000$ records in 440 conditions. Repeated actors reuse cases; the records are not independent pooled replicates. Development seeds are disjoint. No confirmation retraining or tuning occurred. This article uses only the original main protocol, not the separate dense-Merge robustness amendment. The full-table presentation and focused contrasts were selected after evaluation and are not a separately preregistered analysis.

**Evidence:** null

**Assessment:** Raw logs identify policy seed and a common source hash. The freeze manifest lists 12 model archive hashes but neither model loading nor unchanged training parameters can be checked without excluded code/checkpoints/history.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 84: WARN — paper.tex:169

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Policies are loaded with Stable-Baselines3~\cite{sb3}. Five actor-dependent variants use frozen seeds 42/43/44, and seven actor-free variants run once per condition. Each uses the same 100 traffic seeds, 141000--141099, yielding $4\times5\times(5\times3+7)\times100=44{,}000$ records in 440 conditions. Repeated actors reuse cases; the records are not independent pooled replicates. Development seeds are disjoint. No confirmation retraining or tuning occurred. This article uses only the original main protocol, not the separate dense-Merge robustness amendment. The full-table presentation and focused contrasts were selected after evaluation and are not a separately preregistered analysis.

**Evidence:** null

**Assessment:** No development logs, training records, timestamps of protocol decisions, or parameter history are permitted inputs.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 85: WARN — paper.tex:169

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Policies are loaded with Stable-Baselines3~\cite{sb3}. Five actor-dependent variants use frozen seeds 42/43/44, and seven actor-free variants run once per condition. Each uses the same 100 traffic seeds, 141000--141099, yielding $4\times5\times(5\times3+7)\times100=44{,}000$ records in 440 conditions. Repeated actors reuse cases; the records are not independent pooled replicates. Development seeds are disjoint. No confirmation retraining or tuning occurred. This article uses only the original main protocol, not the separate dense-Merge robustness amendment. The full-table presentation and focused contrasts were selected after evaluation and are not a separately preregistered analysis.

**Evidence:** null

**Assessment:** Analysis-selection timing and preregistration history are not encoded in raw results.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 86: WARN — paper.tex:169

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Policies are loaded with Stable-Baselines3~\cite{sb3}. Five actor-dependent variants use frozen seeds 42/43/44, and seven actor-free variants run once per condition. Each uses the same 100 traffic seeds, 141000--141099, yielding $4\times5\times(5\times3+7)\times100=44{,}000$ records in 440 conditions. Repeated actors reuse cases; the records are not independent pooled replicates. Development seeds are disjoint. No confirmation retraining or tuning occurred. This article uses only the original main protocol, not the separate dense-Merge robustness amendment. The full-table presentation and focused contrasts were selected after evaluation and are not a separately preregistered analysis.

**Evidence:** null

**Assessment:** All exported records label original_frozen/fixed_fifo and match the allowed original confirmation files; independent provenance of amendment exclusions is not available beyond this complete allowed grid.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 87: PASS — paper.tex:175

**Status:** `exact_match`

**Paper:** A collision is an event anywhere in the recorded episode. Route completion requires reaching the goal and remaining collision-free for the episode. Corridor completion additionally requires $|e_t|\leq1.75$~m at every recorded step. Episode tracking error is

**Evidence:** {"route_completion_with_collision": 0, "corridor_boolean_inconsistencies": 0}

**Assessment:** Boolean relationships are consistent in every saved episode; physical event/threshold detection requires excluded trajectories or metric implementation.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 88: PASS — paper.tex:179

**Status:** `exact_match`

**Paper:** This is conventional episode RMSE, not the failure-penalized metric in the supplied LANS path-tracking manuscript. Since collisions can shorten an episode, RMSE is interpreted together with collision and completion outcomes.

**Evidence:** {"shortened_episodes": 4350, "shortened_and_collision": 4350}

**Assessment:** All 4,350 recorded episodes shorter than 160 steps are flagged collision.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 89: PASS — paper.tex:181

**Status:** `exact_match`

**Paper:** To avoid treating repeated runs or selected aggregate scores as conclusive RL evidence~\cite{agarwal}, actor-level inference and paired traffic cases are preserved. Binary rate uncertainty uses per-condition Wilson 95\% intervals. Supported continuous-mean and paired-difference intervals use 5,000 traffic-case bootstrap draws. Binary comparisons use exact paired-discordance tests; RMSE uses two-sided Wilcoxon signed-rank tests with the usual symmetry assumption for a location interpretation. We retain Holm correction~\cite{holm} over all 3,440 contrasts/outcomes in the parent main-confirmation analysis, including comparisons not discussed individually here. Correction is not recomputed on a favorable selected subset. Actor-seed results remain separate for inference. The full delay table and figure pool records only for descriptive display. Each scenario contributes equally; actor-free denominators are 400 per delay and actor-dependent denominators are 1,200. Inference remains within actor/scenario conditions.

**Evidence:** {"binary_conditions": 2200, "confidence": 0.95, "recomputation_mismatches": 0}

**Assessment:** All five binary metrics × 440 conditions recomputed using z=Phi^-1(0.975).

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl, evidence/descriptive_metrics.csv

### Claim 90: WARN — paper.tex:181

**Status:** `unsupported_by_this_audit_scope`

**Paper:** To avoid treating repeated runs or selected aggregate scores as conclusive RL evidence~\cite{agarwal}, actor-level inference and paired traffic cases are preserved. Binary rate uncertainty uses per-condition Wilson 95\% intervals. Supported continuous-mean and paired-difference intervals use 5,000 traffic-case bootstrap draws. Binary comparisons use exact paired-discordance tests; RMSE uses two-sided Wilcoxon signed-rank tests with the usual symmetry assumption for a location interpretation. We retain Holm correction~\cite{holm} over all 3,440 contrasts/outcomes in the parent main-confirmation analysis, including comparisons not discussed individually here. Correction is not recomputed on a favorable selected subset. Actor-seed results remain separate for inference. The full delay table and figure pool records only for descriptive display. Each scenario contributes equally; actor-free denominators are 400 per delay and actor-dependent denominators are 1,200. Inference remains within actor/scenario conditions.

**Evidence:** null

**Assessment:** CSV labels assert 5,000 draws for continuous means, and saved endpoints lie within possible resample supports. RNG seeds, draw indices and generation implementation are not allowed inputs, so the original 5,000-draw count, traffic-case resampling procedure and exact bootstrap endpoints cannot be independently reconstructed.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 91: PASS — paper.tex:181

**Status:** `exact_match`

**Paper:** To avoid treating repeated runs or selected aggregate scores as conclusive RL evidence~\cite{agarwal}, actor-level inference and paired traffic cases are preserved. Binary rate uncertainty uses per-condition Wilson 95\% intervals. Supported continuous-mean and paired-difference intervals use 5,000 traffic-case bootstrap draws. Binary comparisons use exact paired-discordance tests; RMSE uses two-sided Wilcoxon signed-rank tests with the usual symmetry assumption for a location interpretation. We retain Holm correction~\cite{holm} over all 3,440 contrasts/outcomes in the parent main-confirmation analysis, including comparisons not discussed individually here. Correction is not recomputed on a favorable selected subset. Actor-seed results remain separate for inference. The full delay table and figure pool records only for descriptive display. Each scenario contributes equally; actor-free denominators are 400 per delay and actor-dependent denominators are 1,200. Inference remains within actor/scenario conditions.

**Evidence:** {"paired_outcomes": 3440, "binary_exact_tests": 2580, "rmse_wilcoxon_tests": 860, "matched_cases_per_test": 100, "raw_p_mismatches": 0}

**Assessment:** Recomputed every difference, discordance count and p-value directly from sorted raw episode-seed pairs; zero-difference RMSE comparisons receive p=1.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl, evidence/paired_tests.csv

### Claim 92: PASS — paper.tex:181

**Status:** `exact_match`

**Paper:** To avoid treating repeated runs or selected aggregate scores as conclusive RL evidence~\cite{agarwal}, actor-level inference and paired traffic cases are preserved. Binary rate uncertainty uses per-condition Wilson 95\% intervals. Supported continuous-mean and paired-difference intervals use 5,000 traffic-case bootstrap draws. Binary comparisons use exact paired-discordance tests; RMSE uses two-sided Wilcoxon signed-rank tests with the usual symmetry assumption for a location interpretation. We retain Holm correction~\cite{holm} over all 3,440 contrasts/outcomes in the parent main-confirmation analysis, including comparisons not discussed individually here. Correction is not recomputed on a favorable selected subset. Actor-seed results remain separate for inference. The full delay table and figure pool records only for descriptive display. Each scenario contributes equally; actor-free denominators are 400 per delay and actor-dependent denominators are 1,200. Inference remains within actor/scenario conditions.

**Evidence:** {"family_size": 3440, "unique_rows": 3440, "metric_counts": {"collision": 860, "completion": 860, "corridor_completion": 860, "rmse": 860}, "comparison_pairs": 15, "global_holm_mismatches": 0}

**Assessment:** Sorted all independently recomputed p-values, multiplied by remaining family size, applied running maximum and clipped to 1. Every saved p_holm agrees. This validates the supplied 3,440-row family, not a historical assertion that no other unprovided analyses were performed.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl, evidence/paired_tests.csv

### Claim 93: PASS — paper.tex:181

**Status:** `exact_match`

**Paper:** To avoid treating repeated runs or selected aggregate scores as conclusive RL evidence~\cite{agarwal}, actor-level inference and paired traffic cases are preserved. Binary rate uncertainty uses per-condition Wilson 95\% intervals. Supported continuous-mean and paired-difference intervals use 5,000 traffic-case bootstrap draws. Binary comparisons use exact paired-discordance tests; RMSE uses two-sided Wilcoxon signed-rank tests with the usual symmetry assumption for a location interpretation. We retain Holm correction~\cite{holm} over all 3,440 contrasts/outcomes in the parent main-confirmation analysis, including comparisons not discussed individually here. Correction is not recomputed on a favorable selected subset. Actor-seed results remain separate for inference. The full delay table and figure pool records only for descriptive display. Each scenario contributes equally; actor-free denominators are 400 per delay and actor-dependent denominators are 1,200. Inference remains within actor/scenario conditions.

**Evidence:** {"all_tests_n": 100, "per_scenario_actor_free": 100, "per_scenario_actor_dependent": 300, "per_delay_actor_free": 400, "per_delay_actor_dependent": 1200}

**Assessment:** The paired table never pools actor seeds; the descriptive grand means equal equally weighted scenario/actor condition means.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 94: PASS — paper.tex:183

**Status:** `exact_match`

**Paper:** The empirical delay threshold is the largest tested delay for which collision rate is at most 1\% and corridor completion is at least 90\% at that delay and every lower grid point. It is a finite-grid endpoint, not a continuous-delay stability bound. A passing value of 1,000~ms is right-censored by the tested grid. Even zero observed collisions in 100 cases has a Wilson 95\% upper bound near 3.7\%, so passing does not establish a population collision probability below 1\%.

**Evidence:** {"all_threshold_rows": 88, "recomputed_mismatches": 0, "no_passing_grid_point": 8}

**Assessment:** Recomputed every scenario/controller/actor threshold from raw binary counts. Blank threshold cells correctly mean no passing tested point.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl, evidence/empirical_delay_tolerance.csv

### Claim 95: PASS — paper.tex:183

**Status:** `rounding_ok`

**Paper:** The empirical delay threshold is the largest tested delay for which collision rate is at most 1\% and corridor completion is at least 90\% at that delay and every lower grid point. It is a finite-grid endpoint, not a continuous-delay stability bound. A passing value of 1,000~ms is right-censored by the tested grid. Even zero observed collisions in 100 cases has a Wilson 95\% upper bound near 3.7\%, so passing does not establish a population collision probability below 1\%.

**Evidence:** 3.699349820698568

**Assessment:** 3.699349820698568% rounds conventionally to 3.7%; the 1% empirical pass criterion is not a 95% population-risk guarantee.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl, evidence/descriptive_metrics.csv

### Claim 96: PASS — paper.tex:187

**Status:** `exact_match`

**Paper:** \caption{All 12 controllers across the five tested command delays. Each panel isolates one controller; colored solid curves show corridor completion and black dashed curves show collisions. Rates are descriptive record averages over four scenarios and available actors, matching Table~\ref{tab:delaygrid}. No outcomes are shifted. Scenario-specific failures and uncertainty remain in the companion tables and CSVs.}

**Evidence:** {"controllers": 12, "delays": 5, "scenarios": 4, "rates_recomputed": true}

**Assessment:** The data described by the caption match the complete aggregate CSVs. Figure artwork itself is separately outside scope.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 97: WARN — paper.tex:187

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \caption{All 12 controllers across the five tested command delays. Each panel isolates one controller; colored solid curves show corridor completion and black dashed curves show collisions. Rates are descriptive record averages over four scenarios and available actors, matching Table~\ref{tab:delaygrid}. No outcomes are shifted. Scenario-specific failures and uncertainty remain in the companion tables and CSVs.}

**Evidence:** null

**Assessment:** The figure PDF/PNG is not an allowed audit input. Only the caption/data mapping can be checked, not the rendered artwork.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 98: PASS — paper.tex:193

**Status:** `exact_match`

**Paper:** All three LANS-RISK actors and nominal MPC attain the same observed contiguous passing thresholds: Highway 1,000~ms, Merge 700~ms, Intersection 1,000~ms, and Roundabout 500~ms. No delay-threshold advantage is established. Table~\ref{tab:delaygrid} reports every tested delay, and Fig.~\ref{fig:confirmation} shows all controller profiles. Identical thresholds should not be read as statistical equivalence or identical episode trajectories.

**Evidence:** [{"scenario": "highway", "controller": "lans", "actor_seed": 42, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 1.0, "passes": true}]}, {"scenario": "highway", "controller": "lans", "actor_seed": 43, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 1.0, "passes": true}]}, {"scenario": "highway", "controller": "lans", "actor_seed": 44, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 1.0, "passes": true}]}, {"scenario": "highway", "controller": "mpc_nominal", "actor_seed": 0, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 1.0, "passes": true}]}, {"scenario": "intersection", "controller": "lans", "actor_seed": 42, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.01, "corridor_completion": 0.99, "passes": true}]}, {"scenario": "intersection", "controller": "lans", "actor_seed": 43, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.01, "corridor_completion": 0.99, "passes": true}]}, {"scenario": "intersection", "controller": "lans", "actor_seed": 44, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.01, "corridor_completion": 0.99, "passes": true}]}, {"scenario": "intersection", "controller": "mpc_nominal", "actor_seed": 0, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.99, "passes": true}]}, {"scenario": "merge", "controller": "lans", "actor_seed": 42, "threshold_ms": 700, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.35, "passes": false}]}, {"scenario": "merge", "controller": "lans", "actor_seed": 43, "threshold_ms": 700, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.35, "passes": false}]}, {"scenario": "merge", "controller": "lans", "actor_seed": 44, "threshold_ms": 700, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.35, "passes": false}]}, {"scenario": "merge", "controller": "mpc_nominal", "actor_seed": 0, "threshold_ms": 700, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.97, "passes": true}, {"delay_ms": 1000, "collision": 0.01, "corridor_completion": 0.34, "passes": false}]}, {"scenario": "roundabout", "controller": "lans", "actor_seed": 42, "threshold_ms": 500, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.24, "passes": false}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.0, "passes": false}]}, {"scenario": "roundabout", "controller": "lans", "actor_seed": 43, "threshold_ms": 500, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.24, "passes": false}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.0, "passes": false}]}, {"scenario": "roundabout", "controller": "lans", "actor_seed": 44, "threshold_ms": 500, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.24, "passes": false}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.0, "passes": false}]}, {"scenario": "roundabout", "controller": "mpc_nominal", "actor_seed": 0, "threshold_ms": 500, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.23, "passes": false}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.0, "passes": false}]}]

**Assessment:** All three LANS actor seeds and nominal MPC independently yield these contiguous thresholds; equal thresholds do not establish statistical equivalence.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 99: PASS — paper.tex:195

**Status:** `exact_match`

**Paper:** At 1,000~ms, both methods complete the corridor in all Highway cases, while their actor-mean corridor rates are 35\% versus 34\% on Merge, 99\% versus 99\% on Intersection, and zero for both on Roundabout (scenario-specific companion tables). LANS-RISK has lower mean RMSE on Merge and Roundabout, while MPC has lower mean RMSE on Highway and Intersection. These descriptive differences do not support a universal tracking winner. In particular, a small RMSE advantage on a scenario with poor corridor completion is not evidence that the task was successfully solved.

**Evidence:** {"lans": {"highway": {"n": 300, "rmse": 0.07981345629686774, "collision": 0.0, "corridor_completion": 1.0}, "intersection": {"n": 300, "rmse": 0.04268431355082067, "collision": 0.01, "corridor_completion": 0.99}, "merge": {"n": 300, "rmse": 0.3780779859167268, "collision": 0.0, "corridor_completion": 0.35}, "roundabout": {"n": 300, "rmse": 0.9273620814106418, "collision": 0.0, "corridor_completion": 0.0}}, "mpc_nominal": {"highway": {"n": 100, "rmse": 0.02542576593307875, "collision": 0.0, "corridor_completion": 1.0}, "intersection": {"n": 100, "rmse": 0.03093134880496795, "collision": 0.0, "corridor_completion": 0.99}, "merge": {"n": 100, "rmse": 0.41620760163203213, "collision": 0.01, "corridor_completion": 0.34}, "roundabout": {"n": 100, "rmse": 0.939072099350991, "collision": 0.0, "corridor_completion": 0.0}}}

**Assessment:** Equal-sized actor groups make the raw record mean equal the actor mean; rates are exact percentages.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 100: PASS — paper.tex:195

**Status:** `exact_match`

**Paper:** At 1,000~ms, both methods complete the corridor in all Highway cases, while their actor-mean corridor rates are 35\% versus 34\% on Merge, 99\% versus 99\% on Intersection, and zero for both on Roundabout (scenario-specific companion tables). LANS-RISK has lower mean RMSE on Merge and Roundabout, while MPC has lower mean RMSE on Highway and Intersection. These descriptive differences do not support a universal tracking winner. In particular, a small RMSE advantage on a scenario with poor corridor completion is not evidence that the task was successfully solved.

**Evidence:** {"lans": {"highway": {"n": 300, "rmse": 0.07981345629686774, "collision": 0.0, "corridor_completion": 1.0}, "intersection": {"n": 300, "rmse": 0.04268431355082067, "collision": 0.01, "corridor_completion": 0.99}, "merge": {"n": 300, "rmse": 0.3780779859167268, "collision": 0.0, "corridor_completion": 0.35}, "roundabout": {"n": 300, "rmse": 0.9273620814106418, "collision": 0.0, "corridor_completion": 0.0}}, "mpc_nominal": {"highway": {"n": 100, "rmse": 0.02542576593307875, "collision": 0.0, "corridor_completion": 1.0}, "intersection": {"n": 100, "rmse": 0.03093134880496795, "collision": 0.0, "corridor_completion": 0.99}, "merge": {"n": 100, "rmse": 0.41620760163203213, "collision": 0.01, "corridor_completion": 0.34}, "roundabout": {"n": 100, "rmse": 0.939072099350991, "collision": 0.0, "corridor_completion": 0.0}}}

**Assessment:** All four stated comparison directions hold at the explicitly introduced 1,000 ms endpoint.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 101: PASS — paper.tex:197

**Status:** `rounding_ok`

**Paper:** The full-grid table also exposes weak baselines: LQR has only 60/400 corridor completions at zero delay despite a mean RMSE of 0.039~m. Early collision termination can produce deceptively small tracking errors; Fig.~\ref{fig:confirmation} therefore retains collisions alongside completion.

**Evidence:** {"completed": 60, "n": 400, "mean_rmse_m": 0.039186699094463824}

**Assessment:** The pooled mean is conventionally rounded to three decimal places; this is not a best-seed statistic.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 102: PASS — paper.tex:197

**Status:** `scope_supported`

**Paper:** The full-grid table also exposes weak baselines: LQR has only 60/400 corridor completions at zero delay despite a mean RMSE of 0.039~m. Early collision termination can produce deceptively small tracking errors; Fig.~\ref{fig:confirmation} therefore retains collisions alongside completion.

**Evidence:** {"zero_delay_lqr_collisions": 340, "mean_steps_in_colliding_lqr_episodes": 28.020588235294117, "mean_rmse_in_colliding_lqr_episodes": 0.04610199893466332}

**Assessment:** This is appropriately phrased as a possibility, corroborated by small logged errors in short failed episodes; no causal reanalysis of per-step errors was possible.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 103: PASS — paper.tex:199

**Status:** `exact_match`

**Paper:** Across the 60 per-actor/scenario/delay LANS--MPC corridor-completion contrasts, nine have a positive LANS-minus-MPC mean difference, none has a negative mean difference, and none is significant after the retained study-wide Holm correction. Absence of significance is not a non-inferiority or equivalence result. We did not specify an equivalence margin or conduct a dedicated equivalence design.

**Evidence:** {"n": 60, "positive": 9, "negative": 0, "zero": 51, "positive_significant": 0, "negative_significant": 0, "max_positive_p_holm": 1.0}

**Assessment:** Counts use independent raw recomputation plus the full 3,440-outcome Holm family.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 104: WARN — paper.tex:199

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Across the 60 per-actor/scenario/delay LANS--MPC corridor-completion contrasts, nine have a positive LANS-minus-MPC mean difference, none has a negative mean difference, and none is significant after the retained study-wide Holm correction. Absence of significance is not a non-inferiority or equivalence result. We did not specify an equivalence margin or conduct a dedicated equivalence design.

**Evidence:** null

**Assessment:** The manuscript contains no margin, but absence of a historical design cannot be established from the allowed results alone. The statistical caution is sound.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 105: PASS — paper.tex:208

**Status:** `exact_match`

**Paper:** \caption{Tracking performance and corridor completion over all tested command delays (0--1,000~ms). Each cell is mean episode RMSE (m); corridor-completed/total records, aggregated over four scenarios. Corridor completion requires route completion, no collision and no corridor excursion. Actor-dependent columns contain 1,200 records per delay; actor-free columns contain 400. Actor repetitions share traffic cases. No intermediate delay was measured.}

**Evidence:** {"aggregate_rows_recomputed": 300, "grid": [0, 200, 500, 700, 1000], "record_weighting": "equal record; equal condition sizes"}

**Assessment:** All denominator, weighting and recorded-grid statements agree; completion detection details are separately scoped.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 106: PASS — paper.tex:213, delay 0, lans

**Status:** `rounding_ok`

**Paper:** 0.063; 1200/1200

**Evidence:** {"rmse": 0.06343067099091208, "corridor_completed": 1200, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed44_delay0.jsonl

### Claim 107: PASS — paper.tex:213, delay 0, mpc_nominal

**Status:** `rounding_ok`

**Paper:** 0.028; 400/400

**Evidence:** {"rmse": 0.028236533665000306, "corridor_completed": 400, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_mpc_nominal_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_mpc_nominal_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_mpc_nominal_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_mpc_nominal_seed0_delay0.jsonl

### Claim 108: PASS — paper.tex:213, delay 0, lqr

**Status:** `rounding_ok`

**Paper:** 0.039; 60/400

**Evidence:** {"rmse": 0.039186699094463824, "corridor_completed": 60, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_seed0_delay0.jsonl

### Claim 109: PASS — paper.tex:213, delay 0, lqr_acc

**Status:** `rounding_ok`

**Paper:** 0.019; 360/400

**Evidence:** {"rmse": 0.018702107375359944, "corridor_completed": 360, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_acc_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_acc_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_acc_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_acc_seed0_delay0.jsonl

### Claim 110: PASS — paper.tex:213, delay 0, predictor_lqr

**Status:** `rounding_ok`

**Paper:** 0.019; 360/400

**Evidence:** {"rmse": 0.018702107375359944, "corridor_completed": 360, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_predictor_lqr_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_predictor_lqr_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_predictor_lqr_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_predictor_lqr_seed0_delay0.jsonl

### Claim 111: PASS — paper.tex:213, delay 0, ppo_only

**Status:** `rounding_ok`

**Paper:** 0.402; 1127/1200

**Evidence:** {"rmse": 0.40233516664560515, "corridor_completed": 1127, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed44_delay0.jsonl

### Claim 112: PASS — paper.tex:214, delay 200, lans

**Status:** `rounding_ok`

**Paper:** 0.066; 1200/1200

**Evidence:** {"rmse": 0.0656518562623614, "corridor_completed": 1200, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed44_delay200.jsonl

### Claim 113: PASS — paper.tex:214, delay 200, mpc_nominal

**Status:** `rounding_ok`

**Paper:** 0.031; 400/400

**Evidence:** {"rmse": 0.031482476449658583, "corridor_completed": 400, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_mpc_nominal_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_mpc_nominal_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_mpc_nominal_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_mpc_nominal_seed0_delay200.jsonl

### Claim 114: PASS — paper.tex:214, delay 200, lqr

**Status:** `rounding_ok`

**Paper:** 0.448; 59/400

**Evidence:** {"rmse": 0.44822428033624884, "corridor_completed": 59, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_seed0_delay200.jsonl

### Claim 115: PASS — paper.tex:214, delay 200, lqr_acc

**Status:** `rounding_ok`

**Paper:** 0.234; 302/400

**Evidence:** {"rmse": 0.2335704294149734, "corridor_completed": 302, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_acc_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_acc_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_acc_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_acc_seed0_delay200.jsonl

### Claim 116: PASS — paper.tex:214, delay 200, predictor_lqr

**Status:** `rounding_ok`

**Paper:** 0.019; 358/400

**Evidence:** {"rmse": 0.019328749518693997, "corridor_completed": 358, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_predictor_lqr_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_predictor_lqr_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_predictor_lqr_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_predictor_lqr_seed0_delay200.jsonl

### Claim 117: PASS — paper.tex:214, delay 200, ppo_only

**Status:** `rounding_ok`

**Paper:** 1.787; 413/1200

**Evidence:** {"rmse": 1.7865368936088153, "corridor_completed": 413, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed44_delay200.jsonl

### Claim 118: PASS — paper.tex:215, delay 500, lans

**Status:** `rounding_ok`

**Paper:** 0.115; 1197/1200

**Evidence:** {"rmse": 0.11452043927870738, "corridor_completed": 1197, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed44_delay500.jsonl

### Claim 119: PASS — paper.tex:215, delay 500, mpc_nominal

**Status:** `rounding_ok`

**Paper:** 0.092; 399/400

**Evidence:** {"rmse": 0.09161326959623067, "corridor_completed": 399, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_mpc_nominal_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_mpc_nominal_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_mpc_nominal_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_mpc_nominal_seed0_delay500.jsonl

### Claim 120: PASS — paper.tex:215, delay 500, lqr

**Status:** `rounding_ok`

**Paper:** 1.726; 59/400

**Evidence:** {"rmse": 1.7262092620486555, "corridor_completed": 59, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_seed0_delay500.jsonl

### Claim 121: PASS — paper.tex:215, delay 500, lqr_acc

**Status:** `rounding_ok`

**Paper:** 2.080; 159/400

**Evidence:** {"rmse": 2.080001770451697, "corridor_completed": 159, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_acc_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_acc_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_acc_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_acc_seed0_delay500.jsonl

### Claim 122: PASS — paper.tex:215, delay 500, predictor_lqr

**Status:** `rounding_ok`

**Paper:** 0.093; 352/400

**Evidence:** {"rmse": 0.09306050625931879, "corridor_completed": 352, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_predictor_lqr_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_predictor_lqr_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_predictor_lqr_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_predictor_lqr_seed0_delay500.jsonl

### Claim 123: PASS — paper.tex:215, delay 500, ppo_only

**Status:** `rounding_ok`

**Paper:** 8.739; 5/1200

**Evidence:** {"rmse": 8.739419925048175, "corridor_completed": 5, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed44_delay500.jsonl

### Claim 124: PASS — paper.tex:216, delay 700, lans

**Status:** `rounding_ok`

**Paper:** 0.192; 969/1200

**Evidence:** {"rmse": 0.19209188604807545, "corridor_completed": 969, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed44_delay700.jsonl

### Claim 125: PASS — paper.tex:216, delay 700, mpc_nominal

**Status:** `rounding_ok`

**Paper:** 0.174; 320/400

**Evidence:** {"rmse": 0.17436689184629692, "corridor_completed": 320, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_mpc_nominal_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_mpc_nominal_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_mpc_nominal_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_mpc_nominal_seed0_delay700.jsonl

### Claim 126: PASS — paper.tex:216, delay 700, lqr

**Status:** `rounding_ok`

**Paper:** 2.261; 59/400

**Evidence:** {"rmse": 2.2606258768372847, "corridor_completed": 59, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_seed0_delay700.jsonl

### Claim 127: PASS — paper.tex:216, delay 700, lqr_acc

**Status:** `rounding_ok`

**Paper:** 2.369; 159/400

**Evidence:** {"rmse": 2.369170765288032, "corridor_completed": 159, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_acc_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_acc_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_acc_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_acc_seed0_delay700.jsonl

### Claim 128: PASS — paper.tex:216, delay 700, predictor_lqr

**Status:** `rounding_ok`

**Paper:** 0.202; 263/400

**Evidence:** {"rmse": 0.20211261643005485, "corridor_completed": 263, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_predictor_lqr_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_predictor_lqr_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_predictor_lqr_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_predictor_lqr_seed0_delay700.jsonl

### Claim 129: PASS — paper.tex:216, delay 700, ppo_only

**Status:** `rounding_ok`

**Paper:** 12.440; 0/1200

**Evidence:** {"rmse": 12.439638463443055, "corridor_completed": 0, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed44_delay700.jsonl

### Claim 130: PASS — paper.tex:217, delay 1000, lans

**Status:** `rounding_ok`

**Paper:** 0.357; 702/1200

**Evidence:** {"rmse": 0.35698445929376427, "corridor_completed": 702, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed44_delay1000.jsonl

### Claim 131: PASS — paper.tex:217, delay 1000, mpc_nominal

**Status:** `rounding_ok`

**Paper:** 0.353; 233/400

**Evidence:** {"rmse": 0.3529092039302675, "corridor_completed": 233, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_mpc_nominal_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_mpc_nominal_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_mpc_nominal_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_mpc_nominal_seed0_delay1000.jsonl

### Claim 132: PASS — paper.tex:217, delay 1000, lqr

**Status:** `rounding_ok`

**Paper:** 5.232; 58/400

**Evidence:** {"rmse": 5.231986057979963, "corridor_completed": 58, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_seed0_delay1000.jsonl

### Claim 133: PASS — paper.tex:217, delay 1000, lqr_acc

**Status:** `rounding_ok`

**Paper:** 5.102; 158/400

**Evidence:** {"rmse": 5.102141760696834, "corridor_completed": 158, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_acc_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_acc_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_acc_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_acc_seed0_delay1000.jsonl

### Claim 134: PASS — paper.tex:217, delay 1000, predictor_lqr

**Status:** `rounding_ok`

**Paper:** 0.429; 190/400

**Evidence:** {"rmse": 0.42854719128412716, "corridor_completed": 190, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_predictor_lqr_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_predictor_lqr_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_predictor_lqr_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_predictor_lqr_seed0_delay1000.jsonl

### Claim 135: PASS — paper.tex:217, delay 1000, ppo_only

**Status:** `rounding_ok`

**Paper:** 16.136; 0/1200

**Evidence:** {"rmse": 16.13617858581635, "corridor_completed": 0, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed44_delay1000.jsonl

### Claim 136: PASS — paper.tex:223, delay 0, cbf

**Status:** `rounding_ok`

**Paper:** 0.398; 1200/1200

**Evidence:** {"rmse": 0.39790172989252265, "corridor_completed": 1200, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed44_delay0.jsonl

### Claim 137: PASS — paper.tex:223, delay 0, lans_no_prediction

**Status:** `rounding_ok`

**Paper:** 0.063; 1200/1200

**Evidence:** {"rmse": 0.06343067099655325, "corridor_completed": 1200, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed44_delay0.jsonl

### Claim 138: PASS — paper.tex:223, delay 0, lans_no_actor

**Status:** `rounding_ok`

**Paper:** 0.061; 400/400

**Evidence:** {"rmse": 0.06089630280457805, "corridor_completed": 400, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_actor_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_actor_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_actor_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_actor_seed0_delay0.jsonl

### Claim 139: PASS — paper.tex:223, delay 0, robust_lans

**Status:** `rounding_ok`

**Paper:** 0.074; 1200/1200

**Evidence:** {"rmse": 0.07384097488810384, "corridor_completed": 1200, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed44_delay0.jsonl

### Claim 140: PASS — paper.tex:223, delay 0, robust_mpc

**Status:** `rounding_ok`

**Paper:** 0.044; 400/400

**Evidence:** {"rmse": 0.044330402626162994, "corridor_completed": 400, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_mpc_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_mpc_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_mpc_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_mpc_seed0_delay0.jsonl

### Claim 141: PASS — paper.tex:223, delay 0, robust_no_actor

**Status:** `rounding_ok`

**Paper:** 0.070; 400/400

**Evidence:** {"rmse": 0.07047644170238612, "corridor_completed": 400, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_no_actor_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_no_actor_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_no_actor_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_no_actor_seed0_delay0.jsonl

### Claim 142: PASS — paper.tex:224, delay 200, cbf

**Status:** `rounding_ok`

**Paper:** 0.650; 1200/1200

**Evidence:** {"rmse": 0.6503875179062739, "corridor_completed": 1200, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed44_delay200.jsonl

### Claim 143: PASS — paper.tex:224, delay 200, lans_no_prediction

**Status:** `rounding_ok`

**Paper:** 3.586; 121/1200

**Evidence:** {"rmse": 3.586399755283301, "corridor_completed": 121, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed44_delay200.jsonl

### Claim 144: PASS — paper.tex:224, delay 200, lans_no_actor

**Status:** `rounding_ok`

**Paper:** 0.064; 400/400

**Evidence:** {"rmse": 0.0636606396296849, "corridor_completed": 400, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_actor_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_actor_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_actor_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_actor_seed0_delay200.jsonl

### Claim 145: PASS — paper.tex:224, delay 200, robust_lans

**Status:** `rounding_ok`

**Paper:** 0.076; 1200/1200

**Evidence:** {"rmse": 0.07624998160648482, "corridor_completed": 1200, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed44_delay200.jsonl

### Claim 146: PASS — paper.tex:224, delay 200, robust_mpc

**Status:** `rounding_ok`

**Paper:** 0.046; 400/400

**Evidence:** {"rmse": 0.04611697968374249, "corridor_completed": 400, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_mpc_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_mpc_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_mpc_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_mpc_seed0_delay200.jsonl

### Claim 147: PASS — paper.tex:224, delay 200, robust_no_actor

**Status:** `rounding_ok`

**Paper:** 0.072; 400/400

**Evidence:** {"rmse": 0.07199568163751394, "corridor_completed": 400, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_no_actor_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_no_actor_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_no_actor_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_no_actor_seed0_delay200.jsonl

### Claim 148: PASS — paper.tex:225, delay 500, cbf

**Status:** `rounding_ok`

**Paper:** 1.000; 1063/1200

**Evidence:** {"rmse": 1.000177156673097, "corridor_completed": 1063, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed44_delay500.jsonl

### Claim 149: PASS — paper.tex:225, delay 500, lans_no_prediction

**Status:** `rounding_ok`

**Paper:** 17.263; 0/1200

**Evidence:** {"rmse": 17.262998045723833, "corridor_completed": 0, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed44_delay500.jsonl

### Claim 150: PASS — paper.tex:225, delay 500, lans_no_actor

**Status:** `rounding_ok`

**Paper:** 0.112; 399/400

**Evidence:** {"rmse": 0.11191772174048208, "corridor_completed": 399, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_actor_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_actor_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_actor_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_actor_seed0_delay500.jsonl

### Claim 151: PASS — paper.tex:225, delay 500, robust_lans

**Status:** `rounding_ok`

**Paper:** 0.126; 1194/1200

**Evidence:** {"rmse": 0.12564819221696452, "corridor_completed": 1194, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed44_delay500.jsonl

### Claim 152: PASS — paper.tex:225, delay 500, robust_mpc

**Status:** `rounding_ok`

**Paper:** 0.102; 398/400

**Evidence:** {"rmse": 0.10188329772503835, "corridor_completed": 398, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_mpc_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_mpc_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_mpc_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_mpc_seed0_delay500.jsonl

### Claim 153: PASS — paper.tex:225, delay 500, robust_no_actor

**Status:** `rounding_ok`

**Paper:** 0.123; 398/400

**Evidence:** {"rmse": 0.12265577732254605, "corridor_completed": 398, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_no_actor_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_no_actor_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_no_actor_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_no_actor_seed0_delay500.jsonl

### Claim 154: PASS — paper.tex:226, delay 700, cbf

**Status:** `rounding_ok`

**Paper:** 1.103; 891/1200

**Evidence:** {"rmse": 1.1025517380327323, "corridor_completed": 891, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed44_delay700.jsonl

### Claim 155: PASS — paper.tex:226, delay 700, lans_no_prediction

**Status:** `rounding_ok`

**Paper:** 23.461; 0/1200

**Evidence:** {"rmse": 23.46120193062797, "corridor_completed": 0, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed44_delay700.jsonl

### Claim 156: PASS — paper.tex:226, delay 700, lans_no_actor

**Status:** `rounding_ok`

**Paper:** 0.188; 323/400

**Evidence:** {"rmse": 0.18835074446354397, "corridor_completed": 323, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_actor_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_actor_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_actor_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_actor_seed0_delay700.jsonl

### Claim 157: PASS — paper.tex:226, delay 700, robust_lans

**Status:** `rounding_ok`

**Paper:** 0.207; 957/1200

**Evidence:** {"rmse": 0.20748029423648093, "corridor_completed": 957, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed44_delay700.jsonl

### Claim 158: PASS — paper.tex:226, delay 700, robust_mpc

**Status:** `rounding_ok`

**Paper:** 0.189; 319/400

**Evidence:** {"rmse": 0.1890186298008777, "corridor_completed": 319, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_mpc_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_mpc_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_mpc_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_mpc_seed0_delay700.jsonl

### Claim 159: PASS — paper.tex:226, delay 700, robust_no_actor

**Status:** `rounding_ok`

**Paper:** 0.206; 319/400

**Evidence:** {"rmse": 0.20601220286975772, "corridor_completed": 319, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_no_actor_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_no_actor_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_no_actor_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_no_actor_seed0_delay700.jsonl

### Claim 160: PASS — paper.tex:227, delay 1000, cbf

**Status:** `rounding_ok`

**Paper:** 1.423; 685/1200

**Evidence:** {"rmse": 1.4226600419735993, "corridor_completed": 685, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed44_delay1000.jsonl

### Claim 161: PASS — paper.tex:227, delay 1000, lans_no_prediction

**Status:** `rounding_ok`

**Paper:** 11.365; 0/1200

**Evidence:** {"rmse": 11.36539175875411, "corridor_completed": 0, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed44_delay1000.jsonl

### Claim 162: PASS — paper.tex:227, delay 1000, lans_no_actor

**Status:** `rounding_ok`

**Paper:** 0.358; 234/400

**Evidence:** {"rmse": 0.35833468206654656, "corridor_completed": 234, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_actor_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_actor_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_actor_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_actor_seed0_delay1000.jsonl

### Claim 163: PASS — paper.tex:227, delay 1000, robust_lans

**Status:** `rounding_ok`

**Paper:** 0.405; 705/1200

**Evidence:** {"rmse": 0.40459331971587575, "corridor_completed": 705, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed44_delay1000.jsonl

### Claim 164: PASS — paper.tex:227, delay 1000, robust_mpc

**Status:** `rounding_ok`

**Paper:** 0.384; 234/400

**Evidence:** {"rmse": 0.38428927185797224, "corridor_completed": 234, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_mpc_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_mpc_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_mpc_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_mpc_seed0_delay1000.jsonl

### Claim 165: PASS — paper.tex:227, delay 1000, robust_no_actor

**Status:** `rounding_ok`

**Paper:** 0.402; 234/400

**Evidence:** {"rmse": 0.40239146318881613, "corridor_completed": 234, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_no_actor_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_no_actor_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_no_actor_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_no_actor_seed0_delay1000.jsonl

### Claim 166: PASS — table_delay_grid.tex:4, delay 0, lans

**Status:** `rounding_ok`

**Paper:** 0.063; 1200/1200

**Evidence:** {"rmse": 0.06343067099091208, "corridor_completed": 1200, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed44_delay0.jsonl

### Claim 167: PASS — table_delay_grid.tex:4, delay 0, mpc_nominal

**Status:** `rounding_ok`

**Paper:** 0.028; 400/400

**Evidence:** {"rmse": 0.028236533665000306, "corridor_completed": 400, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_mpc_nominal_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_mpc_nominal_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_mpc_nominal_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_mpc_nominal_seed0_delay0.jsonl

### Claim 168: PASS — table_delay_grid.tex:4, delay 0, lqr

**Status:** `rounding_ok`

**Paper:** 0.039; 60/400

**Evidence:** {"rmse": 0.039186699094463824, "corridor_completed": 60, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_seed0_delay0.jsonl

### Claim 169: PASS — table_delay_grid.tex:4, delay 0, lqr_acc

**Status:** `rounding_ok`

**Paper:** 0.019; 360/400

**Evidence:** {"rmse": 0.018702107375359944, "corridor_completed": 360, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_acc_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_acc_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_acc_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_acc_seed0_delay0.jsonl

### Claim 170: PASS — table_delay_grid.tex:4, delay 0, predictor_lqr

**Status:** `rounding_ok`

**Paper:** 0.019; 360/400

**Evidence:** {"rmse": 0.018702107375359944, "corridor_completed": 360, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_predictor_lqr_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_predictor_lqr_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_predictor_lqr_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_predictor_lqr_seed0_delay0.jsonl

### Claim 171: PASS — table_delay_grid.tex:4, delay 0, ppo_only

**Status:** `rounding_ok`

**Paper:** 0.402; 1127/1200

**Evidence:** {"rmse": 0.40233516664560515, "corridor_completed": 1127, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed44_delay0.jsonl

### Claim 172: PASS — table_delay_grid.tex:5, delay 200, lans

**Status:** `rounding_ok`

**Paper:** 0.066; 1200/1200

**Evidence:** {"rmse": 0.0656518562623614, "corridor_completed": 1200, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed44_delay200.jsonl

### Claim 173: PASS — table_delay_grid.tex:5, delay 200, mpc_nominal

**Status:** `rounding_ok`

**Paper:** 0.031; 400/400

**Evidence:** {"rmse": 0.031482476449658583, "corridor_completed": 400, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_mpc_nominal_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_mpc_nominal_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_mpc_nominal_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_mpc_nominal_seed0_delay200.jsonl

### Claim 174: PASS — table_delay_grid.tex:5, delay 200, lqr

**Status:** `rounding_ok`

**Paper:** 0.448; 59/400

**Evidence:** {"rmse": 0.44822428033624884, "corridor_completed": 59, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_seed0_delay200.jsonl

### Claim 175: PASS — table_delay_grid.tex:5, delay 200, lqr_acc

**Status:** `rounding_ok`

**Paper:** 0.234; 302/400

**Evidence:** {"rmse": 0.2335704294149734, "corridor_completed": 302, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_acc_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_acc_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_acc_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_acc_seed0_delay200.jsonl

### Claim 176: PASS — table_delay_grid.tex:5, delay 200, predictor_lqr

**Status:** `rounding_ok`

**Paper:** 0.019; 358/400

**Evidence:** {"rmse": 0.019328749518693997, "corridor_completed": 358, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_predictor_lqr_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_predictor_lqr_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_predictor_lqr_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_predictor_lqr_seed0_delay200.jsonl

### Claim 177: PASS — table_delay_grid.tex:5, delay 200, ppo_only

**Status:** `rounding_ok`

**Paper:** 1.787; 413/1200

**Evidence:** {"rmse": 1.7865368936088153, "corridor_completed": 413, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed44_delay200.jsonl

### Claim 178: PASS — table_delay_grid.tex:6, delay 500, lans

**Status:** `rounding_ok`

**Paper:** 0.115; 1197/1200

**Evidence:** {"rmse": 0.11452043927870738, "corridor_completed": 1197, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed44_delay500.jsonl

### Claim 179: PASS — table_delay_grid.tex:6, delay 500, mpc_nominal

**Status:** `rounding_ok`

**Paper:** 0.092; 399/400

**Evidence:** {"rmse": 0.09161326959623067, "corridor_completed": 399, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_mpc_nominal_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_mpc_nominal_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_mpc_nominal_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_mpc_nominal_seed0_delay500.jsonl

### Claim 180: PASS — table_delay_grid.tex:6, delay 500, lqr

**Status:** `rounding_ok`

**Paper:** 1.726; 59/400

**Evidence:** {"rmse": 1.7262092620486555, "corridor_completed": 59, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_seed0_delay500.jsonl

### Claim 181: PASS — table_delay_grid.tex:6, delay 500, lqr_acc

**Status:** `rounding_ok`

**Paper:** 2.080; 159/400

**Evidence:** {"rmse": 2.080001770451697, "corridor_completed": 159, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_acc_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_acc_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_acc_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_acc_seed0_delay500.jsonl

### Claim 182: PASS — table_delay_grid.tex:6, delay 500, predictor_lqr

**Status:** `rounding_ok`

**Paper:** 0.093; 352/400

**Evidence:** {"rmse": 0.09306050625931879, "corridor_completed": 352, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_predictor_lqr_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_predictor_lqr_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_predictor_lqr_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_predictor_lqr_seed0_delay500.jsonl

### Claim 183: PASS — table_delay_grid.tex:6, delay 500, ppo_only

**Status:** `rounding_ok`

**Paper:** 8.739; 5/1200

**Evidence:** {"rmse": 8.739419925048175, "corridor_completed": 5, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed44_delay500.jsonl

### Claim 184: PASS — table_delay_grid.tex:7, delay 700, lans

**Status:** `rounding_ok`

**Paper:** 0.192; 969/1200

**Evidence:** {"rmse": 0.19209188604807545, "corridor_completed": 969, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed44_delay700.jsonl

### Claim 185: PASS — table_delay_grid.tex:7, delay 700, mpc_nominal

**Status:** `rounding_ok`

**Paper:** 0.174; 320/400

**Evidence:** {"rmse": 0.17436689184629692, "corridor_completed": 320, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_mpc_nominal_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_mpc_nominal_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_mpc_nominal_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_mpc_nominal_seed0_delay700.jsonl

### Claim 186: PASS — table_delay_grid.tex:7, delay 700, lqr

**Status:** `rounding_ok`

**Paper:** 2.261; 59/400

**Evidence:** {"rmse": 2.2606258768372847, "corridor_completed": 59, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_seed0_delay700.jsonl

### Claim 187: PASS — table_delay_grid.tex:7, delay 700, lqr_acc

**Status:** `rounding_ok`

**Paper:** 2.369; 159/400

**Evidence:** {"rmse": 2.369170765288032, "corridor_completed": 159, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_acc_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_acc_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_acc_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_acc_seed0_delay700.jsonl

### Claim 188: PASS — table_delay_grid.tex:7, delay 700, predictor_lqr

**Status:** `rounding_ok`

**Paper:** 0.202; 263/400

**Evidence:** {"rmse": 0.20211261643005485, "corridor_completed": 263, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_predictor_lqr_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_predictor_lqr_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_predictor_lqr_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_predictor_lqr_seed0_delay700.jsonl

### Claim 189: PASS — table_delay_grid.tex:7, delay 700, ppo_only

**Status:** `rounding_ok`

**Paper:** 12.440; 0/1200

**Evidence:** {"rmse": 12.439638463443055, "corridor_completed": 0, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed44_delay700.jsonl

### Claim 190: PASS — table_delay_grid.tex:8, delay 1000, lans

**Status:** `rounding_ok`

**Paper:** 0.357; 702/1200

**Evidence:** {"rmse": 0.35698445929376427, "corridor_completed": 702, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_seed44_delay1000.jsonl

### Claim 191: PASS — table_delay_grid.tex:8, delay 1000, mpc_nominal

**Status:** `rounding_ok`

**Paper:** 0.353; 233/400

**Evidence:** {"rmse": 0.3529092039302675, "corridor_completed": 233, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_mpc_nominal_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_mpc_nominal_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_mpc_nominal_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_mpc_nominal_seed0_delay1000.jsonl

### Claim 192: PASS — table_delay_grid.tex:8, delay 1000, lqr

**Status:** `rounding_ok`

**Paper:** 5.232; 58/400

**Evidence:** {"rmse": 5.231986057979963, "corridor_completed": 58, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_seed0_delay1000.jsonl

### Claim 193: PASS — table_delay_grid.tex:8, delay 1000, lqr_acc

**Status:** `rounding_ok`

**Paper:** 5.102; 158/400

**Evidence:** {"rmse": 5.102141760696834, "corridor_completed": 158, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lqr_acc_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lqr_acc_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lqr_acc_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lqr_acc_seed0_delay1000.jsonl

### Claim 194: PASS — table_delay_grid.tex:8, delay 1000, predictor_lqr

**Status:** `rounding_ok`

**Paper:** 0.429; 190/400

**Evidence:** {"rmse": 0.42854719128412716, "corridor_completed": 190, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_predictor_lqr_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_predictor_lqr_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_predictor_lqr_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_predictor_lqr_seed0_delay1000.jsonl

### Claim 195: PASS — table_delay_grid.tex:8, delay 1000, ppo_only

**Status:** `rounding_ok`

**Paper:** 16.136; 0/1200

**Evidence:** {"rmse": 16.13617858581635, "corridor_completed": 0, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_ppo_only_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_ppo_only_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_ppo_only_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_ppo_only_seed44_delay1000.jsonl

### Claim 196: PASS — table_delay_grid.tex:14, delay 0, cbf

**Status:** `rounding_ok`

**Paper:** 0.398; 1200/1200

**Evidence:** {"rmse": 0.39790172989252265, "corridor_completed": 1200, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed44_delay0.jsonl

### Claim 197: PASS — table_delay_grid.tex:14, delay 0, lans_no_prediction

**Status:** `rounding_ok`

**Paper:** 0.063; 1200/1200

**Evidence:** {"rmse": 0.06343067099655325, "corridor_completed": 1200, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed44_delay0.jsonl

### Claim 198: PASS — table_delay_grid.tex:14, delay 0, lans_no_actor

**Status:** `rounding_ok`

**Paper:** 0.061; 400/400

**Evidence:** {"rmse": 0.06089630280457805, "corridor_completed": 400, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_actor_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_actor_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_actor_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_actor_seed0_delay0.jsonl

### Claim 199: PASS — table_delay_grid.tex:14, delay 0, robust_lans

**Status:** `rounding_ok`

**Paper:** 0.074; 1200/1200

**Evidence:** {"rmse": 0.07384097488810384, "corridor_completed": 1200, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed44_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed42_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed43_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed44_delay0.jsonl

### Claim 200: PASS — table_delay_grid.tex:14, delay 0, robust_mpc

**Status:** `rounding_ok`

**Paper:** 0.044; 400/400

**Evidence:** {"rmse": 0.044330402626162994, "corridor_completed": 400, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_mpc_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_mpc_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_mpc_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_mpc_seed0_delay0.jsonl

### Claim 201: PASS — table_delay_grid.tex:14, delay 0, robust_no_actor

**Status:** `rounding_ok`

**Paper:** 0.070; 400/400

**Evidence:** {"rmse": 0.07047644170238612, "corridor_completed": 400, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_no_actor_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_no_actor_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_no_actor_seed0_delay0.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_no_actor_seed0_delay0.jsonl

### Claim 202: PASS — table_delay_grid.tex:15, delay 200, cbf

**Status:** `rounding_ok`

**Paper:** 0.650; 1200/1200

**Evidence:** {"rmse": 0.6503875179062739, "corridor_completed": 1200, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed44_delay200.jsonl

### Claim 203: PASS — table_delay_grid.tex:15, delay 200, lans_no_prediction

**Status:** `rounding_ok`

**Paper:** 3.586; 121/1200

**Evidence:** {"rmse": 3.586399755283301, "corridor_completed": 121, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed44_delay200.jsonl

### Claim 204: PASS — table_delay_grid.tex:15, delay 200, lans_no_actor

**Status:** `rounding_ok`

**Paper:** 0.064; 400/400

**Evidence:** {"rmse": 0.0636606396296849, "corridor_completed": 400, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_actor_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_actor_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_actor_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_actor_seed0_delay200.jsonl

### Claim 205: PASS — table_delay_grid.tex:15, delay 200, robust_lans

**Status:** `rounding_ok`

**Paper:** 0.076; 1200/1200

**Evidence:** {"rmse": 0.07624998160648482, "corridor_completed": 1200, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed44_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed42_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed43_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed44_delay200.jsonl

### Claim 206: PASS — table_delay_grid.tex:15, delay 200, robust_mpc

**Status:** `rounding_ok`

**Paper:** 0.046; 400/400

**Evidence:** {"rmse": 0.04611697968374249, "corridor_completed": 400, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_mpc_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_mpc_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_mpc_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_mpc_seed0_delay200.jsonl

### Claim 207: PASS — table_delay_grid.tex:15, delay 200, robust_no_actor

**Status:** `rounding_ok`

**Paper:** 0.072; 400/400

**Evidence:** {"rmse": 0.07199568163751394, "corridor_completed": 400, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_no_actor_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_no_actor_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_no_actor_seed0_delay200.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_no_actor_seed0_delay200.jsonl

### Claim 208: PASS — table_delay_grid.tex:16, delay 500, cbf

**Status:** `rounding_ok`

**Paper:** 1.000; 1063/1200

**Evidence:** {"rmse": 1.000177156673097, "corridor_completed": 1063, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed44_delay500.jsonl

### Claim 209: PASS — table_delay_grid.tex:16, delay 500, lans_no_prediction

**Status:** `rounding_ok`

**Paper:** 17.263; 0/1200

**Evidence:** {"rmse": 17.262998045723833, "corridor_completed": 0, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed44_delay500.jsonl

### Claim 210: PASS — table_delay_grid.tex:16, delay 500, lans_no_actor

**Status:** `rounding_ok`

**Paper:** 0.112; 399/400

**Evidence:** {"rmse": 0.11191772174048208, "corridor_completed": 399, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_actor_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_actor_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_actor_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_actor_seed0_delay500.jsonl

### Claim 211: PASS — table_delay_grid.tex:16, delay 500, robust_lans

**Status:** `rounding_ok`

**Paper:** 0.126; 1194/1200

**Evidence:** {"rmse": 0.12564819221696452, "corridor_completed": 1194, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed44_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed42_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed43_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed44_delay500.jsonl

### Claim 212: PASS — table_delay_grid.tex:16, delay 500, robust_mpc

**Status:** `rounding_ok`

**Paper:** 0.102; 398/400

**Evidence:** {"rmse": 0.10188329772503835, "corridor_completed": 398, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_mpc_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_mpc_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_mpc_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_mpc_seed0_delay500.jsonl

### Claim 213: PASS — table_delay_grid.tex:16, delay 500, robust_no_actor

**Status:** `rounding_ok`

**Paper:** 0.123; 398/400

**Evidence:** {"rmse": 0.12265577732254605, "corridor_completed": 398, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_no_actor_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_no_actor_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_no_actor_seed0_delay500.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_no_actor_seed0_delay500.jsonl

### Claim 214: PASS — table_delay_grid.tex:17, delay 700, cbf

**Status:** `rounding_ok`

**Paper:** 1.103; 891/1200

**Evidence:** {"rmse": 1.1025517380327323, "corridor_completed": 891, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed44_delay700.jsonl

### Claim 215: PASS — table_delay_grid.tex:17, delay 700, lans_no_prediction

**Status:** `rounding_ok`

**Paper:** 23.461; 0/1200

**Evidence:** {"rmse": 23.46120193062797, "corridor_completed": 0, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed44_delay700.jsonl

### Claim 216: PASS — table_delay_grid.tex:17, delay 700, lans_no_actor

**Status:** `rounding_ok`

**Paper:** 0.188; 323/400

**Evidence:** {"rmse": 0.18835074446354397, "corridor_completed": 323, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_actor_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_actor_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_actor_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_actor_seed0_delay700.jsonl

### Claim 217: PASS — table_delay_grid.tex:17, delay 700, robust_lans

**Status:** `rounding_ok`

**Paper:** 0.207; 957/1200

**Evidence:** {"rmse": 0.20748029423648093, "corridor_completed": 957, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed44_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed42_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed43_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed44_delay700.jsonl

### Claim 218: PASS — table_delay_grid.tex:17, delay 700, robust_mpc

**Status:** `rounding_ok`

**Paper:** 0.189; 319/400

**Evidence:** {"rmse": 0.1890186298008777, "corridor_completed": 319, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_mpc_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_mpc_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_mpc_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_mpc_seed0_delay700.jsonl

### Claim 219: PASS — table_delay_grid.tex:17, delay 700, robust_no_actor

**Status:** `rounding_ok`

**Paper:** 0.206; 319/400

**Evidence:** {"rmse": 0.20601220286975772, "corridor_completed": 319, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_no_actor_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_no_actor_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_no_actor_seed0_delay700.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_no_actor_seed0_delay700.jsonl

### Claim 220: PASS — table_delay_grid.tex:18, delay 1000, cbf

**Status:** `rounding_ok`

**Paper:** 1.423; 685/1200

**Evidence:** {"rmse": 1.4226600419735993, "corridor_completed": 685, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_cbf_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_cbf_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_cbf_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_cbf_seed44_delay1000.jsonl

### Claim 221: PASS — table_delay_grid.tex:18, delay 1000, lans_no_prediction

**Status:** `rounding_ok`

**Paper:** 11.365; 0/1200

**Evidence:** {"rmse": 11.36539175875411, "corridor_completed": 0, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_prediction_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_prediction_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_prediction_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_prediction_seed44_delay1000.jsonl

### Claim 222: PASS — table_delay_grid.tex:18, delay 1000, lans_no_actor

**Status:** `rounding_ok`

**Paper:** 0.358; 234/400

**Evidence:** {"rmse": 0.35833468206654656, "corridor_completed": 234, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_lans_no_actor_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_lans_no_actor_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_lans_no_actor_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_lans_no_actor_seed0_delay1000.jsonl

### Claim 223: PASS — table_delay_grid.tex:18, delay 1000, robust_lans

**Status:** `rounding_ok`

**Paper:** 0.405; 705/1200

**Evidence:** {"rmse": 0.40459331971587575, "corridor_completed": 705, "n": 1200}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_lans_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_lans_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_lans_seed44_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed42_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed43_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_lans_seed44_delay1000.jsonl

### Claim 224: PASS — table_delay_grid.tex:18, delay 1000, robust_mpc

**Status:** `rounding_ok`

**Paper:** 0.384; 234/400

**Evidence:** {"rmse": 0.38428927185797224, "corridor_completed": 234, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_mpc_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_mpc_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_mpc_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_mpc_seed0_delay1000.jsonl

### Claim 225: PASS — table_delay_grid.tex:18, delay 1000, robust_no_actor

**Status:** `rounding_ok`

**Paper:** 0.402; 234/400

**Evidence:** {"rmse": 0.40239146318881613, "corridor_completed": 234, "n": 400}

**Assessment:** RMSE is the mean of all saved episode RMSEs in this controller/delay group, rounded to 0.001 m. Completion numerator and denominator are exact. No tolerance beyond ordinary displayed rounding is applied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/highway_robust_no_actor_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/intersection_robust_no_actor_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/merge_robust_no_actor_seed0_delay1000.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/roundabout_robust_no_actor_seed0_delay1000.jsonl

### Claim 226: PASS — paper.tex:233

**Status:** `exact_match`

**Paper:** Disabling internal queue prediction reduces corridor-completion rates in 45 of the 60 paired actor/scenario/delay contrasts; all 45 remain significant after Holm correction. No contrast has a higher corridor-completion rate for the no-prediction variant. These counts are correlated comparisons over shared cases and actors, not 60 independent replications.

**Evidence:** {"n": 60, "positive": 45, "negative": 0, "zero": 15, "positive_significant": 45, "negative_significant": 0, "max_positive_p_holm": 0.0002608299255371094}

**Assessment:** Maximum Holm p among the 45 improved contrasts is 0.0002608299255371094; the counts are comparisons over reused cases, not independent replications.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 227: PASS — paper.tex:235

**Status:** `exact_match`

**Paper:** The endpoint behavior illustrates the mechanism's limitations and value. At 1,000~ms, removing prediction yields zero corridor completion in every scenario. Mean collision rates rise to 25\% on Intersection and 100\% on Roundabout, while Highway and Merge can have zero collisions yet still fail corridor completion. This combination explains why collision-only reporting would be misleading. The physical queue remains active in the ablation; the degradation concerns planning from the wrong effective initial state within this implementation.

**Evidence:** {"highway": {"n": 300, "rmse": 14.599262216198877, "collision": 0.0, "corridor_completion": 0.0}, "intersection": {"n": 300, "rmse": 11.149467356932377, "collision": 0.25, "corridor_completion": 0.0}, "merge": {"n": 300, "rmse": 16.687457991722546, "collision": 0.0, "corridor_completion": 0.0}, "roundabout": {"n": 300, "rmse": 3.0253794701626435, "collision": 1.0, "corridor_completion": 0.0}}

**Assessment:** All endpoint rates agree exactly. The raw results support observed ablation differences; the claim that only queue prediction changed requires source verification.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 228: WARN — paper.tex:235

**Status:** `unsupported_by_this_audit_scope`

**Paper:** The endpoint behavior illustrates the mechanism's limitations and value. At 1,000~ms, removing prediction yields zero corridor completion in every scenario. Mean collision rates rise to 25\% on Intersection and 100\% on Roundabout, while Highway and Merge can have zero collisions yet still fail corridor completion. This combination explains why collision-only reporting would be misleading. The physical queue remains active in the ablation; the degradation concerns planning from the wrong effective initial state within this implementation.

**Evidence:** null

**Assessment:** Outcome differences alone do not establish the one-component intervention or mechanistic cause; actual ablation code is excluded.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 229: PASS — paper.tex:238

**Status:** `exact_match`

**Paper:** Removing the actor leaves corridor-completion rates unchanged in all 60 per-actor/scenario/delay comparisons. Scenario-specific results show mixed tracking effects at 1,000~ms: the no-actor variant has slightly lower mean RMSE on Intersection and Roundabout, but higher mean RMSE on Highway and Merge. Therefore, the present evidence does not establish a general completion benefit from the learned prior. This finding is retained rather than interpreting the presence of PPO as evidence of its usefulness.

**Evidence:** {"n": 60, "positive": 0, "negative": 0, "zero": 60, "positive_significant": 0, "negative_significant": 0, "max_positive_p_holm": null}

**Assessment:** 

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 230: PASS — paper.tex:238

**Status:** `exact_match`

**Paper:** Removing the actor leaves corridor-completion rates unchanged in all 60 per-actor/scenario/delay comparisons. Scenario-specific results show mixed tracking effects at 1,000~ms: the no-actor variant has slightly lower mean RMSE on Intersection and Roundabout, but higher mean RMSE on Highway and Merge. Therefore, the present evidence does not establish a general completion benefit from the learned prior. This finding is retained rather than interpreting the presence of PPO as evidence of its usefulness.

**Evidence:** {"lans": {"highway": {"n": 300, "rmse": 0.07981345629686774, "collision": 0.0, "corridor_completion": 1.0}, "intersection": {"n": 300, "rmse": 0.04268431355082067, "collision": 0.01, "corridor_completion": 0.99}, "merge": {"n": 300, "rmse": 0.3780779859167268, "collision": 0.0, "corridor_completion": 0.35}, "roundabout": {"n": 300, "rmse": 0.9273620814106418, "collision": 0.0, "corridor_completion": 0.0}}, "lans_no_actor": {"highway": {"n": 100, "rmse": 0.08223684558647747, "collision": 0.0, "corridor_completion": 1.0}, "intersection": {"n": 100, "rmse": 0.031639659640461386, "collision": 0.01, "corridor_completion": 0.99}, "merge": {"n": 100, "rmse": 0.39242065985545027, "collision": 0.0, "corridor_completion": 0.35}, "roundabout": {"n": 100, "rmse": 0.9270415631837973, "collision": 0.0, "corridor_completion": 0.0}}}

**Assessment:** Every stated direction holds. Roundabout difference is small but unrounded ordering remains correct; the text does not claim significance.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 231: PASS — paper.tex:240

**Status:** `exact_match`

**Paper:** Against PPO-only, LANS-RISK has higher corridor-completion rates in 49 of 60 contrasts, with 45 significant after Holm correction. The improvement applies to the full supervision bundle. PPO-only has zero corridor completion at the largest tested delay in every scenario and high collision rates on some scenarios. Nevertheless, comparing a supervised trajectory planner with an unsupervised policy cannot isolate which individual supervisory element causes every observed improvement.

**Evidence:** {"n": 60, "positive": 49, "negative": 0, "zero": 11, "positive_significant": 45, "negative_significant": 0, "max_positive_p_holm": 1.0}

**Assessment:** 

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 232: PASS — paper.tex:240

**Status:** `exact_match`

**Paper:** Against PPO-only, LANS-RISK has higher corridor-completion rates in 49 of 60 contrasts, with 45 significant after Holm correction. The improvement applies to the full supervision bundle. PPO-only has zero corridor completion at the largest tested delay in every scenario and high collision rates on some scenarios. Nevertheless, comparing a supervised trajectory planner with an unsupervised policy cannot isolate which individual supervisory element causes every observed improvement.

**Evidence:** {"highway": {"n": 300, "rmse": 11.060401277279649, "collision": 0.0, "corridor_completion": 0.0}, "intersection": {"n": 300, "rmse": 14.573261002806866, "collision": 0.19, "corridor_completion": 0.0}, "merge": {"n": 300, "rmse": 35.22423983125953, "collision": 0.0, "corridor_completion": 0.0}, "roundabout": {"n": 300, "rmse": 3.686812231919351, "collision": 0.9933333333333333, "corridor_completion": 0.0}}

**Assessment:** At 1,000 ms all four corridor rates are zero, Roundabout collision is 99.333...% and Intersection 19%; no unsupported universal collision claim is made.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 233: PASS — paper.tex:240

**Status:** `scope_supported`

**Paper:** Against PPO-only, LANS-RISK has higher corridor-completion rates in 49 of 60 contrasts, with 45 significant after Holm correction. The improvement applies to the full supervision bundle. PPO-only has zero corridor completion at the largest tested delay in every scenario and high collision rates on some scenarios. Nevertheless, comparing a supervised trajectory planner with an unsupervised policy cannot isolate which individual supervisory element causes every observed improvement.

**Evidence:** "Separate component-labelled outcomes support limited within-design comparisons; full supervision versus policy-only confounds the listed components."

**Assessment:** The text appropriately limits mechanism attribution; code-level component isolation remains unverified.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 234: PASS — paper.tex:245

**Status:** `scope_supported`

**Paper:** The main implication is narrower than a generic learned-control superiority claim. Queue-aware planning is consequential within the tested supervisor, while the learned proposal has no observed corridor-completion advantage over its matched removal. A strong model-based baseline matches the empirical delay threshold. These results motivate treating the actor as an optional proposal mechanism whose value must be measured, rather than assumed.

**Evidence:** {"contrasts": {"mpc_nominal": {"n": 60, "positive": 9, "negative": 0, "zero": 51, "positive_significant": 0, "negative_significant": 0, "max_positive_p_holm": 1.0}, "lans_no_prediction": {"n": 60, "positive": 45, "negative": 0, "zero": 15, "positive_significant": 45, "negative_significant": 0, "max_positive_p_holm": 0.0002608299255371094}, "lans_no_actor": {"n": 60, "positive": 0, "negative": 0, "zero": 60, "positive_significant": 0, "negative_significant": 0, "max_positive_p_holm": null}, "ppo_only": {"n": 60, "positive": 49, "negative": 0, "zero": 11, "positive_significant": 45, "negative_significant": 0, "max_positive_p_holm": 1.0}}, "thresholds": [{"scenario": "highway", "controller": "lans", "actor_seed": 42, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 1.0, "passes": true}]}, {"scenario": "highway", "controller": "lans", "actor_seed": 43, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 1.0, "passes": true}]}, {"scenario": "highway", "controller": "lans", "actor_seed": 44, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 1.0, "passes": true}]}, {"scenario": "highway", "controller": "mpc_nominal", "actor_seed": 0, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 1.0, "passes": true}]}, {"scenario": "intersection", "controller": "lans", "actor_seed": 42, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.01, "corridor_completion": 0.99, "passes": true}]}, {"scenario": "intersection", "controller": "lans", "actor_seed": 43, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.01, "corridor_completion": 0.99, "passes": true}]}, {"scenario": "intersection", "controller": "lans", "actor_seed": 44, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.01, "corridor_completion": 0.99, "passes": true}]}, {"scenario": "intersection", "controller": "mpc_nominal", "actor_seed": 0, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.99, "passes": true}]}, {"scenario": "merge", "controller": "lans", "actor_seed": 42, "threshold_ms": 700, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.35, "passes": false}]}, {"scenario": "merge", "controller": "lans", "actor_seed": 43, "threshold_ms": 700, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.35, "passes": false}]}, {"scenario": "merge", "controller": "lans", "actor_seed": 44, "threshold_ms": 700, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.35, "passes": false}]}, {"scenario": "merge", "controller": "mpc_nominal", "actor_seed": 0, "threshold_ms": 700, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.97, "passes": true}, {"delay_ms": 1000, "collision": 0.01, "corridor_completion": 0.34, "passes": false}]}, {"scenario": "roundabout", "controller": "lans", "actor_seed": 42, "threshold_ms": 500, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.24, "passes": false}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.0, "passes": false}]}, {"scenario": "roundabout", "controller": "lans", "actor_seed": 43, "threshold_ms": 500, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.24, "passes": false}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.0, "passes": false}]}, {"scenario": "roundabout", "controller": "lans", "actor_seed": 44, "threshold_ms": 500, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.24, "passes": false}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.0, "passes": false}]}, {"scenario": "roundabout", "controller": "mpc_nominal", "actor_seed": 0, "threshold_ms": 500, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.23, "passes": false}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.0, "passes": false}]}]}

**Assessment:** The empirical findings support this narrow conclusion. They do not establish an actor advantage, general superiority or causal effects beyond the declared implementation intervention.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 235: WARN — paper.tex:247

**Status:** `unsupported_by_this_audit_scope`

**Paper:** The cold FIFO also imposes a control-authority limitation. Early queued commands may move the vehicle outside the reference corridor before a newly computed correction can act. Increasing search effort at the current decision cannot alter commands that have already entered the queue. The threshold is therefore partly a property of the complete protocol, initial queue, scenario, and reference geometry, not solely of the controller's optimization quality.

**Evidence:** null

**Assessment:** This is a logical consequence of the stated FIFO model, but initial queue contents, per-step reference departures and executed-command timing are absent from allowed logs; causal attribution cannot be independently verified here.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 236: PASS — paper.tex:249

**Status:** `scope_supported`

**Paper:** Several boundaries limit generalization. The benchmark uses synthetic disc vehicles, a finite horizon, structured state access, fixed actors, and a known command queue. It does not establish real-road safety, robustness to arbitrary uncertainty, or performance with perception failures. Sampling only finitely many trajectories cannot certify feasibility; retaining a plan does not create a safe terminal set. Information about queue-prefix violations is diagnostic and should not be advertised as a guarantee of recovery.

**Evidence:** {"study": ["extended_baselines"], "stage": ["confirmation"], "stage_status": ["complete"], "source_version": ["original_frozen"], "profile": ["fixed_fifo"], "scenario": ["highway", "intersection", "merge", "roundabout"], "controller": ["cbf", "lans", "lans_no_actor", "lans_no_prediction", "lqr", "lqr_acc", "mpc_nominal", "ppo_only", "predictor_lqr", "robust_lans", "robust_mpc", "robust_no_actor"], "actor_seed": [0, 42, 43, 44], "delay_ms": [0, 200, 500, 700, 1000]}

**Assessment:** The available empirical scope is four named scenarios, fixed_fifo, finite recorded cases and actor seeds; no broader benchmark evidence was supplied.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 237: WARN — paper.tex:249

**Status:** `unsupported_by_this_audit_scope`

**Paper:** Several boundaries limit generalization. The benchmark uses synthetic disc vehicles, a finite horizon, structured state access, fixed actors, and a known command queue. It does not establish real-road safety, robustness to arbitrary uncertainty, or performance with perception failures. Sampling only finitely many trajectories cannot certify feasibility; retaining a plan does not create a safe terminal set. Information about queue-prefix violations is diagnostic and should not be advertised as a guarantee of recovery.

**Evidence:** null

**Assessment:** These implementation/proof characterizations require code or proof artifacts absent from this audit; limited outcome evidence alone cannot certify or refute them.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 238: PASS — paper.tex:251

**Status:** `exact_match`

**Paper:** The analysis preserves failures, paired cases, and frozen source/model hashes. Nonetheless, raw logs do not contain full per-step trajectories for independently reconstructing every recorded episode RMSE; aggregate statistics are recomputed from the saved episode-level values and the frozen metric implementation is retained. Confidence intervals are marginal, actor repetitions share traffic cases, and the fixed set of three actor seeds does not characterize all possible training outcomes. Shared-session episode timings are not evidence of real-time execution guarantees.

**Evidence:** {"records": 44000, "shortened_collision_episodes": 4350, "matching_pairs": "all tests share exact episode seeds", "full_grid": "complete"}

**Assessment:** Every original allowed raw condition and failure is present in the exported evidence and descriptive table.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 239: PASS — paper.tex:251

**Status:** `exact_match`

**Paper:** The analysis preserves failures, paired cases, and frozen source/model hashes. Nonetheless, raw logs do not contain full per-step trajectories for independently reconstructing every recorded episode RMSE; aggregate statistics are recomputed from the saved episode-level values and the frozen metric implementation is retained. Confidence intervals are marginal, actor repetitions share traffic cases, and the fixed set of three actor seeds does not characterize all possible training outcomes. Shared-session episode timings are not evidence of real-time execution guarantees.

**Evidence:** {"freeze_manifest_hash_entries": 51, "model_archive_hash_entries": 12, "raw_summary_files": 440, "distinct_recorded_source_hashes": 1}

**Assessment:** The supplied manifest has 51 SHA256 entries including 12 model archives. All 440 raw summary-to-JSONL hashes verify. Source/checkpoint bytes and freeze chronology were excluded, so hash retention is verified, not actual source/model immutability.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.json

### Claim 240: PASS — paper.tex:251

**Status:** `exact_match`

**Paper:** The analysis preserves failures, paired cases, and frozen source/model hashes. Nonetheless, raw logs do not contain full per-step trajectories for independently reconstructing every recorded episode RMSE; aggregate statistics are recomputed from the saved episode-level values and the frozen metric implementation is retained. Confidence intervals are marginal, actor repetitions share traffic cases, and the fixed set of three actor seeds does not characterize all possible training outcomes. Shared-session episode timings are not evidence of real-time execution guarantees.

**Evidence:** {"raw_record_fields": ["actor_seed", "collision", "completion", "controller", "corridor_completion", "corridor_exceedance", "decision_ms_max", "decision_ms_median", "delay_ms", "episode_seed", "no_feasible_steps", "npc_position_error_accel", "npc_position_error_cv", "progress", "rmse", "scenario", "steps", "timeout"], "all_table_RMSE_means_match": true}

**Assessment:** Raw records contain episode RMSE, step count and episode diagnostics, but no arrays of lateral errors or per-step state/action trajectories. Per-episode RMSE itself cannot be independently reconstructed.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 241: WARN — paper.tex:251

**Status:** `unsupported_by_this_audit_scope`

**Paper:** The analysis preserves failures, paired cases, and frozen source/model hashes. Nonetheless, raw logs do not contain full per-step trajectories for independently reconstructing every recorded episode RMSE; aggregate statistics are recomputed from the saved episode-level values and the frozen metric implementation is retained. Confidence intervals are marginal, actor repetitions share traffic cases, and the fixed set of three actor seeds does not characterize all possible training outcomes. Shared-session episode timings are not evidence of real-time execution guarantees.

**Evidence:** null

**Assessment:** The manifest lists source hashes; the actual metric implementation is excluded, so neither its formula nor preservation is independently verified.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 242: PASS — paper.tex:251

**Status:** `scope_supported`

**Paper:** The analysis preserves failures, paired cases, and frozen source/model hashes. Nonetheless, raw logs do not contain full per-step trajectories for independently reconstructing every recorded episode RMSE; aggregate statistics are recomputed from the saved episode-level values and the frozen metric implementation is retained. Confidence intervals are marginal, actor repetitions share traffic cases, and the fixed set of three actor seeds does not characterize all possible training outcomes. Shared-session episode timings are not evidence of real-time execution guarantees.

**Evidence:** {"actor_seeds": [42, 43, 44], "same_traffic_seed_set": true, "Wilson_intervals": "per condition", "decision_timing": "episode summaries only"}

**Assessment:** Separate condition intervals and repeated actor/case structure agree. Timings lack the controlled execution metadata needed for hard runtime claims, which the paper avoids.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 243: PASS — paper.tex:254

**Status:** `scope_supported`

**Paper:** We presented and evaluated a queue-aware, trajectory-retaining supervisor for frozen learned driving policies under delayed command execution. The 44,000-record main grid and focused matched comparisons support the importance of queue prediction within this design, while revealing no corridor-completion benefit from the actor prior and no observed delay-threshold advantage over matched nominal MPC. Tracking differences are scenario-dependent, and failures remain visible. The resulting contribution is an empirically characterized supervision design and a reproducible comparison, with explicit limits on novelty, safety, and generalization.

**Evidence:** {"counts": {"episodes": 44000, "raw_episode_records": 44000, "raw_json_files": 440, "raw_jsonl_files": 440, "conditions": 440, "paired_tests": 3440, "descriptive_rows": 5720, "table_cells": 120, "csv_aggregate_rows": 300}, "contrasts": {"mpc_nominal": {"n": 60, "positive": 9, "negative": 0, "zero": 51, "positive_significant": 0, "negative_significant": 0, "max_positive_p_holm": 1.0}, "lans_no_prediction": {"n": 60, "positive": 45, "negative": 0, "zero": 15, "positive_significant": 45, "negative_significant": 0, "max_positive_p_holm": 0.0002608299255371094}, "lans_no_actor": {"n": 60, "positive": 0, "negative": 0, "zero": 60, "positive_significant": 0, "negative_significant": 0, "max_positive_p_holm": null}, "ppo_only": {"n": 60, "positive": 49, "negative": 0, "zero": 11, "positive_significant": 45, "negative_significant": 0, "max_positive_p_holm": 1.0}}, "thresholds": [{"scenario": "highway", "controller": "lans", "actor_seed": 42, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 1.0, "passes": true}]}, {"scenario": "highway", "controller": "lans", "actor_seed": 43, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 1.0, "passes": true}]}, {"scenario": "highway", "controller": "lans", "actor_seed": 44, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 1.0, "passes": true}]}, {"scenario": "highway", "controller": "mpc_nominal", "actor_seed": 0, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 1.0, "passes": true}]}, {"scenario": "intersection", "controller": "lans", "actor_seed": 42, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.01, "corridor_completion": 0.99, "passes": true}]}, {"scenario": "intersection", "controller": "lans", "actor_seed": 43, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.01, "corridor_completion": 0.99, "passes": true}]}, {"scenario": "intersection", "controller": "lans", "actor_seed": 44, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.01, "corridor_completion": 0.99, "passes": true}]}, {"scenario": "intersection", "controller": "mpc_nominal", "actor_seed": 0, "threshold_ms": 1000, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.99, "passes": true}]}, {"scenario": "merge", "controller": "lans", "actor_seed": 42, "threshold_ms": 700, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.35, "passes": false}]}, {"scenario": "merge", "controller": "lans", "actor_seed": 43, "threshold_ms": 700, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.35, "passes": false}]}, {"scenario": "merge", "controller": "lans", "actor_seed": 44, "threshold_ms": 700, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.35, "passes": false}]}, {"scenario": "merge", "controller": "mpc_nominal", "actor_seed": 0, "threshold_ms": 700, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 0.99, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.97, "passes": true}, {"delay_ms": 1000, "collision": 0.01, "corridor_completion": 0.34, "passes": false}]}, {"scenario": "roundabout", "controller": "lans", "actor_seed": 42, "threshold_ms": 500, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.24, "passes": false}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.0, "passes": false}]}, {"scenario": "roundabout", "controller": "lans", "actor_seed": 43, "threshold_ms": 500, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.24, "passes": false}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.0, "passes": false}]}, {"scenario": "roundabout", "controller": "lans", "actor_seed": 44, "threshold_ms": 500, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.24, "passes": false}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.0, "passes": false}]}, {"scenario": "roundabout", "controller": "mpc_nominal", "actor_seed": 0, "threshold_ms": 500, "points": [{"delay_ms": 0, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 200, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 500, "collision": 0.0, "corridor_completion": 1.0, "passes": true}, {"delay_ms": 700, "collision": 0.0, "corridor_completion": 0.23, "passes": false}, {"delay_ms": 1000, "collision": 0.0, "corridor_completion": 0.0, "passes": false}]}]}

**Assessment:** The concluding empirical statements agree with raw results. Causal component isolation and executable method details remain subject to the scope warnings above.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 244: WARN — paper.tex:258

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{kalaria} D. Kalaria, Q. Lin, and J. M. Dolan, ``Delay-aware robust control for safe autonomous driving and racing,'' arXiv:2208.13856v1, 2022.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 245: WARN — paper.tex:259

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{psf} K. P. Wabersich and M. N. Zeilinger, ``A predictive safety filter for learning-based control of constrained nonlinear dynamical systems,'' \emph{Automatica}, vol. 129, Art. no. 109597, 2021.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 246: WARN — paper.tex:260

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{paperone} R. Ali and J. Tian, ``Latency-aware path-tracking control for autonomous vehicles via analytical feedback and PPO-based residual compensation,'' author-supplied manuscript, undated.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 247: WARN — paper.tex:261

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{hewing} L. Hewing, K. P. Wabersich, M. Menner, and M. N. Zeilinger, ``Learning-based model predictive control: Toward safe learning in control,'' \emph{Annual Review of Control, Robotics, and Autonomous Systems}, vol. 3, pp. 269--296, 2020.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 248: WARN — paper.tex:262

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{brunke} L. Brunke \emph{et al.}, ``Safe learning in robotics: From learning-based control to safe reinforcement learning,'' \emph{Annual Review of Control, Robotics, and Autonomous Systems}, vol. 5, pp. 411--444, 2022.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 249: WARN — paper.tex:263

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{tearle} B. Tearle, K. P. Wabersich, A. Carron, and M. N. Zeilinger, ``A predictive safety filter for learning-based racing control,'' arXiv:2102.11907v1, 2021.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 250: WARN — paper.tex:264

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{sls} A. P. Leeman, J. K\"ohler, S. Bennani, and M. N. Zeilinger, ``Predictive safety filter using system level synthesis,'' in \emph{Proc. Learning for Dynamics and Control}, PMLR, vol. 211, pp. 1180--1192, 2023.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 251: WARN — paper.tex:265

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{cbfdelay} A. Singletary, Y. Chen, and A. D. Ames, ``Control barrier functions for sampled-data systems with input delays,'' in \emph{Proc. IEEE Conf. Decision and Control}, pp. 804--809, 2020.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 252: WARN — paper.tex:266

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{cano} F. Cano C\'ordoba, A. Palmisano, M. Fr\"anzle, R. Bloem, and B. K\"onighofer, ``Safety shielding under delayed observation,'' in \emph{Proc. Int. Conf. Automated Planning and Scheduling}, vol. 33, pp. 80--85, 2023.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 253: WARN — paper.tex:267

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{wang} W. Wang, D. Han, X. Luo, and D. Li, ``Addressing signal delay in deep reinforcement learning,'' in \emph{Proc. Int. Conf. Learning Representations}, 2024. [Online]. Available: \url{https://openreview.net/forum?id=Z8UfDs4J46}

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 254: WARN — paper.tex:268

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{dfbt} Q. Wu \emph{et al.}, ``Directly forecasting belief for reinforcement learning with delays,'' in \emph{Proc. Int. Conf. Machine Learning}, 2025.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 255: WARN — paper.tex:269

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{rlrd} Y. Bouteiller, S. Ramstedt, G. Beltrame, C. Pal, and J. Binas, ``Reinforcement learning with random delays,'' in \emph{Proc. Int. Conf. Learning Representations}, 2021.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 256: WARN — paper.tex:270

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{darom} A. Tabrizian, Z. Huang, A. Aziz, and P. Wei, ``Delay-aware reinforcement learning for highway on-ramp merging under stochastic communication latency,'' arXiv:2403.11852v5, May 2026.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 257: WARN — paper.tex:271

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{lubars} J. Lubars \emph{et al.}, ``Combining reinforcement learning with model predictive control for on-ramp merging,'' in \emph{Proc. IEEE Int. Intelligent Transportation Systems Conf.}, pp. 942--947, 2021.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 258: WARN — paper.tex:272

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{udatha} S. Udatha, Y. Lyu, and J. Dolan, ``Reinforcement learning with probabilistically safe control barrier functions for ramp merging,'' in \emph{Proc. IEEE Int. Conf. Robotics and Automation}, pp. 5625--5630, 2023.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 259: WARN — paper.tex:273

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{yuan} Z. Yuan \emph{et al.}, ``Safe-control-gym: A unified benchmark suite for safe learning-based control and reinforcement learning in robotics,'' \emph{IEEE Robotics and Automation Letters}, vol. 7, no. 4, pp. 11142--11149, 2022.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 260: WARN — paper.tex:274

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{ppo} J. Schulman, F. Wolski, P. Dhariwal, A. Radford, and O. Klimov, ``Proximal policy optimization algorithms,'' arXiv:1707.06347, 2017.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 261: WARN — paper.tex:275

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{sb3} A. Raffin \emph{et al.}, ``Stable-Baselines3: Reliable reinforcement learning implementations,'' \emph{Journal of Machine Learning Research}, vol. 22, no. 268, pp. 1--8, 2021.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 262: WARN — paper.tex:276

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{agarwal} R. Agarwal, M. Schwarzer, P. S. Castro, A. C. Courville, and M. G. Bellemare, ``Deep reinforcement learning at the edge of the statistical precipice,'' in \emph{Advances in Neural Information Processing Systems}, vol. 34, 2021.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 263: WARN — paper.tex:277

**Status:** `unsupported_by_this_audit_scope`

**Paper:** \bibitem{holm} S. Holm, ``A simple sequentially rejective multiple test procedure,'' \emph{Scandinavian Journal of Statistics}, vol. 6, no. 2, pp. 65--70, 1979.

**Evidence:** null

**Assessment:** Cited publication texts and bibliographic databases are not allowed evidence inputs. This audit makes no citation-accuracy finding.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/EXTENDED_FREEZE.json, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl

### Claim 264: PASS — Evidence consistency

**Status:** `exact_match`

**Paper:** Raw-to-export join and complete case preservation

**Evidence:** {"episodes": 44000, "raw_episode_records": 44000, "raw_json_files": 440, "raw_jsonl_files": 440, "conditions": 440, "paired_tests": 3440, "descriptive_rows": 5720, "table_cells": 120, "csv_aggregate_rows": 300}

**Assessment:** All fields present in original raw episode objects exactly match exported episode values. All original per-condition summaries reconcile, including percentages and means.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl, /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.json, evidence/episodes.jsonl

### Claim 265: PASS — Evidence consistency

**Status:** `exact_match`

**Paper:** Companion aggregate table values

**Evidence:** {"rows_checked": 300, "discrepancies": 0}

**Assessment:** Every n, mean RMSE, route-completion count, corridor-completion count and collision count was independently recomputed from raw episodes.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl, evidence/all_controller_delay_table.csv, evidence/all_controller_delay_by_scenario.csv

### Claim 266: PASS — Evidence consistency

**Status:** `exact_match`

**Paper:** Descriptive available means, sample SD, min/max, 5th/50th/95th percentiles, n, worst-observed endpoints and Wilson intervals

**Evidence:** {"rows": 5720, "unavailable_diagnostic_rows": 140, "available_rows": 5580, "discrepancies": 0}

**Assessment:** For 140 explicitly unavailable no_feasible_steps rows, n=0 and missing summaries are retained; runner-default zeros are not treated as measurements. All remaining numeric summaries listed here and Wilson endpoints reconcile. Worst-observed values equal the minimum for completion/corridor completion/progress and maximum for other metrics; this verifies the supplied convention, not a substantive claim that a larger step count is scientifically worse. Bootstrap endpoints were not independently regenerated.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl, evidence/descriptive_metrics.csv

### Claim 267: PASS — Evidence consistency

**Status:** `exact_match`

**Paper:** Raw paired contrasts and family-wide multiplicity

**Evidence:** {"matched_tests": 3440, "raw_p_recomputations": 3440, "Holm_recomputations": 3440, "discrepancies": 0}

**Assessment:** Each per-condition paired mean, binary discordance count, exact test or signed-rank p-value and full-family Holm adjustment agrees.

**Provenance:** /workspace/recovery/restored/LANS-RISK/working/extended_baselines/confirmation/*.jsonl, evidence/paired_tests.csv
