"""Experimental finite-horizon authority selector, not a safety certificate."""
import numpy as np
from numba import njit
from observable_mpc import propagate,nominal_steering
from extended_suite import ProtocolEnv

def packet(env):
 return dict(ego=np.array([*env.ego.position,env.ego.heading,env.ego.velocity],dtype=float),npcs=np.array([[*n.position,n.heading,n.velocity] for n in env.npcs],dtype=float).reshape(-1,4),pending=np.array(list(env.pending),dtype=float).reshape(-1,2),desired_speed=env.config['desired_speed'])
class DirectEnv(ProtocolEnv):
 def step(self,action):
  self.beta=1.; self.safety_enabled=False
  return super().step(action)

@njit(cache=True)
def rollout_clearance(state,npcs,command,scenario):
 s=state.copy();n=npcs.copy();margin=1e6
 for t in range(20):
  # Five-tick candidate followed by a geometric-steering braking backup.
  steer=command[0] if t<5 else nominal_steering(s,scenario)
  accel=command[1] if t<5 else -1.
  s,n,c=propagate(s,n,steer,accel,scenario)
  margin=min(margin,c)
 return margin

class QueueAuthority:
 def __init__(self,scenario,compensate=True):
  self.scenario=['highway','merge','intersection','roundabout'].index(scenario)
  self.compensate=compensate
 def action(self,env,ppo):
  data=packet(env);state=data['ego'];npcs=data['npcs'];prefix=1e6
  if self.compensate:
   for command in data['pending']:
    state,npcs,clearance=propagate(state,npcs,float(command[0]),float(command[1]),self.scenario)
    prefix=min(prefix,clearance)
  ey,ep=env._compute_raw_errors()
  lqr=float(env.lqr.compute_action(dict(lateral_error=ey,lateral_error_rate=env.e_y_dot_hat,yaw_error=ep,yaw_error_rate=env.e_psi_dot_hat,speed=env.ego.velocity),env._reference_curvature())[0])
  beta=env.beta; alphas=[beta,0.,.25,.5,.75,1.]
  commands=[np.array([a*float(ppo[0])+(1-a)*lqr,float(ppo[1])],dtype=float) for a in alphas]
  margins=np.array([rollout_clearance(state,npcs,c,self.scenario) for c in commands])
  feasible=np.flatnonzero(margins>=.1)
  if len(feasible):
   selected=min(feasible,key=lambda i:abs(alphas[i]-beta))
   action=commands[selected];authority=alphas[selected];status='AUTHORITY_ACCEPTED' if selected==0 else 'AUTHORITY_REDUCED_OR_CHANGED'
   chosen=float(margins[selected])
  else:
   options=[np.array([nominal_steering(state,self.scenario),-1.]),np.array([0.,-1.]),np.array([lqr,-1.])]
   backup=np.array([rollout_clearance(state,npcs,c,self.scenario) for c in options])
   selected=int(np.argmax(backup));action=options[selected];chosen=float(backup[selected]);authority=-1.
   status='BRAKE_BACKUP' if chosen>=.1 else 'NO_SAMPLED_SAFE_BACKUP'
  self.log=dict(authority=float(authority),predicted_clearance=chosen,prefix_clearance=float(prefix),decision=status)
  return np.clip(action,-1,1).astype(np.float32)
