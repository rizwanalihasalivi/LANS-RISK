"""
LANS-Risk — Scenario Configuration
Matches Paper Table 3, Table 5, and Table 4 (OBS_DIM = 18)
"""

# =============================================================
# Observation dimension (Table 4)
# =============================================================
OBSERVATION_DIM = 18

# =============================================================
# Table 3 — Reference physical parameters
# =============================================================
VEHICLE = {
    "m": 1650.0,           # kg
    "Iz": 4224.0,          # kg·m²
    "lf": 1.2,             # m
    "lr": 1.4,             # m
    "L":  2.6,             # m  (lf + lr)
    "Cf": 80_000.0,        # N/rad — combined axle (no factor of 2)
    "Cr": 80_000.0,        # N/rad
    "delta_max": 0.50,     # rad — front-wheel steering limit
    "a_max": 3.5,          # m/s²
    "v_max": 25.0,         # m/s
    "b_disc": 2.423,       # m — disc radius
    "body_len": 4.5,       # m
    "body_wid": 1.8,       # m
    "alpha_filter": 0.25,  # Eq. (4) derivative filter
    "D_th": 0.50,          # m — clearance trigger
    "h_r": 0.25,           # s — release margin
    "h_D": 0.50,           # m — release margin
    "k_w": 0.60,           # warning brake coefficient (Table 3)
    "sigma_c": 1.40,       # s — conflict-time scale
}

# =============================================================
# Table 10 — Recomputed LQR gains (4-state [e_y, ė_y, e_ψ, ė_ψ])
# =============================================================
LQR_GAIN_TABLE = {
    2.0:  [0.83469, 0.01978, 1.44476, 0.04841],
    5.0:  [0.63326, 0.04946, 1.53566, 0.10931],
    10.0: [0.50235, 0.08222, 1.68814, 0.15074],
    15.0: [0.44912, 0.09933, 1.80438, 0.16728],
    20.0: [0.42010, 0.10977, 1.89682, 0.17593],
    25.0: [0.40161, 0.11695, 1.97208, 0.18108],
}

# =============================================================
# Table 5 — Reference thresholds + scenario metadata
# =============================================================
SCENARIO_CONFIGS = {
    "highway": {
        "training_steps": 300_000,
        "n_envs": 8,
        "learning_rate": 3e-4,
        "desired_speed": 15.0,
        "ttc_danger": 1.75,
        "ttc_warning": 2.90,
        "min_latency_ms": 5.0,
        "max_latency_ms": 40.0,
        "max_latency": 40.0,
        "beta_sensitivity": 10.0,
        "beta_midpoint_tau_hat": 0.6,
        "complexity": 0.3,
        "goal_distance": 80.0,
        "nominal_npcs": 5,
    },
    "merge": {
        "training_steps": 300_000,
        "n_envs": 8,
        "learning_rate": 3e-4,
        "desired_speed": 12.0,
        "ttc_danger": 1.70,
        "ttc_warning": 2.85,
        "min_latency_ms": 5.0,
        "max_latency_ms": 40.0,
        "max_latency": 40.0,
        "beta_sensitivity": 10.0,
        "beta_midpoint_tau_hat": 0.6,
        "complexity": 0.5,
        "goal_distance": 60.0,
        "nominal_npcs": 6,
    },
    "intersection": {
        "training_steps": 300_000,
        "n_envs": 8,
        "learning_rate": 2.5e-4,
        "desired_speed": 8.0,
        "ttc_danger": 0.75,
        "ttc_warning": 1.50,
        "min_latency_ms": 5.0,
        "max_latency_ms": 40.0,
        "max_latency": 40.0,
        "beta_sensitivity": 10.0,
        "beta_midpoint_tau_hat": 0.6,
        "complexity": 0.8,
        "goal_distance": 50.0,
        "nominal_npcs": 3,
    },
    "roundabout": {
        "training_steps": 300_000,
        "n_envs": 8,
        "learning_rate": 3e-4,
        "desired_speed": 9.0,
        "ttc_danger": 2.80,
        "ttc_warning": 3.80,
        "min_latency_ms": 5.0,
        "max_latency_ms": 40.0,
        "max_latency": 40.0,
        "beta_sensitivity": 10.0,
        "beta_midpoint_tau_hat": 0.6,
        "complexity": 0.6,
        "goal_distance": 60.0,
        "nominal_npcs": 4,
    },
}


def get_scenario_config(scenario):
    if scenario not in SCENARIO_CONFIGS:
        raise ValueError(f"Unknown scenario: {scenario}")
    return SCENARIO_CONFIGS[scenario].copy()


SCENARIO_NAMES = {
    "highway": "Highway",
    "merge": "Merge",
    "intersection": "Intersection",
    "roundabout": "Roundabout",
}