"""
LANS-Risk Environment — Paper-Accurate Reference Implementation
Implements the corrected reference design from Sections 4-5:
  Eq. (2), (4)-(7), (9)-(13), (17)-(22); Tables 3, 4, 5, 10.

Path-B spawn geometry:
  - Highway:      1 NPC in ego lane at 25-35 m, rest in adjacent lanes
  - Merge:        80% on target lane far ahead, 20% on ramp
  - Intersection: 1 crossing NPC; 50% matched arrival, 50% free
  - Roundabout:   ego on circle, tangent heading; NPCs at 0.9-2.5 rad ahead

Extensions (both off by default):
  obs_delay_steps > 0    -> policy sees observation from N control steps ago
  symbolic_gate          -> supervisor logs SymbolicAction + facts in info
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, List
from collections import deque

import gymnasium as gym
import numpy as np

from scenario_config import get_scenario_config, VEHICLE
from lqr_controller import LQRController
from ttc import geometric_ttc, intersection_conflict_ttc
from risk_supervisor import RiskSupervisor, SAFE, WARNING, DANGER


@dataclass
class Vehicle:
    position: np.ndarray
    velocity: float
    heading: float
    acceleration: float
    vehicle_id: int
    is_ego: bool = False
    desired_speed: float = 10.0


class LANSEnvScenarioAware(gym.Env):
    metadata = {"render_modes": []}
    OBS_DIM = 18

    def __init__(self, scenario="highway", seed=None,
                 latency_enabled=True, safety_enabled=True, lqr_enabled=True,
                 obs_delay_steps=0):
        super().__init__()
        self.scenario = scenario
        self.config = get_scenario_config(scenario)

        self.latency_enabled = latency_enabled
        self.safety_enabled = safety_enabled
        self.lqr_enabled = lqr_enabled

        # Observation delay (in control steps of dt = 0.1 s)
        self.obs_delay_steps = int(obs_delay_steps)
        if self.obs_delay_steps > 0:
            self._obs_queue = deque(maxlen=self.obs_delay_steps + 1)
        else:
            self._obs_queue = None

        self.T_d = float(self.config["ttc_danger"])
        self.T_w = float(self.config["ttc_warning"])
        self.tau_min = float(self.config["min_latency_ms"])
        self.tau_max = float(self.config["max_latency_ms"])
        self.beta_k   = float(self.config["beta_sensitivity"])
        self.beta_mid = float(self.config["beta_midpoint_tau_hat"])

        self.dt = 0.1
        self.max_steps = 80

        self.np_random = np.random.default_rng(seed)

        self.action_space = gym.spaces.Box(-1.0, 1.0, shape=(2,), dtype=np.float32)
        self.observation_space = gym.spaces.Box(-1.0, 1.0, shape=(self.OBS_DIM,), dtype=np.float32)

        self.lqr = LQRController() if lqr_enabled else None
        self.supervisor = RiskSupervisor(self.T_d, self.T_w)

        self.alpha = float(VEHICLE["alpha_filter"])
        self.e_y_prev = 0.0
        self.e_psi_prev = 0.0
        self.e_y_dot_hat = 0.0
        self.e_psi_dot_hat = 0.0
        self.last_executed_steering = 0.0

        self.step_count = 0
        self.latency_ms = self.tau_min
        self.beta = 1.0
        self.ego: Optional[Vehicle] = None
        self.npcs: List[Vehicle] = []
        self.roundabout_radius = 8.0
        self.roundabout_start_angle: Optional[float] = None
        self.roundabout_unwrapped_angle: Optional[float] = None
        self.route_start_x = 0.0
        self.collision_count = 0
        self.episode_count = 0
        self._reset_state()

    # ---------------- spawning ----------------
    def _spawn_vehicles(self):
        n_npc = int(self.config["nominal_npcs"])

        # ---------- INTERSECTION ----------
        if self.scenario == "intersection":
            ego_x = self.np_random.uniform(-24.0, -20.0)
            self.ego = Vehicle(
                position=np.array([ego_x, 0.0]),
                velocity=self.np_random.uniform(6.0, 7.5), heading=0.0,
                acceleration=0.0, vehicle_id=0, is_ego=True,
                desired_speed=self.np_random.uniform(7.0, 9.0))
            self.npcs = []
            d = self.np_random.choice(["north", "south"])
            if self.np_random.random() < 0.5:
                y_mag = self.np_random.uniform(15.0, 22.0)
            else:
                y_mag = self.np_random.uniform(32.0, 45.0)
            if d == "north":
                x = self.np_random.uniform(-2.0, 2.0)
                y = y_mag
                h = -np.pi / 2
            else:
                x = self.np_random.uniform(-2.0, 2.0)
                y = -y_mag
                h = np.pi / 2
            self.npcs.append(Vehicle(
                position=np.array([x, y]),
                velocity=self.np_random.uniform(4.5, 6.0), heading=h,
                acceleration=0.0, vehicle_id=1, is_ego=False,
                desired_speed=self.np_random.uniform(5.0, 7.5)))
            return

        # ---------- ROUNDABOUT ----------
        if self.scenario == "roundabout":
            R = self.roundabout_radius
            theta0 = self.np_random.uniform(0.0, 2.0 * np.pi)
            self.roundabout_start_angle = float(theta0)
            self.roundabout_unwrapped_angle = float(theta0)
            self.ego = Vehicle(
                position=np.array([R * np.cos(theta0), R * np.sin(theta0)]),
                velocity=self.np_random.uniform(5.5, 7.5),
                heading=theta0 + np.pi / 2.0,
                acceleration=0.0, vehicle_id=0, is_ego=True,
                desired_speed=self.np_random.uniform(6.5, 8.0))
            self.npcs = []
            base_thetas = np.linspace(0.9, 2.5, n_npc)
            jitter = self.np_random.uniform(-0.10, 0.10, n_npc)
            for i in range(n_npc):
                theta_i = theta0 + base_thetas[i] + jitter[i]
                self.npcs.append(Vehicle(
                    position=np.array([R * np.cos(theta_i), R * np.sin(theta_i)]),
                    velocity=self.np_random.uniform(4.0, 7.0),
                    heading=theta_i + np.pi / 2.0,
                    acceleration=0.0, vehicle_id=i + 1, is_ego=False,
                    desired_speed=self.np_random.uniform(5.0, 8.0)))
            return

        # ---------- MERGE ----------
        if self.scenario == "merge":
            self.ego = Vehicle(
                position=np.array([0.0, -3.5]),
                velocity=self.np_random.uniform(11.0, 15.0), heading=0.0,
                acceleration=0.0, vehicle_id=0, is_ego=True,
                desired_speed=self.np_random.uniform(13.0, 17.0))
            self.npcs = []
            for i in range(n_npc):
                if self.np_random.random() < 0.8:
                    y_off = self.np_random.uniform(-0.9, 0.9)
                    x_off = self.np_random.uniform(30.0, 70.0)
                else:
                    y_off = self.np_random.uniform(-4.3, -2.7)
                    x_off = self.np_random.uniform(20.0, 45.0)
                self.npcs.append(Vehicle(
                    position=np.array([x_off, y_off]),
                    velocity=self.np_random.uniform(4.0, 9.5),
                    heading=self.np_random.uniform(-0.05, 0.05),
                    acceleration=0.0, vehicle_id=i + 1, is_ego=False,
                    desired_speed=self.np_random.uniform(9.5, 13.5)))
            return

        # ---------- HIGHWAY ----------
        self.ego = Vehicle(
            position=np.array([0.0, 0.0]),
            velocity=self.np_random.uniform(11.0, 15.0), heading=0.0,
            acceleration=0.0, vehicle_id=0, is_ego=True,
            desired_speed=self.np_random.uniform(13.0, 17.0))
        self.npcs = []
        for i in range(n_npc):
            if i == 0:
                x_off = self.np_random.uniform(25.0, 35.0)
                y_off = self.np_random.uniform(-0.8, 0.8)
            elif self.np_random.random() < 0.7:
                y_off = float(self.np_random.choice([-3.5, 3.5]) + self.np_random.uniform(-0.5, 0.5))
                x_off = self.np_random.uniform(35.0, 80.0)
            else:
                y_off = self.np_random.uniform(-0.8, 0.8)
                x_off = self.np_random.uniform(45.0, 80.0)
            self.npcs.append(Vehicle(
                position=np.array([x_off, y_off]),
                velocity=self.np_random.uniform(4.0, 9.5),
                heading=0.0,
                acceleration=0.0, vehicle_id=i + 1, is_ego=False,
                desired_speed=self.np_random.uniform(9.5, 13.5)))

    # ---------------- reference curvature (Eq. 12) ----------------
    def _reference_curvature(self):
        x, y = self.ego.position
        if self.scenario in ("highway", "intersection"):
            return 0.0
        if self.scenario == "merge":
            if x <= 0.0 or x >= 25.0:
                return 0.0
            z = x / 25.0
            fp  =  30 * z**2 - 60 * z**3 + 30 * z**4
            fpp =  60 * z    - 180 * z**2 + 120 * z**3
            yp  = 3.5 * fp  / 25.0
            ypp = 3.5 * fpp / 625.0
            return float(ypp / (1.0 + yp**2) ** 1.5)
        if self.scenario == "roundabout":
            return 1.0 / self.roundabout_radius
        return 0.0

    def _sample_latency_context(self):
        """Sample the synthetic timing context for the next decision.

        The context must be present in the observation that precedes the
        action it supervises.  Sampling it inside ``step`` after the action
        has already been produced creates a one-step information mismatch.
        """
        if self.latency_enabled:
            self.latency_ms = float(self.np_random.uniform(self.tau_min, self.tau_max))
        else:
            self.latency_ms = self.tau_min
        self.beta = self.compute_beta(self.latency_ms)

    # ---------------- raw errors (Eq. 3) ----------------
    def _compute_raw_errors(self):
        x, y = self.ego.position
        psi = self.ego.heading

        if self.scenario in ("highway", "intersection"):
            y_ref, psi_ref = 0.0, 0.0
        elif self.scenario == "merge":
            if x <= 0.0:
                y_ref, psi_ref = -3.5, 0.0
            elif x >= 25.0:
                y_ref, psi_ref = 0.0, 0.0
            else:
                z = x / 25.0
                f = 10 * z**3 - 15 * z**4 + 6 * z**5
                df = (30 * z**2 - 60 * z**3 + 30 * z**4) / 25.0
                y_ref = -3.5 + 3.5 * f
                psi_ref = float(np.arctan(3.5 * df))
        elif self.scenario == "roundabout":
            R = self.roundabout_radius
            r = float(np.linalg.norm([x, y]))
            if r < 1e-6:
                return -R, float(np.arctan2(np.sin(psi), np.cos(psi)))
            angle = float(np.arctan2(y, x))
            # Positive error is left of the CCW reference tangent (inward).
            lateral = R - r
            tangent = angle + np.pi / 2.0
            heading = float(np.arctan2(np.sin(psi - tangent), np.cos(psi - tangent)))
            return float(lateral), heading
        else:
            y_ref, psi_ref = 0.0, 0.0

        lateral = y - y_ref
        heading = float(np.arctan2(np.sin(psi - psi_ref), np.cos(psi - psi_ref)))
        return float(lateral), heading

    # ---------------- risk records (Eq. 5-7) ----------------
    def _time_to_conflict_point(self, veh, point):
        r = point - veh.position
        d = float(np.linalg.norm(r))
        if d < 1e-6:
            return 0.0
        if veh.velocity < 0.1:
            return float("inf")
        v = veh.velocity * np.array([np.cos(veh.heading), np.sin(veh.heading)])
        speed_toward = float(v @ (r / d))
        if speed_toward <= 1e-3:
            return float("inf")
        return d / speed_toward

    def _build_npc_records(self):
        records = []
        p_e = self.ego.position; psi_e = self.ego.heading; v_e = self.ego.velocity
        b_e = float(VEHICLE["b_disc"]); b_n = float(VEHICLE["b_disc"])
        for npc in self.npcs:
            T_geom, C_i = geometric_ttc(p_e, psi_e, v_e,
                                        npc.position, npc.heading, npc.velocity,
                                        b_ego=b_e, b_npc=b_n)
            D_i = float(np.linalg.norm(npc.position - p_e) - (b_e + b_n))
            r = npc.position - p_e
            bearing_global = float(np.arctan2(r[1], r[0]))
            phi = float(np.arctan2(np.sin(bearing_global - psi_e),
                                   np.cos(bearing_global - psi_e)))
            T_conf = float("inf")
            if self.scenario == "intersection":
                cp = np.array([0.0, 0.0])
                tau_e = self._time_to_conflict_point(self.ego, cp)
                tau_i = self._time_to_conflict_point(npc, cp)
                T_conf = intersection_conflict_ttc(tau_e, tau_i)
            T_i = min(T_geom, T_conf)
            records.append({"npc": npc, "T_geom": T_geom, "T_conf": T_conf,
                            "T_i": float(T_i), "D_i": D_i, "phi_i": phi, "C_i": C_i})
        return records

    def _select_critical(self, records):
        if not records:
            return None
        return min(records, key=lambda r: (r["T_i"], r["D_i"], r["npc"].vehicle_id))

    # ---------------- Eq. (13) ----------------
    def compute_beta(self, latency_ms):
        if not self.latency_enabled:
            return 1.0
        tau_hat = (latency_ms - self.tau_min) / (self.tau_max - self.tau_min)
        # Eq. (13): beta decreases monotonically as timing context increases.
        # The absolute value incorrectly makes beta rise again below the
        # midpoint and gives low-latency inputs almost no neural authority.
        exponent = np.clip(self.beta_k * (tau_hat - self.beta_mid), -60.0, 60.0)
        beta = 1.0 / (1.0 + np.exp(exponent))
        return float(np.clip(beta, 0.05, 0.95))

    # ---------------- obs (Table 4, 18-dim) ----------------
    def _get_obs(self, records):
        e_y, e_psi = self._compute_raw_errors()
        d_e_y = e_y - self.e_y_prev
        d_e_psi = float(np.arctan2(np.sin(e_psi - self.e_psi_prev),
                                   np.cos(e_psi - self.e_psi_prev)))
        self.e_y_dot_hat   = self.alpha * (d_e_y   / self.dt) + (1 - self.alpha) * self.e_y_dot_hat
        self.e_psi_dot_hat = self.alpha * (d_e_psi / self.dt) + (1 - self.alpha) * self.e_psi_dot_hat
        self.e_y_prev, self.e_psi_prev = e_y, e_psi

        crit = self._select_critical(records)
        if crit is None:
            D_crit, T_crit, phi_crit = 50.0, 10.0, 0.0
        else:
            D_crit, T_crit, phi_crit = crit["D_i"], crit["T_i"], crit["phi_i"]

        d_lqr = 0.0
        if self.lqr_enabled and self.lqr is not None:
            d_lqr = float(self.lqr.compute_action({
                "lateral_error": e_y, "lateral_error_rate": self.e_y_dot_hat,
                "yaw_error": e_psi, "yaw_error_rate": self.e_psi_dot_hat,
                "speed": self.ego.velocity},
                curvature=self._reference_curvature())[0])

        one_hot = np.zeros(4, dtype=np.float32)
        one_hot[["highway", "merge", "intersection", "roundabout"].index(self.scenario)] = 1.0

        obs = np.array([
            np.clip(e_y / 5.0, -1.0, 1.0),
            np.clip(self.e_y_dot_hat / 10.0, -1.0, 1.0),
            np.clip(e_psi / np.pi, -1.0, 1.0),
            np.clip(self.e_psi_dot_hat / 2.0, -1.0, 1.0),
            np.clip(self.ego.velocity / 25.0, 0.0, 1.0),
            float(self.last_executed_steering),
            np.clip(self.ego.acceleration / VEHICLE["a_max"], -1.0, 1.0),
            float(np.clip(D_crit / 50.0, -1.0, 1.0)) if np.isfinite(D_crit) else 1.0,
            float(np.clip(T_crit / 10.0, 0.0, 1.0)) if np.isfinite(T_crit) else 1.0,
            float(np.clip(len(self.npcs) / 8.0, 0.0, 1.0)),
            *one_hot.tolist(),
            float(np.clip(phi_crit / np.pi, -1.0, 1.0)),
            float(np.clip((self.latency_ms - self.tau_min) / (self.tau_max - self.tau_min), 0.0, 1.0)),
            float(self.beta),
            float(np.clip(d_lqr, -1.0, 1.0)),
        ], dtype=np.float32)
        obs = np.nan_to_num(obs, nan=0.0, posinf=1.0, neginf=-1.0)
        obs = np.clip(obs, -1.0, 1.0)

        # ---- Observation delay queue ----
        if self._obs_queue is not None:
            while len(self._obs_queue) < self.obs_delay_steps:
                self._obs_queue.append(obs.copy())
            self._obs_queue.append(obs.copy())
            return self._obs_queue[0].copy()
        return obs

    # ---------------- Eq. (2) propagation ----------------
    def _update_dynamics(self, action):
        d = float(np.clip(action[0], -1.0, 1.0))
        a = float(np.clip(action[1], -1.0, 1.0))
        delta_f = VEHICLE["delta_max"] * d
        a_x = VEHICLE["a_max"] * a
        self.ego.acceleration = a_x
        self.ego.velocity = float(np.clip(self.ego.velocity + a_x * self.dt,
                                          0.0, VEHICLE["v_max"]))
        dpsi = self.ego.velocity * np.tan(delta_f) / VEHICLE["L"] * self.dt
        new_psi = self.ego.heading + dpsi
        self.ego.heading = float(np.arctan2(np.sin(new_psi), np.cos(new_psi)))
        self.ego.position = self.ego.position + self.ego.velocity * self.dt * np.array(
            [np.cos(self.ego.heading), np.sin(self.ego.heading)])

        if self.scenario == "roundabout":
            self._update_roundabout_progress()

        for npc in self.npcs:
            if self.scenario == "roundabout":
                # Keep background vehicles on the circular route instead of
                # sending tangent-initialized vehicles on straight rays.
                theta = float(np.arctan2(npc.position[1], npc.position[0]))
                theta += float(npc.velocity * self.dt / self.roundabout_radius)
                npc.position = self.roundabout_radius * np.array(
                    [np.cos(theta), np.sin(theta)], dtype=float)
                npc.heading = float(theta + np.pi / 2.0)
                continue
            gap = float(np.linalg.norm(npc.position - self.ego.position))
            desired_gap = (4.5 + npc.velocity * 0.5) if gap < 12.0 else (2.8 + npc.velocity * 0.35)
            if gap < desired_gap:
                npc.acceleration = -1.8 * (1.0 - gap / desired_gap)
            else:
                npc.acceleration = 0.4 * (1.0 - npc.velocity / npc.desired_speed)
            npc.velocity = float(np.clip(npc.velocity + npc.acceleration * self.dt, 0.3, 20.0))
            npc.position = npc.position + npc.velocity * self.dt * np.array(
                [np.cos(npc.heading), np.sin(npc.heading)])
        self.step_count += 1

    def _update_roundabout_progress(self):
        if self.scenario != "roundabout" or self.ego is None:
            return
        angle = float(np.arctan2(self.ego.position[1], self.ego.position[0]))
        if self.roundabout_unwrapped_angle is None:
            self.roundabout_unwrapped_angle = angle
            if self.roundabout_start_angle is None:
                self.roundabout_start_angle = angle
            return
        delta = float(np.arctan2(
            np.sin(angle - self.roundabout_unwrapped_angle),
            np.cos(angle - self.roundabout_unwrapped_angle)))
        self.roundabout_unwrapped_angle += delta

    def _route_progress(self):
        """Return normalized route progress used by the success diagnostic."""
        if self.ego is None:
            return 0.0
        if self.scenario == "roundabout":
            if self.roundabout_start_angle is None or self.roundabout_unwrapped_angle is None:
                return 0.0
            return max(0.0, float(
                (self.roundabout_unwrapped_angle - self.roundabout_start_angle)
                / (2.0 * np.pi)))
        goal = max(float(self.config["goal_distance"]), 1e-9)
        return max(0.0, float(
            (self.ego.position[0] - self.route_start_x) / goal))

    def _route_complete(self):
        progress = self._route_progress()
        if self.scenario == "merge":
            return progress >= 1.0 and abs(float(self.ego.position[1])) < 1.0
        return progress >= 1.0

    def _check_collision(self):
        R = 2.0 * float(VEHICLE["b_disc"])
        for npc in self.npcs:
            if float(np.linalg.norm(npc.position - self.ego.position)) <= R:
                return True
        return False

    # ---------------- Eq. (21) reward ----------------
    def _risk_penalty(self, T_min):
        if not np.isfinite(T_min):
            return 0.0
        if T_min >= 2.2:
            return 0.0
        if T_min >= 1.0:
            return -4.0 * (2.2 - T_min) / 1.2
        return -4.0 - 12.0 * (1.0 - T_min)

    def _compute_reward(self, executed_action, records):
        v_next = float(self.ego.velocity)
        e_y_next = abs(float(self._compute_raw_errors()[0]))
        T_min = min((r["T_i"] for r in records), default=float("inf"))
        c_int = {SAFE: 0.0, WARNING: 0.11, DANGER: 0.51}[self.supervisor.state]
        r = (0.06 * v_next - 0.05 * e_y_next
             - 0.0015 * abs(float(executed_action[0]))
             + 0.5 + self._risk_penalty(T_min) - c_int)
        return float(np.clip(r, -200.0, 200.0))

    # ---------------- reset / step ----------------
    def _reset_state(self):
        self.step_count = 0
        self.latency_ms = self.tau_min
        self.beta = 1.0
        self.e_y_prev = self.e_psi_prev = 0.0
        self.e_y_dot_hat = self.e_psi_dot_hat = 0.0
        self.last_executed_steering = 0.0
        self.supervisor.reset()
        if self._obs_queue is not None:
            self._obs_queue.clear()
        self._spawn_vehicles()
        self.route_start_x = float(self.ego.position[0])
        e_y, e_psi = self._compute_raw_errors()
        self.e_y_prev, self.e_psi_prev = e_y, e_psi

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        self.episode_count += 1
        self._reset_state()
        self._sample_latency_context()
        records = self._build_npc_records()
        return self._get_obs(records), {}

    def step(self, action):
        action = np.asarray(action, dtype=np.float32).reshape(-1)

        # The returned observation already contains the timing context used
        # for this action.  Do not resample it after receiving the action.
        records = self._build_npc_records()

        d_lqr = 0.0
        if self.lqr_enabled and self.lqr is not None:
            e_y, e_psi = self._compute_raw_errors()
            d_lqr = float(self.lqr.compute_action({
                "lateral_error": e_y, "lateral_error_rate": self.e_y_dot_hat,
                "yaw_error": e_psi, "yaw_error_rate": self.e_psi_dot_hat,
                "speed": self.ego.velocity},
                curvature=self._reference_curvature())[0])

        d_ppo = float(np.clip(action[0], -1.0, 1.0))
        a_ppo = float(np.clip(action[1], -1.0, 1.0))
        d_fuse = self.beta * d_ppo + (1.0 - self.beta) * d_lqr
        a_fuse = a_ppo
        fused = np.array([d_fuse, a_fuse], dtype=np.float32)

        if self.safety_enabled:
            self.supervisor.update_state(records)
            tau_hat = (self.latency_ms - self.tau_min) / max(self.tau_max - self.tau_min, 1e-9)
            safe_action, sup_state, modified = self.supervisor.apply(
                fused, records, tau_hat=tau_hat, beta=self.beta)
        else:
            safe_action, sup_state, modified = fused, SAFE, False
            self.supervisor.state = SAFE

        self._update_dynamics(safe_action)
        self.last_executed_steering = float(safe_action[0])

        collided = self._check_collision()
        post_records = self._build_npc_records()
        reward = self._compute_reward(safe_action, post_records)
        if collided:
            self.collision_count += 1

        # Success is a route-progress diagnostic.  As specified in the
        # manuscript, it is not an independent terminal condition.
        success = bool(self._route_complete() and not collided)

        terminated = bool(collided)
        truncated = bool(self.step_count >= self.max_steps)
        executed_beta, executed_latency = self.beta, self.latency_ms
        self._sample_latency_context()
        obs = self._get_obs(post_records)

        crit = self._select_critical(post_records)
        T_min = float(crit["T_i"]) if crit else 10.0
        D_min = float(crit["D_i"]) if crit else 50.0

        e_y_now, e_psi_now = self._compute_raw_errors()
        info = {
            "ttc": T_min,
            "geometric_ttc": min((r["T_geom"] for r in post_records), default=float("inf")),
            "nearest_dist": min((r["D_i"] for r in post_records), default=float("inf")),
            "critical_dist": D_min,
            "beta": executed_beta, "latency": executed_latency,
            "safety_state": self.supervisor.state_name,
            "safety_active": sup_state != SAFE,
            "supervisor_modified": bool(modified),
            "collision": bool(collided), "success": bool(success),
            "route_progress": float(self._route_progress()),
            "scenario": self.scenario,
            "safety_interventions": int(self.supervisor.intervention_count),
            "final_x": float(self.ego.position[0]),
            "speed": float(self.ego.velocity),
            "C_s": float(np.exp(-max(D_min, 0.0) / 9.0)) if crit else 0.0,
            "ppo_steering": d_ppo, "lqr_steering": d_lqr,
            "fused_steering": float(d_fuse), "final_steering": float(safe_action[0]),
            "lateral_error": float(e_y_now), "heading_error": float(e_psi_now),
            "raw_lateral_error": float(e_y_now), "raw_heading_error": float(e_psi_now),
            "symbolic_action": self.supervisor.symbolic_action_name,
            "symbolic_facts": self.supervisor.symbolic_facts_dict,
        }
        return obs, reward, terminated, truncated, info


def create_scenario_env(scenario="highway", seed=42):
    return LANSEnvScenarioAware(scenario=scenario, seed=seed,
                                latency_enabled=True,
                                safety_enabled=True,
                                lqr_enabled=True)


LANSSafeEnv = LANSEnvScenarioAware
