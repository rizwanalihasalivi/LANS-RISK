"""Reproducible extension; preserves historical outputs. See EXTENDED_PROTOCOL.md."""
import argparse
from collections import deque
from concurrent.futures import ProcessPoolExecutor, as_completed
import hashlib
import json
from extended_protocol import ROOT, OUT, SCENARIOS, SEEDS, jobs, checkpoint
import time

import numpy as np
import torch
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env

from lans_env_scenario import LANSSafeEnv
from scenario_config import get_scenario_config



class ProtocolEnv(LANSSafeEnv):
    def __init__(self, scenario, variant='full', delay=0, profile='nominal'):
        self.variant = variant
        self.delay_steps = int(delay)
        self.profile = profile
        self.pending = deque()
        self.applied_action = np.zeros(2)
        super().__init__(scenario=scenario, safety_enabled=variant != 'no_supervisor',
                         lqr_enabled=variant != 'no_lqr')

    def _sample_latency_context(self):
        super()._sample_latency_context()
        if self.variant == 'fixed_authority':
            self.beta = 0.5
        elif self.variant == 'no_lqr':
            self.beta = 1.0

    def _spawn_vehicles(self):
        super()._spawn_vehicles()
        factor = {'slower_npcs': 0.8, 'faster_npcs': 1.2}.get(self.profile, 1.0)
        for npc in self.npcs:
            npc.velocity *= factor
            npc.desired_speed *= factor
        if self.profile == 'initial_offset':
            offset = self.np_random.uniform(-0.25, 0.25)
            if self.scenario == 'roundabout':
                p = self.ego.position
                self.ego.position = p * (1 + offset / np.linalg.norm(p))
            else:
                self.ego.position[1] += offset

    def reset(self, **kwargs):
        self.pending.clear()
        self.pending.extend(np.zeros(2, dtype=np.float32) for _ in range(self.delay_steps))
        return super().reset(**kwargs)

    def _update_dynamics(self, action):
        self.pending.append(np.array(action, copy=True))
        self.applied_action = self.pending.popleft()
        super()._update_dynamics(self.applied_action)

    def step(self, action):
        obs, reward, done, truncated, info = super().step(action)
        # Parent logs the newly issued command. Delayed tests need the command
        # actually applied, including in the next policy observation.
        self.last_executed_steering = float(self.applied_action[0])
        obs[5] = self.last_executed_steering
        info['applied_steering'] = self.last_executed_steering
        info['command_delay_ms'] = 100 * self.delay_steps
        return obs, reward, done, truncated, info




def train(job):
    scenario, seed = job
    torch.set_num_threads(1)
    path = checkpoint(scenario, seed)
    metadata = path.with_suffix('.json')
    if path.exists() and metadata.exists():
        cached = json.loads(metadata.read_text())
        if cached['checkpoint_sha256'] != hashlib.sha256(path.read_bytes()).hexdigest():
            raise RuntimeError(f'Checkpoint integrity failure: {path}')
        return cached
    env = make_vec_env(lambda: ProtocolEnv(scenario), n_envs=8, seed=seed)
    model = PPO('MlpPolicy', env, seed=seed, device='cpu',
                learning_rate=get_scenario_config(scenario)['learning_rate'],
                n_steps=2048, batch_size=64, n_epochs=10, gamma=0.995,
                gae_lambda=0.95, clip_range=0.2, ent_coef=0.01, vf_coef=0.5,
                max_grad_norm=0.5,
                policy_kwargs=dict(net_arch=[128, 128, 64], activation_fn=torch.nn.ReLU))
    start = time.perf_counter()
    model.learn(total_timesteps=300000)
    path.parent.mkdir(parents=True, exist_ok=True)
    model.save(path)
    data = dict(scenario=scenario, training_seed=seed, steps=model.num_timesteps,
                seconds=time.perf_counter()-start,
                checkpoint_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    pending_metadata = metadata.with_suffix('.pending')
    pending_metadata.write_text(json.dumps(data, indent=2))
    pending_metadata.replace(metadata)
    env.close()
    return data


def evaluate(job):
    scenario, seed, variant, delay, profile, episodes = job
    torch.set_num_threads(1)
    label = f'{scenario}_{seed}_{variant}_delay{delay}_{profile}'
    output = OUT / 'episodes' / (label + '.jsonl')
    donefile = OUT / 'summaries' / (label + '.json')
    if donefile.exists():
        cached = json.loads(donefile.read_text())
        existing = [json.loads(line) for line in output.read_text().splitlines()]
        if cached['episodes'] != episodes or len(existing) != episodes:
            raise RuntimeError(f'Incomplete cached condition requires explicit recovery: {label}')
        if [r['episode_seed'] for r in existing] != list(range(40000,40000+episodes)):
            raise RuntimeError(f'Cached seed sequence mismatch: {label}')
        return cached
    analytical = variant.startswith('lqr_speed')
    env_variant = 'no_supervisor' if variant == 'lqr_speed_unshielded' else variant
    env = ProtocolEnv(scenario, env_variant, delay, profile)
    model = None if analytical else PPO.load(checkpoint(scenario, seed), device='cpu')
    output.parent.mkdir(parents=True, exist_ok=True)
    donefile.parent.mkdir(parents=True, exist_ok=True)
    records = []
    pending_output = output.with_suffix('.pending')
    with pending_output.open('w') as f:
        for episode in range(episodes):
            obs, _ = env.reset(seed=40000+episode)
            ey, speed, gap, ttc, times, rewards = [], [], [], [], [], []
            success = False
            interventions = 0
            for _ in range(env.max_steps):
                start = time.perf_counter_ns()
                if analytical:
                    lateral, heading = env._compute_raw_errors()
                    steer = env.lqr.compute_action(dict(lateral_error=lateral,
                        lateral_error_rate=env.e_y_dot_hat, yaw_error=heading,
                        yaw_error_rate=env.e_psi_dot_hat, speed=env.ego.velocity),
                        curvature=env._reference_curvature())[0]
                    action = np.array([steer, np.clip(
                        (env.config['desired_speed']-env.ego.velocity)/3.5, -1, 1)])
                else:
                    action, _ = model.predict(obs, deterministic=True)
                times.append((time.perf_counter_ns()-start)/1e6)
                obs, r, terminated, truncated, info = env.step(action)
                ey.append(info['lateral_error']); speed.append(info['speed'])
                gap.append(info['nearest_dist']); ttc.append(info['geometric_ttc'])
                rewards.append(r); success |= info['success']
                interventions += int(info['safety_active'])
                if terminated or truncated:
                    break
            collision = bool(info['collision'])
            row = dict(episode_seed=40000+episode, collision=collision,
                completion=bool(success and not collision), steps=len(speed),
                timeout=bool(truncated and not collision and not success),
                lateral_mae=float(np.mean(np.abs(ey))),
                lateral_rmse=float(np.sqrt(np.mean(np.square(ey)))),
                speed_mean=float(np.mean(speed)), progress=float(info['route_progress']),
                minimum_clearance=float(min(gap)),
                minimum_geometric_ttc=None if not np.isfinite(min(ttc)) else float(min(ttc)),
                reward=float(sum(rewards)), intervention_steps=interventions,
                proposal_ms_median=float(np.median(times)))
            f.write(json.dumps(row, allow_nan=False)+'\n')
            records.append(row)
    env.close()
    summary = dict(scenario=scenario, training_seed=None if analytical else seed,
        variant=variant, delay_ms=100*delay, profile=profile, episodes=episodes,
        collision_pct=100*np.mean([r['collision'] for r in records]),
        completion_pct=100*np.mean([r['completion'] for r in records]),
        timeout_pct=100*np.mean([r['timeout'] for r in records]))
    for key in ('lateral_mae','lateral_rmse','speed_mean','progress','minimum_clearance','reward'):
        summary[key] = float(np.mean([r[key] for r in records]))
    pending_output.replace(output)
    pending_summary = donefile.with_suffix('.pending')
    pending_summary.write_text(json.dumps(summary, indent=2, allow_nan=False))
    pending_summary.replace(donefile)
    return summary




def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--eval-workers', type=int, default=8)
    parser.add_argument('--episodes', type=int, default=500)
    parser.add_argument('--stage', choices=['train','evaluate','all'], default='all')
    args = parser.parse_args()
    OUT.mkdir(exist_ok=True)
    if args.stage in ('train','all'):
        with ProcessPoolExecutor(args.workers) as pool:
            tasks = [pool.submit(train, (s,k)) for s in SCENARIOS for k in SEEDS]
            for task in as_completed(tasks):
                print('TRAIN', json.dumps(task.result()), flush=True)
    if args.stage in ('evaluate','all'):
        with ProcessPoolExecutor(args.eval_workers) as pool:
            tasks = [pool.submit(evaluate, j) for j in jobs(args.episodes)]
            for task in as_completed(tasks):
                print('EVAL', json.dumps(task.result()), flush=True)
        summaries = [json.loads(p.read_text()) for p in sorted((OUT/'summaries').glob('*.json'))]
        (OUT/'summary.json').write_text(json.dumps(summaries, indent=2))
    print('REQUESTED STAGE COMPLETE', flush=True)


if __name__ == '__main__':
    main()
