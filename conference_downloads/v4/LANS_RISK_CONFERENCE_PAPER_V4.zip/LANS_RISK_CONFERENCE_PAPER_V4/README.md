# LANS-RISK conference manuscript — V4

`paper.pdf` is the definitive seven-page IEEE-style manuscript. `paper.docx` is an editable Word version; its single-column editing layout and pagination differ from the PDF. All 20 references remain cited.

## Revision and ARIS review

- Rebuilt framework matching the reference's spatial composition: wide serif blocks, upper prediction, central PPO, lower memory branch, tall right-side supervisor and bottom FIFO/plant/observation feedback loop. Blocks follow the actual LANS-RISK implementation: queue prediction, geometric steering, frozen PPO, sampled trajectories, risk-first selection, retained plans, physical FIFO and structured-state feedback. No EKF, latency-weighted gain or LQR–PPO fusion block was invented.
- Main Table III covers **all 12 controllers and all five measured delays: 0, 200, 500, 700 and 1,000 ms**. Each cell contains mean episode RMSE (m); corridor-completed/total. This completion criterion requires route completion, collision-free operation and no corridor excursion. Ordinary route-completion counts are also supplied in the CSVs. No values were interpolated at untested delays.
- Main Figure 2 separates all 12 controllers into individual panels, preventing one controller's curve from hiding another. Both completion and collision rates are shown.
- The main manuscript is seven pages. Supplemental scenario details are separate documents and are not manuscript pages.

The ARIS review checks the complete paper, implementation, original raw batches, all tables and statistical contrasts. `ARIS_REVIEW.md` documents findings, manuscript fixes and remaining limitations; `review/` preserves original reviewer reports and recomputations. Fresh native reviewers are same-family and the assessment is provisional, not external peer review or publication acceptance. Review identity requested by the skill is recorded separately from identity actually returned by the host.

The revision restricts information matching to nominal LANS–MPC, documents PPO's legacy 18-D input and deployment, adds scenario/termination details, and states that isolated benefits from retention/ranking remain unestablished. Frozen experiments were not changed or rerun.

`METHODS_SUPPLEMENT.md` provides scene distributions, policy feature ordering, checkpoint-recorded settings and endpoint/logging details.

## Detailed companion files

`all_controller_delay_tables.pdf`: four landscape pages, one per scenario, showing all 240 controller/scenario/delay cells.

`all_controller_scenario_figures.pdf`: three pages, retaining all 12 controllers in every scenario, with actor means and actor min–max shading (not confidence intervals).

`evidence/all_controller_delay_table.csv`: 60 aggregate cells, including RMSE, record count, route completions, corridor completions and collisions. `evidence/all_controller_delay_by_scenario.csv`: corresponding 240 scenario cells. Full main-confirmation episodes (44,000), condition-level metrics and paired tests are included. Actor-dependent methods have 1,200 records per aggregate delay; actor-free methods have 400. Repeated actors reuse traffic cases and are not independent pooled samples.

`figures/architecture.pdf`, `.svg`, and high-resolution `.png` provide reusable diagram formats. `figures/confirmation.*` provide the all-controller main plot. `source_excerpt/` contains unchanged controller and environment excerpts, including scene generation and policy features; it is not a standalone experiment installation.

## Build and validation

Requirements: Python with NumPy, Matplotlib and python-docx; Pandoc; pdflatex with IEEEtran (included), amsmath, booktabs, graphicx, array and hyperref. Run `python build_framework.py` to regenerate the vector framework. Run `python build_document.py` to rebuild manuscript PDF/Word from packaged figures and generated tables. Run `python build_supplement.py` to regenerate detailed scenario figures from packaged episode data. Compile `all_controller_delay_tables.tex` with pdflatex for the companion table PDF.

`build_main.py` regenerates the main tables/figures and checks original batch hashes using the existing full project recovery tree. Its S and R constants must point to the final verified results and frozen extended-baselines source if relocating that full project. The complete experimental code, models and logs remain in the previously delivered final verified project archive.

Run `python validate_package.py` for numerical and structural checks. `PACKAGE_VALIDATION.json` records those checks. `FULL_MAIN_PROVENANCE.json` lists all 880 raw/metadata hashes for 440 verified batches. `SHA256SUMS.json` identifies packaged payloads.

The expanded table now reports the whole main-confirmation grid, replacing V2's 22,000-record scope. This does not add experiments. The scientific freeze and original evidence are preserved. Read `CONFERENCE_JOURNAL_SCOPE.md` and `LITERATURE_REVIEW_NOTES.md` for extension scope, reference verification levels and scientific limits. The SOTA comparison is qualitative; external methods were not rerun.
