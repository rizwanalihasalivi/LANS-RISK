# Fresh ARIS review of LANS-RISK conference V4

Date: 2026-10-23. Reviewer session: `/root/aris_fresh_v4_review`. Requested reviewer: `gpt-6-astra`, reasoning `ultra`. The serving model and effort are not independently exposed; these are requested settings, not verified identity claims. `review_independence: same-family`; `acceptance_status: provisional`. This is a fresh artifact-grounded review, not external acceptance or cross-family validation. The exact assignment is in `REQUEST.txt`.

## Verdict

**V4 is scientifically coherent and suitable for submission consideration at a conference that values empirical control implementations and careful comparative evaluation. I found no mandatory scientific correction in the current bounded claims. Acceptance is not assured: limited incremental novelty is the principal remaining weakness. I would not recommend the present contribution for a top venue requiring a substantial new control/ML method or major empirical discovery.**

The supported result is specific and useful: within this implementation, queue compensation prevents a large degradation under a real command FIFO; the frozen actor adds no observed corridor-completion benefit; matched nominal MPC attains the same empirical delay thresholds. The paper states those results candidly. It does not demonstrate a superior learned controller, a new safety theorem, or a general advance over MPC. This is a judgment about the current V4 alone; I did not read earlier review reports or revision narratives.

No new experiment, retraining, robustness campaign, observation-delay extension, or runtime study is required to make the claims currently written defensible. Those would support a different and broader article. No manuscript or frozen evidence was modified during this review.

## What was independently verified

I read all manuscript sections, equations, tables and references in `paper.tex`; visually inspected all seven pages of `paper.pdf`, plus the full architecture and confirmation PNGs; read `METHODS_SUPPLEMENT.md` and `table_delay_grid.tex`; and inspected the executed controller/environment code named in the assignment. I checked the relevant passages of the five supplied primary literature extractions and the earlier LANS manuscript. I did not audit every cited paper or conduct a new literature search.

The numerical checks used arithmetic/statistics on saved records, not new simulator runs:

- All **44,000** packaged records match every original logged field in the corresponding **440 original JSONL batches**. Each condition has exactly the 100 ordered case seeds 141000–141099. All 440 original JSON summaries were read for condition count and starting seed.
- All **60 controller/delay aggregate rows**, all **240 scenario-specific rows**, and all **60 printed LaTeX cells** agree with the episode records. The standalone delay-grid LaTeX is included verbatim in the paper.
- All populated mean, sample-SD, extrema and 5th/50th/95th-percentile fields in the **5,720 descriptive rows** match. There are 140 unavailable rows with blank descriptive fields; these were not treated as observed values. All **2,200 Wilson interval rows** recompute correctly.
- All **3,440 paired tests** recompute: paired mean differences, binary discordances, exact binomial McNemar p-values, RMSE Wilcoxon p-values, and Holm correction over the entire family. There are 860 comparisons for each of collision, route completion, corridor completion and RMSE.
- All headline contrast counts, stated delay thresholds and endpoint directions match the records.
- Numeric training metadata in all **12 checkpoint ZIP JSON members** agrees with the supplied metadata. This was plain JSON inspection, without executing model objects. All 12 named packaged source excerpts are byte-identical to the corresponding restored originals.

I did **not** regenerate the 5,000-draw bootstrap intervals, rerun experiments, establish historical no-tuning chronology, reconstruct training trajectories, or independently reconstruct individual collision/RMSE events from full state/action traces. Those traces are absent from the saved batch logs. Thus the audit verifies internal consistency and aggregation, not independent remeasurement of the underlying simulation outcomes.

Primary evidence: `evidence/episodes.jsonl:1`, `evidence/descriptive_metrics.csv:1`, `evidence/paired_tests.csv:1`, `evidence/all_controller_delay_table.csv:1`, `evidence/all_controller_delay_by_scenario.csv:1`, `evidence/ACTOR_CHECKPOINT_METADATA.json:1`; original batches under `restored/LANS-RISK/working/extended_baselines/confirmation/`. Paths above are relative to `/workspace/recovery/conference_paper_v4/` unless they begin `restored/`, which is relative to `/workspace/recovery/`.

## Main findings

### 1. Numerical conclusions and statistical qualification are correct

| Comparison against LANS-RISK | Positive LANS corridor-rate differences | Negative differences | Equal rates | Positive differences significant after full-family Holm |
|---|---:|---:|---:|---:|
| Nominal MPC | 9/60 | 0/60 | 51/60 | 0/60 |
| No queue prediction | 45/60 | 0/60 | 15/60 | 45/60 |
| No actor | 0/60 | 0/60 | 60/60 | 0/60 |
| PPO only | 49/60 | 0/60 | 11/60 | 45/60 |

The common LANS/MPC contiguous passing thresholds are Highway 1,000 ms, Merge 700 ms, Intersection 1,000 ms and Roundabout 500 ms, for each of the three LANS actors. At 1,000 ms the LANS/MPC corridor rates are respectively 100/100%, 35/34%, 99/99%, and 0/0%. Queue removal has zero corridor completion in every scenario at that endpoint; its collision rates are 0%, 0%, 25%, and 100%.

The paper correctly avoids interpreting 60 contrasts as independent replications, 1,200 actor-repeated records as 1,200 independent scenes, nonsignificance as equivalence, or an empirical 1% passing criterion as a population safety bound. Holm correction does not require independence across tests, so the admitted dependence does not itself invalidate that adjustment. The full family is retained rather than recalculated on favorable displayed comparisons. The actor seeds are fixed; population inference over training seeds would remain unjustified, and V4 says so.

Evidence: `paper.tex:169`, `paper.tex:181`, `paper.tex:183`, `paper.tex:193`, `paper.tex:199`, `paper.tex:233`, `paper.tex:238`, `paper.tex:240`; representative paired-table rows `paired_tests.csv:68`, `:72`, `:84`, `:88`; the Merge Wilson examples are `descriptive_metrics.csv:3111` and `:3696`. These conclusions were checked across all relevant rows, not only these examples.

### 2. Nominal MPC is a credible comparison; PPO is a transferred-policy comparison

The nominal pair shares the physical plant/FIFO, structured state access, action bounds, desired speeds, observed-acceleration predictor, 30-step horizon and 3 × 192 sampled candidates. This is substantially fairer than comparing LANS only with the weak LQR or transferred PPO baselines. The distinct objectives, block/per-step representations, retention, warm starts and fallback mean it is not a one-component ablation. V4 explicitly says this and makes no equal-runtime claim.

The PPO actor receives a compressed 18-dimensional legacy observation, has no full NPC set or FIFO, and sees synthetic timing unrelated to the imposed command delay. Direct deployment forces the old fusion gain to one and disables the previous safety layer. This is a real limitation of the comparison, but it is already prominently disclosed. Therefore the observed PPO-to-LANS improvement supports the full planner/interface bundle. It does not establish an advantage over a policy trained specifically for this benchmark and information interface. V4 preserves that boundary.

The main remaining concern is interpretive weight: a reader should regard PPO as a legacy deployment baseline, while MPC and the no-actor variant carry the strongest evidence. This is a limitation, not an undisclosed flaw requiring retraining for this conference article.

Evidence: `paper.tex:60`, `paper.tex:161`, `paper.tex:172`, `paper.tex:240`; original `extended_baselines/adaptive_mpc.py:75`, `:83`, `:95`; `nominal_lans.py:29`, `:43`, `:51`; `experiment.py:48`, `:59`, `:99`; `traffic_v2/benchmark.py:85`; `submission_study/lans_env_scenario.py:329`, `:523`; supplement `:49`, `:51`.

### 3. Causal support is narrow but correctly stated

The no-prediction variant disables the internal propagation of pending commands and leaves the real FIFO active. It otherwise uses the same LANS class and case-seeded sampling scheme. The resulting loss supports queue compensation within this implementation. It does not establish that every form of prediction is necessary or that this predictor is optimal.

The no-actor removal replaces the proposal with analytical cruise and removes the actor-distance term while retaining the planning machinery. Equal corridor rates correctly support “no observed completion benefit,” not exact trajectory equivalence or universal uselessness of learning. There is no nominal isolation of retention or lexicographic ranking. V4 acknowledges that missing attribution and does not use the robust variants to fill the gap.

The cold, zero-filled FIFO and curved references constrain what any controller can achieve initially. Consequently the measured threshold is conditional on initialization and geometry, not an intrinsic latency limit of an algorithm. This is already stated. It limits how exciting the threshold match is as a contribution; it does not make the reported threshold false.

Evidence: `paper.tex:84`, `paper.tex:160`, `paper.tex:247`, `paper.tex:249`; `nominal_lans.py:39`, `:43`, `:56`; `experiment.py:53`, `:105`; `submission_study/extended_suite.py:51`; `scenario_planner.py:39`, `:47`, `:68`.

### 4. Sections III/IV and the architecture accurately describe the executed system

The ego propagation order, geometry, normalized command limits, acceleration estimation/clipping/decay, queue rollout, per-step means with five-step-shared noise, six explicit candidate slots, elite update, first-action actor penalty, lexicographic ordering, and shifted geometric-steering/full-brake tail agree with the implementation. The treatment of first-step clearance as the secondary criterion when collision-free duration is zero is also correct.

The architecture shows distinct structured-state and legacy actor inputs, arrival-state prediction, geometric steering, sampled selection, retained plans, the physical FIFO and the feedback path. It does not introduce an EKF or a live LQR/PPO actuation-fusion mechanism that the evaluated implementation lacks. The caption explains that the geometric steering rule is evaluated along each rollout, avoiding the mistaken interpretation of a fixed steering value for the entire horizon. The retained plan is correctly described as a candidate, not a certified backup.

All seven PDF pages are readable without visible clipping or a broken table. Figure 2 retains all 12 controllers and collisions as well as completion. Table III contains every tested delay and correctly distinguishes 400 from 1,200 descriptive-record denominators. Aggregation hides scenario differences, but the text gives the main endpoint differences and the companion table supplies all scenario rows. This is an acceptable space tradeoff, not evidence suppression.

Evidence: `paper.tex:62`, `:86`, `:103`, `:109`, `:119`, `:128`, `:139`, `:187`, `:208`; `adaptive_mpc.py:12`, `:25`, `:31`; `baselines.py:5`; `nominal_lans.py:12`, `:38`, `:50`, `:59`, `:66`; `experiment.py:73`.

### 5. The serious remaining weakness is contribution strength

Queue-aware prediction, predictive supervision, and retained backup/trajectory ideas are established. The supplied PSF papers explicitly construct backup plans and terminal-safe sets; Kalaria already combines delay handling with robust MPC and discusses guarding learned control. V4 correctly recognizes this. DAROM is also described in its actual observation-delay setting rather than numerically ranked against a command-FIFO benchmark. Cano Córdoba's formal shielding and miniature racing PSF are characterized in their proper guarantee/evaluation contexts. I found no material mischaracterization in the checked primary sources.

What remains distinct is an implemented combination of a geometric prior, frozen actor candidate/prior, per-step retained plan and collision-first sampled ranking, plus a transparent synthetic comparison. The evidence does not show that this combination improves completion or delay thresholds over the actor-free/MPC alternatives. Thus the paper's value is principally a carefully documented empirical result, including a negative finding about the learned proposal. That can fit an application/empirical control venue. For a top novelty venue, “predicting pending commands matters” plus no demonstrated actor gain is unlikely to clear the contribution bar, even when honestly framed. More benchmarking alone would not automatically solve that novelty problem.

Evidence: `paper.tex:19`, `:21`, `:25`, `:29`, `:34`, `:38`, `:245`, `:254`; supplied `1812.05506v4.pdf.txt:225`, `:246`; `2102.11907v1.pdf.txt:100`, `:142`, `:360`; `2208.13856v1 (1).pdf.txt:21`, `:275`; `canocordoba.txt:32`, `:48`, `:301`; `2403.11852v5.pdf.txt:319`, `:387`, `:415`, `:478`; earlier LANS manuscript `uploaded_paper1_text.txt:5`, `:158`, `:179`, `:209`.

## Mandatory corrections versus optional improvements

**Mandatory corrections detected: none for the stated conference scope and claims.** This is not a certificate that every implementation detail is flawless. It means the review found no demonstrated remaining error that invalidates the current manuscript's bounded conclusions.

Optional improvements, using existing material only:

1. Make the empirical takeaway even easier to grasp by leading the contribution paragraph with the negative result: the model-based queue compensation carries the completion benefit here, while the frozen actor adds none. The current manuscript already supports this; it is a positioning improvement, not a claim correction.
2. Put a few scenario-specific RMSE magnitudes beside the directional comparison in Section VI.A. At 1,000 ms, LANS/MPC mean RMSE is Highway 0.0798/0.0254 m, Merge 0.3781/0.4162 m, Intersection 0.0427/0.0309 m, and Roundabout 0.9274/0.9391 m. The last pair is on failed corridor episodes, so it must retain that qualification. No extra table or page is necessary.
3. Name/cite the standard cross-entropy-style sampling optimizer if space allows, and replace the supplement's tool-specific “full ARIS review” sentence (`METHODS_SUPPLEMENT.md:59`) with a neutral description of the statistical audit. Automated review is not itself scientific evidence.

Keep robustness to plant/traffic changes, stochastic observation delays, matched retraining, dedicated runtime measurements, full trajectory logging and isolated retention/ranking ablations as future work unless the claimed scope is expanded. Their absence is already disclosed and is not a reason to force another revision cycle on this seven-page article.

## Confidence and limits

Confidence is high in saved-record consistency, printed arithmetic, test reproduction, nominal implementation correspondence and the claim restrictions. Confidence is moderate in venue fit and originality assessment because acceptance is contextual and this was not an exhaustive literature search. Historical training/tuning chronology and the individual physical-event logs remain unverified. There was no independent external reviewer or acceptance decision.
