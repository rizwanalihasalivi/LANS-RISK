# LANS-RISK conference manuscript — V5

`paper.pdf` is the definitive **eight-page** IEEE-style conference manuscript, including references. `paper.docx` is editable; its editing layout/pagination differs from the PDF. All 20 references remain cited. V1–V4 remain preserved separately.

## Restored results in the main paper

The paper contains **six numbered tables** and **four figures**. Table III has two panels, so Word contains seven editable table blocks.

| Item | Content |
|---|---|
| Table I | Qualitative literature/SOTA mechanism comparison |
| Table II | Algorithm 1: LANS-RISK decision sequence |
| Table III | All 12 controllers at 0, 200, 500, 700 and 1,000 ms: RMSE and corridor-completed/total |
| Table IV | Scenario-wise LANS–MPC collision, corridor completion and RMSE at 1,000 ms |
| Table V | Empirical passing-delay endpoints for five focused controllers |
| Table VI | Scenario-wise no-prediction/no-actor/PPO ablations at 1,000 ms |
| Figure 1 | V4 reference-style framework, preserved |
| Figure 2 | All 12 controllers: aggregate completion and collision profiles |
| Figure 3 | Five focused controllers × four scenarios; separate rows expose coincident curves |
| Figure 4 | Passing-delay endpoints, actor variation, no-passing and censoring markers |

Repeated explanations in the abstract, introduction, literature, captions, results and discussion were condensed. Main method equations are unchanged from V4. State/FIFO access, legacy PPO deployment, matched-MPC differences, statistical assumptions and all central limitations remain disclosed. No font-size reduction was used for the body text. Figures/tables appear before the references.

## Data and scope

All 44,000 main-confirmation records and 440 conditions are retained. No experiment was rerun or altered. Aggregate actor-dependent denominators reuse paired traffic cases and are descriptive. Delay endpoints are not controller runtime measurements. No values are interpolated at unmeasured delays.

`all_controller_delay_tables.pdf` contains the full four-scenario tables. `all_controller_scenario_figures.pdf` contains all 12 methods in each scenario. The evidence directory contains raw episode metrics, processed statistics, thresholds, paired tests, all-controller tables and focused endpoint data. The methods supplement gives scene distributions, policy features, checkpoint-recorded metadata and logging limits. Source excerpts are unchanged; the full experiment installation/models remain in the complete project archive.

## Rebuild and verify

Requirements: Python with NumPy, Matplotlib and python-docx; Pandoc; pdflatex with the included IEEEtran class and standard amsmath/booktabs/graphicx/hyperref packages. Liberation Sans is used for the restored plots to avoid an embedded-font conflict between different Matplotlib PDFs.

1. Run `python build_focused_results.py` to recreate the restored tables and scenario/threshold figures from packaged evidence.
2. Run `python build_document.py` to build PDF and editable Word.
3. Run `python validate_package.py` to check all aggregate/focused tables, measured thresholds, PDF page count, references, captions, equations and unchanged primary evidence.

`build_framework.py` regenerates the preserved framework. `build_main.py` and `build_supplement.py` regenerate the other displays; `build_main.py` requires the full restored project paths for original-batch provenance. `PACKAGE_VALIDATION.json` records actual checks; `SHA256SUMS.json` binds the ZIP payloads.

The included ARIS reports reviewed V3/V4. **No new V5 model review is claimed.** V5 underwent deterministic numerical/structural validation and visual inspection. Prompt/call traces remain local under the ARIS privacy rule. `ARIS_REVIEW.md` explains the version boundary. Scientific findings and limitations are unchanged.
